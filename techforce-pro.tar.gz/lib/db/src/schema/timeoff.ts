import { pgTable, serial, integer, text, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const timeOffRequestsTable = pgTable("time_off_requests", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  requestedDate: date("requested_date").notNull(),
  status: text("status").notNull().default("pending"),
  denialReason: text("denial_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTimeOffSchema = createInsertSchema(timeOffRequestsTable).omit({ id: true, createdAt: true });
export type InsertTimeOff = z.infer<typeof insertTimeOffSchema>;
export type TimeOffRequest = typeof timeOffRequestsTable.$inferSelect;
