import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export type Role = "manager" | "supervisor" | "technician" | "customer";

interface AuthContextType {
  role: Role | null;
  setRole: (role: Role | null) => void;
  selectedEmployeeId: number | null;
  setSelectedEmployeeId: (id: number | null) => void;
  selectedCustomerId: number | null;
  setSelectedCustomerId: (id: number | null) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<Role | null>(() => {
    const stored = localStorage.getItem("tfpro_role");
    return stored as Role | null;
  });
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<number | null>(() => {
    const stored = localStorage.getItem("tfpro_emp_id");
    return stored ? Number(stored) : null;
  });
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(() => {
    const stored = localStorage.getItem("tfpro_cust_id");
    return stored ? Number(stored) : null;
  });

  const setRole = (r: Role | null) => {
    if (r) localStorage.setItem("tfpro_role", r);
    else localStorage.removeItem("tfpro_role");
    setRoleState(r);
  };

  useEffect(() => {
    if (selectedEmployeeId) localStorage.setItem("tfpro_emp_id", String(selectedEmployeeId));
    else localStorage.removeItem("tfpro_emp_id");
  }, [selectedEmployeeId]);

  useEffect(() => {
    if (selectedCustomerId) localStorage.setItem("tfpro_cust_id", String(selectedCustomerId));
    else localStorage.removeItem("tfpro_cust_id");
  }, [selectedCustomerId]);

  return (
    <AuthContext.Provider value={{ role, setRole, selectedEmployeeId, setSelectedEmployeeId, selectedCustomerId, setSelectedCustomerId }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
