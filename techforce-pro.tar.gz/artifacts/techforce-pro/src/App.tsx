import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AuthProvider, useAuth } from "@/hooks/use-auth";

// Auth/Role Picker
import Login from "@/pages/login";

// Layout
import MainLayout from "@/components/layout/main-layout";

// Manager Pages
import ManagerDashboard from "@/pages/manager/dashboard";
import Employees from "@/pages/manager/employees";
import EmployeeDetail from "@/pages/manager/employee-detail";
import Customers from "@/pages/manager/customers";
import CustomerDetail from "@/pages/manager/customer-detail";
import Jobs from "@/pages/manager/jobs";
import Returns from "@/pages/manager/returns";
import Reschedules from "@/pages/manager/reschedules";
import OpenJobs from "@/pages/manager/open-jobs";
import Schedules from "@/pages/manager/schedules";
import Profit from "@/pages/manager/profit";
import Invoices from "@/pages/manager/invoices";
import InvoiceDetail from "@/pages/manager/invoice-detail";
import InvoiceSettings from "@/pages/manager/invoice-settings";
import TimeOff from "@/pages/manager/time-off";
import JobStatuses from "@/pages/manager/job-statuses";

// Supervisor Pages
import SupervisorDashboard from "@/pages/supervisor/dashboard";

// Technician Pages
import TechSchedule from "@/pages/tech/schedule";
import TechTimeOff from "@/pages/tech/time-off";

// Customer Pages
import ClientPortal from "@/pages/customer/portal";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function AppRoutes() {
  const { role } = useAuth();

  if (!role) {
    return <Login />;
  }

  return (
    <SidebarProvider>
      <MainLayout>
        <Switch>
          {role === "manager" && (
            <>
              <Route path="/" component={ManagerDashboard} />
              <Route path="/employees" component={Employees} />
              <Route path="/employees/:id" component={EmployeeDetail} />
              <Route path="/customers" component={Customers} />
              <Route path="/customers/:id" component={CustomerDetail} />
              <Route path="/jobs" component={Jobs} />
              <Route path="/jobs/returns" component={Returns} />
              <Route path="/jobs/reschedules" component={Reschedules} />
              <Route path="/open-jobs" component={OpenJobs} />
              <Route path="/schedules" component={Schedules} />
              <Route path="/profit" component={Profit} />
              <Route path="/invoices" component={Invoices} />
              <Route path="/invoices/:id" component={InvoiceDetail} />
              <Route path="/invoice-settings" component={InvoiceSettings} />
              <Route path="/time-off" component={TimeOff} />
              <Route path="/job-statuses" component={JobStatuses} />
            </>
          )}
          
          {role === "supervisor" && (
            <>
              <Route path="/supervisor" component={SupervisorDashboard} />
              <Route path="/supervisor/jobs" component={Jobs} />
              <Route path="/supervisor/returns" component={Returns} />
              <Route path="/supervisor/reschedules" component={Reschedules} />
            </>
          )}

          {role === "technician" && (
            <>
              <Route path="/tech" component={TechSchedule} />
              <Route path="/tech/time-off" component={TechTimeOff} />
            </>
          )}

          {role === "customer" && (
            <>
              <Route path="/portal" component={ClientPortal} />
            </>
          )}

          <Route component={NotFound} />
        </Switch>
      </MainLayout>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppRoutes />
          </WouterRouter>
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
