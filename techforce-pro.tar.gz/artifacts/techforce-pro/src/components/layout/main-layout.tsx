import { type ReactNode } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
} from "@/components/ui/sidebar";

interface NavItem { label: string; icon: string; path: string; }

const MANAGER_NAV: NavItem[] = [
  { label: "Dashboard", icon: "📊", path: "/" },
  { label: "Profit Engine", icon: "💰", path: "/profit" },
  { label: "Employees", icon: "👷", path: "/employees" },
  { label: "Customers", icon: "🏢", path: "/customers" },
  { label: "Jobs", icon: "🔧", path: "/jobs" },
  { label: "Returns Queue", icon: "🔄", path: "/jobs/returns" },
  { label: "Reschedule Queue", icon: "📅", path: "/jobs/reschedules" },
  { label: "Open Jobs", icon: "📋", path: "/open-jobs" },
  { label: "Schedules", icon: "🗓️", path: "/schedules" },
  { label: "Invoices", icon: "📄", path: "/invoices" },
  { label: "Invoice Settings", icon: "⚙️", path: "/invoice-settings" },
  { label: "Time Off", icon: "🏖️", path: "/time-off" },
  { label: "Job Statuses", icon: "🏷️", path: "/job-statuses" },
];

const SUPERVISOR_NAV: NavItem[] = [
  { label: "Dashboard", icon: "📊", path: "/supervisor" },
  { label: "Jobs", icon: "🔧", path: "/supervisor/jobs" },
  { label: "Returns", icon: "🔄", path: "/supervisor/returns" },
  { label: "Reschedules", icon: "📅", path: "/supervisor/reschedules" },
];

const TECH_NAV: NavItem[] = [
  { label: "My Schedule", icon: "🗓️", path: "/tech" },
  { label: "Time Off", icon: "🏖️", path: "/tech/time-off" },
];

const CUSTOMER_NAV: NavItem[] = [
  { label: "My Portal", icon: "🏢", path: "/portal" },
];

export default function MainLayout({ children }: { children: ReactNode }) {
  const { role, setRole } = useAuth();
  const [location, setLocation] = useLocation();

  const navItems = role === "manager" ? MANAGER_NAV
    : role === "supervisor" ? SUPERVISOR_NAV
    : role === "technician" ? TECH_NAV
    : CUSTOMER_NAV;

  const roleLabel = role === "manager" ? "Manager / Admin"
    : role === "supervisor" ? "Supervisor"
    : role === "technician" ? "Technician"
    : "Customer";

  const roleIcon = role === "manager" ? "🧑‍💼"
    : role === "supervisor" ? "🦺"
    : role === "technician" ? "🔧"
    : "🏢";

  function logout() {
    setRole(null);
    setLocation("/");
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      <Sidebar className="border-r border-sidebar-border">
        <SidebarHeader className="px-4 py-3 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🔥</span>
            <div>
              <div className="font-bold text-sm text-sidebar-foreground">TechForce Pro</div>
              <div className="text-xs text-muted-foreground">Multicorp Fire Protection</div>
            </div>
          </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Navigation</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {navItems.map(item => {
                  const active = location === item.path || (item.path !== "/" && location.startsWith(item.path));
                  return (
                    <SidebarMenuItem key={item.path}>
                      <SidebarMenuButton
                        isActive={active}
                        onClick={() => setLocation(item.path)}
                        className="cursor-pointer"
                      >
                        <span>{item.icon}</span>
                        <span>{item.label}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="border-t border-sidebar-border p-3">
          <div className="flex items-center gap-2 px-2 py-1.5">
            <span className="text-lg">{roleIcon}</span>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-sidebar-foreground truncate">{roleLabel}</div>
            </div>
            <button onClick={logout} className="text-xs text-muted-foreground hover:text-destructive transition-colors">Exit</button>
          </div>
        </SidebarFooter>
      </Sidebar>
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
