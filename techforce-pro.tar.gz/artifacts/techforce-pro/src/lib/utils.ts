import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(amount);
}

export function formatPct(pct: number): string {
  return `${Math.round(pct)}%`;
}

export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    completed: "text-green-400 bg-green-400/10 border-green-400/20",
    in_progress: "text-blue-400 bg-blue-400/10 border-blue-400/20",
    pending: "text-slate-400 bg-slate-400/10 border-slate-400/20",
    return: "text-amber-400 bg-amber-400/10 border-amber-400/20",
    will_return: "text-amber-400 bg-amber-400/10 border-amber-400/20",
    reschedule: "text-purple-400 bg-purple-400/10 border-purple-400/20",
    emergency: "text-red-400 bg-red-400/10 border-red-400/20",
    private: "text-slate-500 bg-slate-500/10 border-slate-500/20",
    drop_off: "text-orange-400 bg-orange-400/10 border-orange-400/20",
    approved: "text-green-400 bg-green-400/10 border-green-400/20",
    denied: "text-red-400 bg-red-400/10 border-red-400/20",
    paid: "text-green-400 bg-green-400/10 border-green-400/20",
    sent: "text-blue-400 bg-blue-400/10 border-blue-400/20",
    draft: "text-slate-400 bg-slate-400/10 border-slate-400/20",
    overdue: "text-red-400 bg-red-400/10 border-red-400/20",
  };
  return map[status] ?? "text-slate-400 bg-slate-400/10 border-slate-400/20";
}

export const STATUS_ICONS: Record<string, string> = {
  completed: "✅",
  in_progress: "🔵",
  pending: "⏳",
  return: "🔄",
  will_return: "🔄",
  reschedule: "📅",
  emergency: "🚨",
  private: "🔒",
  drop_off: "📦",
};

export const ROLE_LABELS: Record<string, string> = {
  suppression_lead: "Suppression Lead",
  sprinkler_tech: "Sprinkler Tech",
  extinguisher_tech: "Extinguisher Tech",
  helper: "Helper",
  office_admin: "Office Admin",
};

export const FACILITY_LABELS: Record<string, string> = {
  restaurant: "Restaurant",
  school: "School",
  commercial: "Commercial",
  group_home: "Group Home",
  condo: "Condo",
  fleet: "Fleet",
  other: "Other",
};

export const SERVICE_LABELS: Record<string, string> = {
  extinguisher_inspection: "Extinguisher Inspection",
  hood_suppression: "Hood Suppression",
  sprinkler_test: "Sprinkler Test",
  exit_light_check: "Exit Light Check",
  emergency_service: "Emergency Service",
};

export const CERT_LABELS: Record<string, string> = {
  extinguisher: "Extinguisher",
  suppression: "Suppression",
  sprinkler: "Sprinkler",
  exit_light: "Exit Light",
  any: "Any",
};

export function getUtilColor(pct: number): string {
  if (pct >= 90) return "text-green-400";
  if (pct >= 80) return "text-amber-400";
  return "text-red-400";
}

export function getPriorityColor(priority: string): string {
  if (priority === "high") return "text-red-400 bg-red-400/10 border-red-400/20";
  if (priority === "medium") return "text-amber-400 bg-amber-400/10 border-amber-400/20";
  return "text-slate-400 bg-slate-400/10 border-slate-400/20";
}
