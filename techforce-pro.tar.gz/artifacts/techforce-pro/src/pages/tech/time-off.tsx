import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { getStatusColor } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface TimeOff { id: number; employeeId: number; requestedDate: string; status: string; denialReason: string | null; createdAt: string; employeeName: string; }

export default function TechTimeOff() {
  const { selectedEmployeeId } = useAuth();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [date, setDate] = useState("");

  const { data: allRequests = [] } = useQuery<(TimeOff & { employeeName: string })[]>({
    queryKey: ["time-off"],
    queryFn: () => apiFetch("/time-off"),
  });

  const myRequests = allRequests.filter(r => r.employeeId === selectedEmployeeId);

  const request = useMutation({
    mutationFn: () => apiFetch("/time-off", { method: "POST", body: JSON.stringify({ employeeId: selectedEmployeeId, requestedDate: date }) }),
    onSuccess: (data: any) => {
      qc.invalidateQueries({ queryKey: ["time-off"] });
      setDate("");
      if (data.status === "approved") toast({ title: "✅ Time off approved!" });
      else toast({ title: `❌ Request denied`, description: data.denialReason ?? "Contact your manager" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  return (
    <div className="p-6 space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">🏖️ Request Time Off</h1>
        <p className="text-sm text-muted-foreground">Requests are auto-evaluated based on your shop day balance, utilization, and scheduled jobs</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <h3 className="font-semibold text-foreground">New Request</h3>
        <div>
          <label className="text-xs text-muted-foreground uppercase block mb-1">Date Requested</label>
          <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="max-w-xs" />
        </div>
        <Button onClick={() => request.mutate()} disabled={!date || !selectedEmployeeId || request.isPending}>
          {request.isPending ? "Submitting..." : "Submit Request"}
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">My Request History</h3></div>
        {myRequests.length === 0 ? (
          <div className="px-4 py-8 text-center text-muted-foreground text-sm">No requests submitted yet</div>
        ) : myRequests.map(r => (
          <div key={r.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
            <div className="flex-1">
              <div className="font-medium text-sm text-foreground">{r.requestedDate}</div>
              {r.denialReason && <div className="text-xs text-red-400 mt-0.5">{r.denialReason}</div>}
            </div>
            <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(r.status)}`}>{r.status}</span>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="font-semibold text-sm text-foreground mb-2">How Requests Are Evaluated</h3>
        <div className="space-y-1 text-xs text-muted-foreground">
          <div>🟢 Approved if: shop days available + utilization above 85% + no job conflict</div>
          <div>🔴 Denied if: at 90%+ of shop day limit</div>
          <div>🔴 Denied if: utilization below 85%</div>
          <div>🔴 Denied if: you have a billable job scheduled that day</div>
        </div>
      </div>
    </div>
  );
}
