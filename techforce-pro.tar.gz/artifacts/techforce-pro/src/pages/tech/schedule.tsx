import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { getStatusColor, STATUS_ICONS, SERVICE_LABELS, formatCurrency } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

interface Job { id: number; customerName: string; customerAddress: string; serviceType: string; status: string; scheduledDate: string | null; scheduledTime: string | null; revenue: number; notes: string | null; certificationRequired: string; }
interface Employee { id: number; name: string; role: string; shopDaysUsedYtd: number; allowedShopDays: number; utilizationPct: number; }

export default function TechSchedule() {
  const { selectedEmployeeId } = useAuth();
  const { data: schedule = [], isLoading } = useQuery<Job[]>({
    queryKey: ["employee-schedule", selectedEmployeeId],
    queryFn: () => apiFetch(`/employees/${selectedEmployeeId}/schedule`),
    enabled: !!selectedEmployeeId,
  });
  const { data: employee } = useQuery<Employee>({
    queryKey: ["employee", selectedEmployeeId],
    queryFn: () => apiFetch(`/employees/${selectedEmployeeId}`),
    enabled: !!selectedEmployeeId,
  });

  const upcoming = schedule.filter(j => j.status !== "completed").sort((a, b) => (a.scheduledDate ?? "").localeCompare(b.scheduledDate ?? ""));
  const completed = schedule.filter(j => j.status === "completed");

  return (
    <div className="p-6 space-y-6 max-w-3xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">🗓️ My Schedule</h1>
        {employee && <p className="text-sm text-muted-foreground">{employee.name} · Shop days: {employee.shopDaysUsedYtd}/{employee.allowedShopDays}</p>}
      </div>

      {!selectedEmployeeId ? (
        <div className="text-muted-foreground">No employee selected. Please log in again.</div>
      ) : isLoading ? <div className="text-muted-foreground">Loading your schedule...</div> : (
        <>
          <div className="space-y-3">
            <h3 className="font-semibold text-foreground">Upcoming Jobs</h3>
            {upcoming.length === 0 ? (
              <div className="rounded-xl border border-border bg-card p-8 text-center text-muted-foreground">No upcoming jobs assigned. Check back soon!</div>
            ) : upcoming.map(job => (
              <div key={job.id} className={`rounded-xl border bg-card p-4 ${job.status === "emergency" ? "border-red-500/50" : "border-border"}`}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="font-semibold text-foreground">{job.customerName}</div>
                    <div className="text-sm text-muted-foreground">{job.customerAddress}</div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(job.status)}`}>{STATUS_ICONS[job.status]} {job.status.replace(/_/g, " ")}</span>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>📋 {SERVICE_LABELS[job.serviceType] ?? job.serviceType}</span>
                  {job.scheduledDate && <span>📅 {job.scheduledDate}</span>}
                  {job.scheduledTime && <span>🕐 {job.scheduledTime}</span>}
                </div>
                {job.notes && <div className="text-xs text-muted-foreground mt-2 italic">"{job.notes}"</div>}
              </div>
            ))}
          </div>

          {completed.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold text-foreground text-sm text-muted-foreground">Completed ({completed.length})</h3>
              {completed.map(job => (
                <div key={job.id} className="rounded-lg border border-border/50 bg-card/50 p-3 flex items-center justify-between opacity-60">
                  <div>
                    <div className="text-sm font-medium text-foreground">{job.customerName}</div>
                    <div className="text-xs text-muted-foreground">{job.scheduledDate ?? "No date"} · {SERVICE_LABELS[job.serviceType] ?? job.serviceType}</div>
                  </div>
                  <span className="text-xs text-green-400">✅ Done</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
