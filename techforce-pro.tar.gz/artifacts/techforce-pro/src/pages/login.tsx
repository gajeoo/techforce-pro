import { useState } from "react";
import { useAuth, type Role } from "@/hooks/use-auth";
import { apiFetch } from "@/lib/api";
import { useLocation } from "wouter";

const ROLES: { id: Role; label: string; desc: string; icon: string; color: string }[] = [
  { id: "manager", label: "Manager / Admin", desc: "Full access — scheduling, profit, invoicing, team management", icon: "🧑‍💼", color: "border-blue-500 hover:bg-blue-500/10" },
  { id: "supervisor", label: "Supervisor", desc: "View & manage daily jobs, returns, reschedules, team roster", icon: "🦺", color: "border-amber-500 hover:bg-amber-500/10" },
  { id: "technician", label: "Technician", desc: "View your schedule, submit time-off requests", icon: "🔧", color: "border-green-500 hover:bg-green-500/10" },
  { id: "customer", label: "Customer Portal", desc: "View your jobs, invoices, and service history", icon: "🏢", color: "border-purple-500 hover:bg-purple-500/10" },
];

interface Employee { id: number; name: string; role: string; }
interface Customer { id: number; name: string; }

export default function Login() {
  const { setRole, setSelectedEmployeeId, setSelectedCustomerId } = useAuth();
  const [step, setStep] = useState<"role" | "employee" | "customer">("role");
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [, setLocation] = useLocation();

  async function pickRole(role: Role) {
    setSelectedRole(role);
    if (role === "technician") {
      const data = await apiFetch<Employee[]>("/employees");
      setEmployees(data);
      setStep("employee");
    } else if (role === "customer") {
      const data = await apiFetch<Customer[]>("/customers");
      setCustomers(data);
      setStep("customer");
    } else {
      setRole(role);
      setLocation(role === "supervisor" ? "/supervisor" : "/");
    }
  }

  async function pickEmployee(emp: Employee) {
    setSelectedEmployeeId(emp.id);
    setRole("technician");
    setLocation("/tech");
  }

  async function pickCustomer(cust: Customer) {
    setSelectedCustomerId(cust.id);
    setRole("customer");
    setLocation("/portal");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-lg px-4">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🔥</div>
          <h1 className="text-3xl font-bold text-foreground">TechForce Pro</h1>
          <p className="text-muted-foreground mt-1">Multicorp Fire Protection Services</p>
        </div>

        {step === "role" && (
          <div className="space-y-3">
            <p className="text-center text-sm text-muted-foreground mb-4">Select your role to continue</p>
            {ROLES.map(r => (
              <button key={r.id} onClick={() => pickRole(r.id)} className={`w-full flex items-start gap-4 p-4 rounded-xl border border-border bg-card ${r.color} transition-all text-left group`}>
                <span className="text-2xl">{r.icon}</span>
                <div>
                  <div className="font-semibold text-foreground group-hover:text-white transition-colors">{r.label}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{r.desc}</div>
                </div>
              </button>
            ))}
          </div>
        )}

        {step === "employee" && (
          <div className="space-y-3">
            <button onClick={() => setStep("role")} className="text-sm text-muted-foreground hover:text-foreground mb-2 flex items-center gap-1">← Back</button>
            <p className="text-center text-sm text-muted-foreground mb-4">Select your name</p>
            {employees.map(emp => (
              <button key={emp.id} onClick={() => pickEmployee(emp)} className="w-full flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-green-500 hover:bg-green-500/10 transition-all text-left">
                <span className="text-xl">🔧</span>
                <div>
                  <div className="font-semibold text-foreground">{emp.name}</div>
                  <div className="text-xs text-muted-foreground capitalize">{emp.role.replace(/_/g, " ")}</div>
                </div>
              </button>
            ))}
            {employees.length === 0 && <p className="text-center text-muted-foreground text-sm">No technicians found. Add employees first.</p>}
          </div>
        )}

        {step === "customer" && (
          <div className="space-y-3">
            <button onClick={() => setStep("role")} className="text-sm text-muted-foreground hover:text-foreground mb-2 flex items-center gap-1">← Back</button>
            <p className="text-center text-sm text-muted-foreground mb-4">Select your company</p>
            {customers.map(c => (
              <button key={c.id} onClick={() => pickCustomer(c)} className="w-full flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-purple-500 hover:bg-purple-500/10 transition-all text-left">
                <span className="text-xl">🏢</span>
                <div className="font-semibold text-foreground">{c.name}</div>
              </button>
            ))}
            {customers.length === 0 && <p className="text-center text-muted-foreground text-sm">No customers found. Add customers first.</p>}
          </div>
        )}
      </div>
    </div>
  );
}
