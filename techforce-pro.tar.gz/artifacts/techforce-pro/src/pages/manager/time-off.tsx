import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { getStatusColor } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface TimeOff { id: number; employeeId: number; employeeName: string; requestedDate: string; status: string; denialReason: string | null; createdAt: string; }

export default function TimeOff() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: requests = [], isLoading } = useQuery<TimeOff[]>({ queryKey: ["time-off"], queryFn: () => apiFetch("/time-off") });

  const review = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => apiFetch(`/time-off/${id}/review`, { method: "POST", body: JSON.stringify({ status }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["time-off"] }); toast({ title: "Decision saved" }); },
  });

  const pending = requests.filter(r => r.status === "pending");
  const decided = requests.filter(r => r.status !== "pending");

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">🏖️ Time Off Requests</h1>
        <p className="text-sm text-muted-foreground">Auto-rules: denied if shop day limit hit, utilization below 85%, or billable job conflicts</p>
      </div>

      {/* Auto-Deny Rules */}
      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="font-semibold text-sm text-foreground mb-3">⚙️ Auto-Approval Rules</h3>
        <div className="space-y-1 text-xs text-muted-foreground">
          <div>🔴 Denied if technician has used 90%+ of their annual shop day limit</div>
          <div>🔴 Denied if technician utilization is below 85%</div>
          <div>🔴 Denied if technician has a scheduled billable job on the requested date</div>
          <div>✅ Auto-approved if all checks pass — manager can still manually override</div>
        </div>
      </div>

      {/* Pending */}
      {isLoading ? <div className="text-muted-foreground">Loading...</div> : (
        <>
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <h3 className="font-semibold text-foreground">Pending Review</h3>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-xs">{pending.length}</span>
            </div>
            {pending.length === 0 ? (
              <div className="px-4 py-6 text-center text-muted-foreground text-sm">No pending requests</div>
            ) : pending.map(r => (
              <div key={r.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
                <div className="flex-1">
                  <div className="font-medium text-sm text-foreground">{r.employeeName}</div>
                  <div className="text-xs text-muted-foreground">Requested: {r.requestedDate}</div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => review.mutate({ id: r.id, status: "approved" })} className="text-xs px-3 py-1 rounded bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30 transition-colors">Approve</button>
                  <button onClick={() => review.mutate({ id: r.id, status: "denied" })} className="text-xs px-3 py-1 rounded bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30 transition-colors">Deny</button>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">History</h3></div>
            {decided.length === 0 ? <div className="px-4 py-6 text-center text-muted-foreground text-sm">No decisions yet</div> : decided.map(r => (
              <div key={r.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
                <div className="flex-1">
                  <div className="font-medium text-sm text-foreground">{r.employeeName}</div>
                  <div className="text-xs text-muted-foreground">Requested: {r.requestedDate}</div>
                  {r.denialReason && <div className="text-xs text-red-400 mt-0.5">Reason: {r.denialReason}</div>}
                </div>
                <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(r.status)}`}>{r.status}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
