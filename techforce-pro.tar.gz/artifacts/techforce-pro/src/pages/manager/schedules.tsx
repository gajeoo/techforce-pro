import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { getStatusColor, STATUS_ICONS, formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface Employee { id: number; name: string; }
interface CalendarEntry { employeeId: number; employeeName: string; date: string; type: string; revenue: number; jobId: number | null; customerName: string | null; status: string | null; }

export default function Schedules() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [emergencyOpen, setEmergencyOpen] = useState(false);
  const [selectedEmpId, setSelectedEmpId] = useState<string>("");

  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["employees"], queryFn: () => apiFetch("/employees") });
  const { data: calendar = [], refetch } = useQuery<CalendarEntry[]>({ queryKey: ["team-calendar"], queryFn: () => apiFetch("/dashboard/team-calendar") });

  const emergency = useMutation({
    mutationFn: () => apiFetch("/schedules/emergency", { method: "POST", body: JSON.stringify({ employeeId: Number(selectedEmpId) }) }),
    onSuccess: (data: any) => { qc.invalidateQueries({ queryKey: ["open-jobs"] }); setEmergencyOpen(false); toast({ title: `🚨 Emergency: ${data.assignedCount} jobs assigned to tech`, variant: "default" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  // Group calendar by date
  const byDate: Record<string, CalendarEntry[]> = {};
  for (const entry of calendar) {
    if (!byDate[entry.date]) byDate[entry.date] = [];
    byDate[entry.date].push(entry);
  }
  const dates = Object.keys(byDate).sort();

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">🗓️ Team Schedule</h1>
          <p className="text-sm text-muted-foreground">View and manage all technician assignments</p>
        </div>
        <Button variant="destructive" onClick={() => setEmergencyOpen(true)}>🚨 Emergency Schedule</Button>
      </div>

      {dates.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center text-muted-foreground">
          <div className="text-4xl mb-2">🗓️</div>
          <div className="font-medium">No scheduled jobs yet</div>
          <div className="text-sm mt-1">Add jobs with dates to see the team calendar</div>
        </div>
      ) : (
        <div className="space-y-4">
          {dates.map(date => (
            <div key={date} className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="px-4 py-2.5 border-b border-border bg-muted/20">
                <h3 className="font-semibold text-sm text-foreground">{new Date(date + "T00:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</h3>
                <p className="text-xs text-muted-foreground">{byDate[date].length} assignment{byDate[date].length !== 1 ? "s" : ""} · {formatCurrency(byDate[date].reduce((s, e) => s + e.revenue, 0))} revenue</p>
              </div>
              <div className="divide-y divide-border/50">
                {byDate[date].map((entry, i) => (
                  <div key={i} className="px-4 py-3 flex items-center gap-4">
                    <div className="text-sm font-medium text-foreground w-36">{entry.employeeName}</div>
                    <div className="flex-1 text-sm text-muted-foreground">{entry.customerName ?? "—"}</div>
                    <div className="text-sm text-green-400">{formatCurrency(entry.revenue)}</div>
                    {entry.status && <span className={`text-xs px-2 py-0.5 rounded border ${getStatusColor(entry.status)}`}>{STATUS_ICONS[entry.status]} {entry.status.replace(/_/g, " ")}</span>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={emergencyOpen} onOpenChange={setEmergencyOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>🚨 Emergency Schedule</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-sm text-muted-foreground">Select a technician to immediately assign all eligible unassigned open jobs to them.</p>
            <Select value={selectedEmpId} onValueChange={setSelectedEmpId}>
              <SelectTrigger><SelectValue placeholder="Select technician..." /></SelectTrigger>
              <SelectContent>{employees.map(e => <SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>)}</SelectContent>
            </Select>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setEmergencyOpen(false)}>Cancel</Button>
              <Button variant="destructive" onClick={() => emergency.mutate()} disabled={!selectedEmpId || emergency.isPending}>🚨 Trigger Emergency</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
