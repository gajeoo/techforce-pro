import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, getStatusColor, STATUS_ICONS, SERVICE_LABELS } from "@/lib/utils";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface Customer { id: number; name: string; facilityType: string; address: string; contactName: string; contactPhone: string; contactEmail: string | null; }
interface CustomerPricing { id: number; serviceType: string; customerRate: number; standardRate: number; unit: string; }
interface Job { id: number; serviceType: string; status: string; scheduledDate: string | null; revenue: number; }
interface Invoice { id: number; invoiceNumber: string; totalAmount: number; status: string; generatedAt: string; }

export default function CustomerDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [pricingOpen, setPricingOpen] = useState(false);
  const [pricingForm, setPricingForm] = useState({ serviceType: "extinguisher_inspection", customerRate: 0, standardRate: 0, unit: "flat" });

  const { data: customer } = useQuery<Customer>({ queryKey: ["customer", id], queryFn: () => apiFetch(`/customers/${id}`) });
  const { data: pricing = [] } = useQuery<CustomerPricing[]>({ queryKey: ["customer-pricing", id], queryFn: () => apiFetch(`/customers/${id}/pricing`) });
  const { data: jobs = [] } = useQuery<Job[]>({ queryKey: ["customer-jobs", id], queryFn: () => apiFetch(`/customers/${id}/jobs`) });
  const { data: invoices = [] } = useQuery<Invoice[]>({ queryKey: ["customer-invoices", id], queryFn: () => apiFetch(`/customers/${id}/invoices`) });

  const savePricing = useMutation({
    mutationFn: () => apiFetch(`/customers/${id}/pricing`, { method: "POST", body: JSON.stringify(pricingForm) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["customer-pricing", id] }); setPricingOpen(false); toast({ title: "Pricing updated" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  if (!customer) return <div className="p-6 text-muted-foreground">Loading...</div>;

  const totalRevenue = invoices.filter(i => i.status === "paid" || i.status === "sent").reduce((s, i) => s + i.totalAmount, 0);

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <Button variant="outline" onClick={() => setLocation("/customers")}>← Back</Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{customer.name}</h1>
          <p className="text-sm text-muted-foreground">{customer.address}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="stat-card"><div className="stat-label">Total Revenue</div><div className="stat-value text-green-400">{formatCurrency(totalRevenue)}</div></div>
        <div className="stat-card"><div className="stat-label">Total Jobs</div><div className="stat-value">{jobs.length}</div></div>
        <div className="stat-card"><div className="stat-label">Open Invoices</div><div className="stat-value text-amber-400">{invoices.filter(i => i.status === "sent").length}</div></div>
        <div className="stat-card"><div className="stat-label">Contact</div><div className="font-medium text-sm text-foreground">{customer.contactName}</div><div className="text-xs text-muted-foreground">{customer.contactPhone}</div></div>
      </div>

      {/* Custom Pricing */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-foreground">Custom Pricing</h3>
          <Button size="sm" onClick={() => setPricingOpen(true)}>+ Add Rate</Button>
        </div>
        {pricing.length === 0 ? (
          <div className="px-4 py-6 text-center text-muted-foreground text-sm">No custom rates set — using standard pricing</div>
        ) : (
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border">{["Service", "Standard Rate", "Customer Rate", "Unit"].map(h => <th key={h} className="px-4 py-2 text-left text-xs text-muted-foreground uppercase">{h}</th>)}</tr></thead>
            <tbody>
              {pricing.map(p => (
                <tr key={p.id} className="border-b border-border/50">
                  <td className="px-4 py-3 text-foreground">{SERVICE_LABELS[p.serviceType] ?? p.serviceType}</td>
                  <td className="px-4 py-3 text-muted-foreground line-through">{formatCurrency(p.standardRate)}</td>
                  <td className="px-4 py-3 text-green-400 font-medium">{formatCurrency(p.customerRate)}</td>
                  <td className="px-4 py-3 text-muted-foreground capitalize">{p.unit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Jobs History */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">Job History</h3></div>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border">{["Date", "Service", "Status", "Revenue"].map(h => <th key={h} className="px-4 py-2 text-left text-xs text-muted-foreground uppercase">{h}</th>)}</tr></thead>
          <tbody>
            {jobs.length === 0 && <tr><td colSpan={4} className="px-4 py-6 text-center text-muted-foreground">No jobs yet</td></tr>}
            {jobs.map(j => (
              <tr key={j.id} className="border-b border-border/50">
                <td className="px-4 py-3 text-muted-foreground">{j.scheduledDate ?? "TBD"}</td>
                <td className="px-4 py-3 text-foreground">{SERVICE_LABELS[j.serviceType] ?? j.serviceType}</td>
                <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(j.status)}`}>{STATUS_ICONS[j.status]} {j.status.replace(/_/g, " ")}</span></td>
                <td className="px-4 py-3 text-green-400">{formatCurrency(j.revenue)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={pricingOpen} onOpenChange={setPricingOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Set Custom Rate</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><label className="text-xs text-muted-foreground uppercase">Service Type</label>
              <Select value={pricingForm.serviceType} onValueChange={v => setPricingForm(f => ({ ...f, serviceType: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(SERVICE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground uppercase">Standard Rate ($)</label><Input type="number" value={pricingForm.standardRate} onChange={e => setPricingForm(f => ({ ...f, standardRate: Number(e.target.value) }))} /></div>
              <div><label className="text-xs text-muted-foreground uppercase">Customer Rate ($)</label><Input type="number" value={pricingForm.customerRate} onChange={e => setPricingForm(f => ({ ...f, customerRate: Number(e.target.value) }))} /></div>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Unit</label>
              <Select value={pricingForm.unit} onValueChange={v => setPricingForm(f => ({ ...f, unit: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="flat">Flat</SelectItem><SelectItem value="per_unit">Per Unit</SelectItem><SelectItem value="per_head">Per Head</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setPricingOpen(false)}>Cancel</Button>
              <Button onClick={() => savePricing.mutate()} disabled={savePricing.isPending}>Save</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
