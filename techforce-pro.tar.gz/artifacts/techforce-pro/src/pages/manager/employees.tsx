import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, ROLE_LABELS, CERT_LABELS, getUtilColor } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface Employee {
  id: number; name: string; role: string; salary: number; billableRate: number;
  homeZip: string; certifications: string[]; allowedShopDays: number; shopDaysUsedYtd: number;
  utilizationPct: number; isActive: boolean;
}

const BLANK = { name: "", role: "extinguisher_tech", salary: 50000, billableRate: 75, homeZip: "", certifications: [] as string[], isActive: true };

export default function Employees() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(BLANK);
  const [editId, setEditId] = useState<number | null>(null);

  const { data: employees = [], isLoading } = useQuery<Employee[]>({ queryKey: ["employees"], queryFn: () => apiFetch("/employees") });

  const save = useMutation({
    mutationFn: async () => {
      if (editId) return apiFetch(`/employees/${editId}`, { method: "PUT", body: JSON.stringify(form) });
      return apiFetch("/employees", { method: "POST", body: JSON.stringify(form) });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["employees"] }); setOpen(false); toast({ title: editId ? "Employee updated" : "Employee added" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const del = useMutation({
    mutationFn: (id: number) => apiFetch(`/employees/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["employees"] }); toast({ title: "Employee removed" }); },
  });

  function openCreate() { setForm(BLANK); setEditId(null); setOpen(true); }
  function openEdit(e: Employee) { setForm({ name: e.name, role: e.role, salary: e.salary, billableRate: e.billableRate, homeZip: e.homeZip, certifications: e.certifications, isActive: e.isActive }); setEditId(e.id); setOpen(true); }
  function toggleCert(c: string) { setForm(f => ({ ...f, certifications: f.certifications.includes(c) ? f.certifications.filter(x => x !== c) : [...f.certifications, c] })); }

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-foreground">Employees</h1><p className="text-sm text-muted-foreground">Manage your field technicians and staff</p></div>
        <Button onClick={openCreate}>+ Add Employee</Button>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Name", "Role", "Salary", "Bill Rate", "Certifications", "Shop Days", "Utilization", ""].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs text-muted-foreground font-medium uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">No employees yet. Add your first team member.</td></tr>
              )}
              {employees.map(emp => (
                <tr key={emp.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3">
                    <button onClick={() => setLocation(`/employees/${emp.id}`)} className="font-medium text-primary hover:underline">{emp.name}</button>
                    {!emp.isActive && <span className="ml-2 text-xs text-muted-foreground">(inactive)</span>}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{ROLE_LABELS[emp.role] ?? emp.role}</td>
                  <td className="px-4 py-3 text-muted-foreground">{formatCurrency(emp.salary)}</td>
                  <td className="px-4 py-3 text-muted-foreground">${emp.billableRate}/hr</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {(emp.certifications ?? []).map(c => (
                        <span key={c} className="px-1.5 py-0.5 rounded text-xs bg-blue-500/10 text-blue-400 border border-blue-500/20">{CERT_LABELS[c] ?? c}</span>
                      ))}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{emp.shopDaysUsedYtd}/{emp.allowedShopDays}</td>
                  <td className={`px-4 py-3 font-medium ${getUtilColor(emp.utilizationPct)}`}>{Math.round(emp.utilizationPct)}%</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => openEdit(emp)} className="text-xs text-muted-foreground hover:text-foreground">Edit</button>
                      <button onClick={() => del.mutate(emp.id)} className="text-xs text-muted-foreground hover:text-destructive">Remove</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "Edit Employee" : "Add Employee"}</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><label className="text-xs text-muted-foreground uppercase">Name</label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Full name" /></div>
            <div><label className="text-xs text-muted-foreground uppercase">Role</label>
              <Select value={form.role} onValueChange={v => setForm(f => ({ ...f, role: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(ROLE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground uppercase">Annual Salary ($)</label><Input type="number" value={form.salary} onChange={e => setForm(f => ({ ...f, salary: Number(e.target.value) }))} /></div>
              <div><label className="text-xs text-muted-foreground uppercase">Bill Rate ($/hr)</label><Input type="number" value={form.billableRate} onChange={e => setForm(f => ({ ...f, billableRate: Number(e.target.value) }))} /></div>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Home ZIP</label><Input value={form.homeZip} onChange={e => setForm(f => ({ ...f, homeZip: e.target.value }))} placeholder="21046" /></div>
            <div>
              <label className="text-xs text-muted-foreground uppercase block mb-2">Certifications</label>
              <div className="flex flex-wrap gap-2">
                {Object.entries(CERT_LABELS).filter(([k]) => k !== "any").map(([k, v]) => (
                  <button key={k} onClick={() => toggleCert(k)} className={`px-3 py-1 rounded-full text-xs border transition-colors ${form.certifications.includes(k) ? "bg-blue-500 border-blue-500 text-white" : "border-border text-muted-foreground hover:border-blue-500"}`}>{v}</button>
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => save.mutate()} disabled={!form.name || save.isPending}>{save.isPending ? "Saving..." : "Save"}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
