import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { getPriorityColor, CERT_LABELS } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface OpenJob { id: number; title: string; clientName: string; certRequired: string; priority: string; assignedEmployeeId: number | null; assignedEmployeeName: string | null; notes: string | null; }
const BLANK = { title: "", clientName: "", certRequired: "any", priority: "medium", notes: "" };

export default function OpenJobs() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(BLANK);

  const { data: jobs = [], isLoading } = useQuery<OpenJob[]>({ queryKey: ["open-jobs"], queryFn: () => apiFetch("/open-jobs") });

  const create = useMutation({
    mutationFn: () => apiFetch("/open-jobs", { method: "POST", body: JSON.stringify(form) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["open-jobs"] }); setOpen(false); toast({ title: "Open job added" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const del = useMutation({
    mutationFn: (id: number) => apiFetch(`/open-jobs/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["open-jobs"] }); toast({ title: "Job removed" }); },
  });

  const autoAssign = useMutation({
    mutationFn: () => apiFetch("/schedules/auto-assign", { method: "POST" }),
    onSuccess: (data: any) => { qc.invalidateQueries({ queryKey: ["open-jobs"] }); toast({ title: `Auto-assigned ${data.assignedCount} jobs` }); },
  });

  const fillShopDays = useMutation({
    mutationFn: () => apiFetch("/schedules/fill-shop-days", { method: "POST" }),
    onSuccess: (data: any) => { qc.invalidateQueries({ queryKey: ["open-jobs"] }); toast({ title: `Filled ${data.assignedCount} shop-day slots` }); },
  });

  const highJobs = jobs.filter(j => j.priority === "high");
  const medJobs = jobs.filter(j => j.priority === "medium");
  const lowJobs = jobs.filter(j => j.priority === "low");

  const JobCard = ({ job }: { job: OpenJob }) => (
    <div className={`rounded-lg border bg-card p-3 ${getPriorityColor(job.priority).includes("red") ? "border-red-500/30" : job.priority === "medium" ? "border-amber-500/30" : "border-border"}`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="font-medium text-sm text-foreground">{job.title}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{job.clientName}</div>
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-xs px-1.5 py-0.5 rounded border ${getPriorityColor(job.priority)}`}>{job.priority}</span>
            <span className="text-xs text-muted-foreground">{CERT_LABELS[job.certRequired] ?? job.certRequired}</span>
            {job.assignedEmployeeName && <span className="text-xs text-green-400">→ {job.assignedEmployeeName}</span>}
          </div>
          {job.notes && <div className="text-xs text-muted-foreground mt-1 italic">"{job.notes}"</div>}
        </div>
        <button onClick={() => del.mutate(job.id)} className="text-xs text-muted-foreground hover:text-destructive ml-2">✕</button>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-4 max-w-6xl mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">📋 Open Jobs</h1>
          <p className="text-sm text-muted-foreground">Unscheduled work orders sorted by priority</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={() => fillShopDays.mutate()} disabled={fillShopDays.isPending}>🏪 Fill Shop Days</Button>
          <Button variant="outline" onClick={() => autoAssign.mutate()} disabled={autoAssign.isPending}>⚡ Auto-Assign All</Button>
          <Button onClick={() => { setForm(BLANK); setOpen(true); }}>+ Add Job</Button>
        </div>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 mb-3"><span className="text-red-400">🔴</span><h3 className="font-semibold text-sm text-foreground">High Priority</h3><span className="text-xs text-muted-foreground">({highJobs.length})</span></div>
            {highJobs.length === 0 && <div className="text-xs text-muted-foreground text-center py-4">None</div>}
            {highJobs.map(j => <JobCard key={j.id} job={j} />)}
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2 mb-3"><span className="text-amber-400">🟡</span><h3 className="font-semibold text-sm text-foreground">Medium Priority</h3><span className="text-xs text-muted-foreground">({medJobs.length})</span></div>
            {medJobs.length === 0 && <div className="text-xs text-muted-foreground text-center py-4">None</div>}
            {medJobs.map(j => <JobCard key={j.id} job={j} />)}
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2 mb-3"><span className="text-slate-400">🟢</span><h3 className="font-semibold text-sm text-foreground">Low Priority</h3><span className="text-xs text-muted-foreground">({lowJobs.length})</span></div>
            {lowJobs.length === 0 && <div className="text-xs text-muted-foreground text-center py-4">None</div>}
            {lowJobs.map(j => <JobCard key={j.id} job={j} />)}
          </div>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Add Open Job</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><label className="text-xs text-muted-foreground uppercase">Job Title</label><Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="e.g. Hood inspection - Main St" /></div>
            <div><label className="text-xs text-muted-foreground uppercase">Client Name</label><Input value={form.clientName} onChange={e => setForm(f => ({ ...f, clientName: e.target.value }))} /></div>
            <div><label className="text-xs text-muted-foreground uppercase">Priority</label>
              <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="high">🔴 High</SelectItem><SelectItem value="medium">🟡 Medium</SelectItem><SelectItem value="low">🟢 Low</SelectItem></SelectContent>
              </Select>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Certification Required</label>
              <Select value={form.certRequired} onValueChange={v => setForm(f => ({ ...f, certRequired: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(CERT_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Notes</label><Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => create.mutate()} disabled={!form.title || create.isPending}>Add Job</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
