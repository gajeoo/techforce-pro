import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, getStatusColor, STATUS_ICONS, SERVICE_LABELS } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Job { id: number; customerName: string; serviceType: string; status: string; scheduledDate: string | null; revenue: number; notes: string | null; requiresFollowUp: boolean; followUpConfirmed: boolean; employeeName: string | null; }

const STATUSES = ["pending", "in_progress", "completed", "return", "will_return", "reschedule", "emergency"];

export default function Returns() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: jobs = [], isLoading } = useQuery<Job[]>({ queryKey: ["returns"], queryFn: () => apiFetch("/jobs/returns") });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => apiFetch(`/jobs/${id}`, { method: "PUT", body: JSON.stringify({ status }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["returns"] }); qc.invalidateQueries({ queryKey: ["jobs"] }); toast({ title: "Status updated" }); },
  });

  const confirmFollowup = useMutation({
    mutationFn: (id: number) => apiFetch(`/jobs/${id}/confirm-followup`, { method: "POST" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["returns"] }); toast({ title: "Follow-up confirmed ✓" }); },
  });

  return (
    <div className="p-6 space-y-4 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">🔄 Returns Queue</h1>
        <p className="text-sm text-muted-foreground">Jobs with status: Return or Will Return — awaiting follow-up scheduling</p>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : jobs.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center text-muted-foreground">
          <div className="text-4xl mb-2">✅</div>
          <div className="font-medium">Returns queue is clear!</div>
        </div>
      ) : (
        <div className="space-y-3">
          {jobs.map(job => (
            <div key={job.id} className={`rounded-xl border bg-card p-4 ${getStatusColor(job.status).includes("amber") ? "border-amber-500/30" : "border-border"}`}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-foreground">{job.customerName}</span>
                    <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(job.status)}`}>{STATUS_ICONS[job.status]} {job.status.replace(/_/g, " ")}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType} · {job.scheduledDate ?? "No date"} · {job.employeeName ?? "Unassigned"}</div>
                  {job.notes && <div className="text-xs text-muted-foreground mt-1 italic">"{job.notes}"</div>}
                  {job.requiresFollowUp && !job.followUpConfirmed && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-xs text-amber-400">⚠️ Follow-up confirmation required</span>
                      <button onClick={() => confirmFollowup.mutate(job.id)} className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 hover:bg-amber-500/30 transition-colors">Confirm</button>
                    </div>
                  )}
                  {job.requiresFollowUp && job.followUpConfirmed && (
                    <div className="text-xs text-green-400 mt-1">✅ Follow-up confirmed</div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="text-green-400 font-medium">{formatCurrency(job.revenue)}</div>
                  <Select value={job.status} onValueChange={v => updateStatus.mutate({ id: job.id, status: v })}>
                    <SelectTrigger className="h-7 text-xs w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_ICONS[s] ?? ""} {s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
