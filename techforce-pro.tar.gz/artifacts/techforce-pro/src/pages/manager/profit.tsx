import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, formatPct, getUtilColor, ROLE_LABELS } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface EmployeeROI {
  employeeId: number; employeeName: string; role: string;
  revenueYtd: number; salaryCostYtd: number; shopDayCost: number; netProfit: number;
  utilizationPct: number; shopDaysUsed: number; shopDaysAllowed: number;
}
interface ProfitLeak { employeeId: number; employeeName: string; message: string; severity: string; dollarAmount: number; }
interface Summary { shopDayCostYtd: number; projectedAnnualSavings: number; teamUtilizationPct: number; }

export default function Profit() {
  const { data: roi = [] } = useQuery<EmployeeROI[]>({ queryKey: ["employee-roi"], queryFn: () => apiFetch("/dashboard/employee-roi") });
  const { data: leaks = [] } = useQuery<ProfitLeak[]>({ queryKey: ["profit-leaks"], queryFn: () => apiFetch("/dashboard/profit-leaks") });
  const { data: summary } = useQuery<Summary>({ queryKey: ["dashboard-summary"], queryFn: () => apiFetch("/dashboard/summary") });

  const totalRevenue = roi.reduce((s, r) => s + r.revenueYtd, 0);
  const totalNetProfit = roi.reduce((s, r) => s + r.netProfit, 0);
  const totalShopCost = roi.reduce((s, r) => s + r.shopDayCost, 0);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">💰 Profit Engine</h1>
        <p className="text-sm text-muted-foreground">Shop day optimization — every day a tech is in the shop costs money</p>
      </div>

      {/* Formula Card */}
      <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-4">
        <h3 className="font-semibold text-blue-400 mb-2">📐 Daily Cost Formula</h3>
        <div className="font-mono text-sm text-foreground">
          Daily Cost = (Annual Salary × 1.3 + $10,000) ÷ 260 working days
        </div>
        <div className="mt-2 text-xs text-muted-foreground">
          The 1.3× multiplier covers payroll taxes, benefits, and overhead. $10,000 covers annual vehicle/equipment costs. Dividing by 260 gives the true daily burden rate.
        </div>
        <div className="mt-3 grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
          {[
            { role: "Suppression Lead", days: 2 }, { role: "Sprinkler Tech", days: 3 },
            { role: "Extinguisher Tech", days: 5 }, { role: "Helper", days: 12 }, { role: "Office Admin", days: 0 },
          ].map(r => (
            <div key={r.role} className="bg-muted/30 rounded p-2">
              <div className="font-medium text-foreground">{r.role}</div>
              <div className="text-amber-400">{r.days} shop days/yr</div>
            </div>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="stat-card"><div className="stat-label">Total Revenue YTD</div><div className="stat-value text-green-400">{formatCurrency(totalRevenue)}</div></div>
        <div className="stat-card"><div className="stat-label">Net Profit YTD</div><div className={`stat-value ${totalNetProfit >= 0 ? "text-green-400" : "text-red-400"}`}>{formatCurrency(totalNetProfit)}</div></div>
        <div className="stat-card"><div className="stat-label">Shop Day Cost YTD</div><div className="stat-value text-amber-400">{formatCurrency(totalShopCost)}</div></div>
        <div className="stat-card"><div className="stat-label">Projected Annual Savings</div><div className="stat-value text-blue-400">{summary ? formatCurrency(summary.projectedAnnualSavings) : "—"}</div><div className="text-xs text-muted-foreground">vs last year (180 shop days)</div></div>
      </div>

      {/* ROI Chart */}
      {roi.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="font-semibold mb-4 text-foreground">Net Profit per Technician YTD</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={roi} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="employeeName" tick={{ fill: "#94a3b8", fontSize: 11 }} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
              <Bar dataKey="netProfit" name="Net Profit" radius={[4, 4, 0, 0]} fill="#22c55e" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Shop Day Usage */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">Shop Day Usage by Technician</h3></div>
        <div className="divide-y divide-border/50">
          {roi.length === 0 && <div className="px-4 py-8 text-center text-muted-foreground">Add employees to track shop day usage</div>}
          {roi.map(r => {
            const pct = r.shopDaysAllowed > 0 ? (r.shopDaysUsed / r.shopDaysAllowed) * 100 : 0;
            const barColor = pct >= 100 ? "bg-red-500" : pct >= 80 ? "bg-amber-500" : "bg-blue-500";
            return (
              <div key={r.employeeId} className="px-4 py-3">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <span className="font-medium text-sm text-foreground">{r.employeeName}</span>
                    <span className="text-xs text-muted-foreground ml-2">{ROLE_LABELS[r.role] ?? r.role}</span>
                  </div>
                  <div className="text-sm">
                    <span className={pct >= 100 ? "text-red-400" : "text-amber-400"}>{r.shopDaysUsed}</span>
                    <span className="text-muted-foreground">/{r.shopDaysAllowed} days</span>
                    <span className="ml-3 text-amber-400">{formatCurrency(r.shopDayCost)}</span>
                  </div>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div className={`h-full rounded-full ${barColor} transition-all`} style={{ width: `${Math.min(pct, 100)}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Profit Leak Detail */}
      {leaks.length > 0 && (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">⚠️ Profit Leak Analysis</h3></div>
          <div className="divide-y divide-border/50">
            {leaks.map((leak, i) => (
              <div key={i} className="px-4 py-3 flex items-start gap-3">
                <span className="text-lg">{leak.severity === "high" ? "🔴" : "🟡"}</span>
                <div className="flex-1">
                  <div className="font-medium text-sm text-foreground">{leak.employeeName}</div>
                  <div className="text-xs text-muted-foreground">{leak.message}</div>
                </div>
                <div className={`font-bold text-sm ${leak.severity === "high" ? "text-red-400" : "text-amber-400"}`}>{formatCurrency(leak.dollarAmount)}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
