import { STATUS_ICONS, getStatusColor } from "@/lib/utils";

const STATUSES = [
  { key: "pending", label: "Pending", desc: "Job created, not yet started", icon: STATUS_ICONS.pending },
  { key: "in_progress", label: "In Progress", desc: "Technician is on-site performing the service", icon: STATUS_ICONS.in_progress },
  { key: "completed", label: "Completed", desc: "Job finished — invoice auto-generated", icon: STATUS_ICONS.completed },
  { key: "return", label: "Return", desc: "Tech needs to return — goes to Returns Queue", icon: STATUS_ICONS.return },
  { key: "will_return", label: "Will Return", desc: "Client confirmed a follow-up visit is needed", icon: STATUS_ICONS.will_return },
  { key: "reschedule", label: "Reschedule", desc: "Job must be moved to a new date — goes to Reschedule Queue", icon: STATUS_ICONS.reschedule },
  { key: "emergency", label: "Emergency", desc: "Urgent dispatch — highest priority", icon: STATUS_ICONS.emergency },
  { key: "private", label: "Private", desc: "Internal job — not visible to customer portal", icon: STATUS_ICONS.private },
  { key: "drop_off", label: "Drop Off", desc: "Customer dropped off equipment at the shop", icon: STATUS_ICONS.drop_off },
];

export default function JobStatuses() {
  return (
    <div className="p-6 space-y-6 max-w-3xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">🏷️ Job Status Reference</h1>
        <p className="text-sm text-muted-foreground">All available job statuses and their meanings — used across jobs, returns, and reschedule queues</p>
      </div>

      <div className="space-y-3">
        {STATUSES.map(s => (
          <div key={s.key} className="rounded-xl border border-border bg-card p-4 flex items-start gap-4">
            <div className="text-3xl">{s.icon ?? "⚙️"}</div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <span className="font-semibold text-foreground">{s.label}</span>
                <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(s.key)}`}>{s.key.replace(/_/g, " ")}</span>
              </div>
              <div className="text-sm text-muted-foreground">{s.desc}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-4">
        <h3 className="font-semibold text-blue-400 mb-2">💡 Queue Logic</h3>
        <div className="space-y-1 text-xs text-muted-foreground">
          <div>• <span className="text-foreground">Return / Will Return</span> → Appears in Returns Queue automatically</div>
          <div>• <span className="text-foreground">Reschedule</span> → Appears in Reschedule Queue; requires follow-up confirmation before new date can be set</div>
          <div>• <span className="text-foreground">Completed</span> → Invoice is auto-generated upon status change</div>
          <div>• <span className="text-foreground">Emergency</span> → Flagged for immediate attention; use Emergency Schedule button in Schedules</div>
        </div>
      </div>
    </div>
  );
}
