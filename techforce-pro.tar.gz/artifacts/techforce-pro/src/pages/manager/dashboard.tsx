import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, formatPct, getUtilColor } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

interface Summary {
  shopDayCostYtd: number; teamUtilizationPct: number; revenueYtd: number;
  activeTechCount: number; openJobCount: number; returnJobCount: number;
  rescheduleJobCount: number; projectedAnnualSavings: number;
}
interface ProfitLeak { employeeId: number; employeeName: string; message: string; severity: string; dollarAmount: number; }
interface RevenueByService { serviceType: string; revenueYtd: number; jobCount: number; }
interface EmployeeROI {
  employeeId: number; employeeName: string; role: string;
  revenueYtd: number; salaryCostYtd: number; shopDayCost: number; netProfit: number;
  utilizationPct: number; shopDaysUsed: number; shopDaysAllowed: number;
}

const CHART_COLORS = ["#3b82f6", "#22c55e", "#f59e0b", "#a855f7", "#ef4444"];
const SERVICE_NAMES: Record<string, string> = {
  extinguisher_inspection: "Extinguisher", hood_suppression: "Hood Sup.", sprinkler_test: "Sprinkler", exit_light_check: "Exit Light", emergency_service: "Emergency",
};

export default function ManagerDashboard() {
  const { data: summary } = useQuery<Summary>({ queryKey: ["dashboard-summary"], queryFn: () => apiFetch("/dashboard/summary") });
  const { data: leaks = [] } = useQuery<ProfitLeak[]>({ queryKey: ["profit-leaks"], queryFn: () => apiFetch("/dashboard/profit-leaks") });
  const { data: revenue = [] } = useQuery<RevenueByService[]>({ queryKey: ["revenue-by-service"], queryFn: () => apiFetch("/dashboard/revenue-by-service") });
  const { data: roi = [] } = useQuery<EmployeeROI[]>({ queryKey: ["employee-roi"], queryFn: () => apiFetch("/dashboard/employee-roi") });

  const pieData = revenue.map((r, i) => ({ name: SERVICE_NAMES[r.serviceType] ?? r.serviceType, value: r.revenueYtd, color: CHART_COLORS[i % CHART_COLORS.length] }));

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Command Center</h1>
          <p className="text-sm text-muted-foreground">Multicorp Fire Protection Services — YTD Overview</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="stat-label">Revenue YTD</div>
          <div className="stat-value text-green-400">{summary ? formatCurrency(summary.revenueYtd) : "—"}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Shop Day Cost YTD</div>
          <div className="stat-value text-amber-400">{summary ? formatCurrency(summary.shopDayCostYtd) : "—"}</div>
          <div className="text-xs text-muted-foreground mt-1">Projected savings: {summary ? formatCurrency(summary.projectedAnnualSavings) : "—"}/yr</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Team Utilization</div>
          <div className={`stat-value ${summary ? getUtilColor(summary.teamUtilizationPct) : ""}`}>{summary ? formatPct(summary.teamUtilizationPct) : "—"}</div>
          <div className="text-xs text-muted-foreground mt-1">Target: 85%+</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Active Techs</div>
          <div className="stat-value">{summary?.activeTechCount ?? "—"}</div>
        </div>
      </div>

      {/* Queue Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="stat-card border-amber-500/30">
          <div className="flex items-center gap-2">
            <span className="text-xl">🔄</span>
            <div>
              <div className="stat-label">Returns Queue</div>
              <div className="stat-value text-amber-400">{summary?.returnJobCount ?? 0} jobs</div>
            </div>
          </div>
        </div>
        <div className="stat-card border-purple-500/30">
          <div className="flex items-center gap-2">
            <span className="text-xl">📅</span>
            <div>
              <div className="stat-label">Reschedule Queue</div>
              <div className="stat-value text-purple-400">{summary?.rescheduleJobCount ?? 0} jobs</div>
            </div>
          </div>
        </div>
        <div className="stat-card border-blue-500/30">
          <div className="flex items-center gap-2">
            <span className="text-xl">📋</span>
            <div>
              <div className="stat-label">Unassigned Open Jobs</div>
              <div className="stat-value text-blue-400">{summary?.openJobCount ?? 0} jobs</div>
            </div>
          </div>
        </div>
        <div className="stat-card border-red-500/30">
          <div className="flex items-center gap-2">
            <span className="text-xl">⚠️</span>
            <div>
              <div className="stat-label">Profit Alerts</div>
              <div className="stat-value text-red-400">{leaks.filter(l => l.severity === "high").length} high</div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="font-semibold mb-4 text-foreground">Revenue by Service Type</h3>
          {revenue.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={revenue.map(r => ({ ...r, name: SERVICE_NAMES[r.serviceType] ?? r.serviceType }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Bar dataKey="revenueYtd" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="h-[220px] flex items-center justify-center text-muted-foreground text-sm">No completed jobs yet</div>}
        </div>

        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="font-semibold mb-4 text-foreground">Revenue Mix</h3>
          {pieData.length > 0 ? (
            <div className="flex items-center gap-4">
              <ResponsiveContainer width="50%" height={200}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} dataKey="value">
                    {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-2">
                {pieData.map((entry, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
                    <span className="text-muted-foreground flex-1">{entry.name}</span>
                    <span className="font-medium text-foreground">{formatCurrency(entry.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">No completed jobs yet</div>}
        </div>
      </div>

      {/* Profit Leaks */}
      {leaks.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="font-semibold mb-4 text-foreground">⚠️ Profit Leak Alerts</h3>
          <div className="space-y-2">
            {leaks.map((leak, i) => (
              <div key={i} className={`flex items-start gap-3 p-3 rounded-lg border ${leak.severity === "high" ? "border-red-500/30 bg-red-500/5" : "border-amber-500/30 bg-amber-500/5"}`}>
                <span className="text-lg">{leak.severity === "high" ? "🔴" : "🟡"}</span>
                <div className="flex-1">
                  <div className="font-medium text-sm text-foreground">{leak.employeeName}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{leak.message}</div>
                </div>
                <div className={`text-sm font-bold ${leak.severity === "high" ? "text-red-400" : "text-amber-400"}`}>{formatCurrency(leak.dollarAmount)}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Employee ROI Table */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <h3 className="font-semibold text-foreground">Employee ROI Tracker</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Technician", "Revenue YTD", "Salary Cost YTD", "Shop Day Cost", "Net Profit", "Utilization", "Shop Days"].map(h => (
                  <th key={h} className="px-4 py-2 text-left text-xs text-muted-foreground font-medium uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {roi.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">No employee data yet. Add employees to get started.</td></tr>
              )}
              {roi.map(r => (
                <tr key={r.employeeId} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{r.employeeName}</td>
                  <td className="px-4 py-3 text-green-400">{formatCurrency(r.revenueYtd)}</td>
                  <td className="px-4 py-3 text-muted-foreground">{formatCurrency(r.salaryCostYtd)}</td>
                  <td className="px-4 py-3 text-amber-400">{formatCurrency(r.shopDayCost)}</td>
                  <td className={`px-4 py-3 font-bold ${r.netProfit >= 0 ? "text-green-400" : "text-red-400"}`}>{formatCurrency(r.netProfit)}</td>
                  <td className={`px-4 py-3 font-medium ${getUtilColor(r.utilizationPct)}`}>{formatPct(r.utilizationPct)}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.shopDaysUsed}/{r.shopDaysAllowed}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
