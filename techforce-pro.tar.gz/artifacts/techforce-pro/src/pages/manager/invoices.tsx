import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, getStatusColor } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Invoice { id: number; invoiceNumber: string; customerId: number; jobId: number | null; totalAmount: number; status: string; generatedAt: string; customerName: string; lineItems: Array<{ service: string; quantity: number; rate: number; total: number }>; }

export default function Invoices() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({ queryKey: ["invoices"], queryFn: () => apiFetch("/invoices") });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => apiFetch(`/invoices/${id}`, { method: "PUT", body: JSON.stringify({ status }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["invoices"] }); toast({ title: "Invoice updated" }); },
  });

  const filtered = statusFilter === "all" ? invoices : invoices.filter(i => i.status === statusFilter);
  const totalRevenue = invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.totalAmount, 0);
  const pendingRevenue = invoices.filter(i => i.status === "sent").reduce((s, i) => s + i.totalAmount, 0);

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-foreground">📄 Invoices</h1><p className="text-sm text-muted-foreground">All generated invoices and billing history</p></div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="stat-card"><div className="stat-label">Collected Revenue</div><div className="stat-value text-green-400">{formatCurrency(totalRevenue)}</div></div>
        <div className="stat-card"><div className="stat-label">Pending Collection</div><div className="stat-value text-amber-400">{formatCurrency(pendingRevenue)}</div></div>
        <div className="stat-card"><div className="stat-label">Total Invoices</div><div className="stat-value">{invoices.length}</div></div>
      </div>

      <div className="flex gap-2">
        {["all", "draft", "sent", "paid", "overdue"].map(s => (
          <button key={s} onClick={() => setStatusFilter(s)} className={`px-3 py-1 rounded-full text-xs border transition-colors ${statusFilter === s ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}>
            {s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Invoice #", "Customer", "Amount", "Status", "Date", ""].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs text-muted-foreground font-medium uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No invoices yet. Complete a job to auto-generate one.</td></tr>}
              {filtered.map(inv => (
                <tr key={inv.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3">
                    <button onClick={() => setLocation(`/invoices/${inv.id}`)} className="font-mono text-primary hover:underline text-sm">{inv.invoiceNumber}</button>
                  </td>
                  <td className="px-4 py-3 text-foreground">{inv.customerName}</td>
                  <td className="px-4 py-3 text-green-400 font-medium">{formatCurrency(inv.totalAmount)}</td>
                  <td className="px-4 py-3">
                    <Select value={inv.status} onValueChange={v => updateStatus.mutate({ id: inv.id, status: v })}>
                      <SelectTrigger className={`h-7 text-xs w-28 border ${getStatusColor(inv.status)}`}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["draft", "sent", "paid", "overdue"].map(s => <SelectItem key={s} value={s} className="text-xs">{s.charAt(0).toUpperCase() + s.slice(1)}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{new Date(inv.generatedAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => setLocation(`/invoices/${inv.id}`)} className="text-xs text-muted-foreground hover:text-foreground">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
