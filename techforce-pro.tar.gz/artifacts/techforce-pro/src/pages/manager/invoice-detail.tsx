import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency } from "@/lib/utils";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

interface Invoice {
  id: number; invoiceNumber: string; customerId: number; totalAmount: number;
  status: string; generatedAt: string; customerName: string;
  lineItems: Array<{ service: string; quantity: number; rate: number; total: number }>;
}
interface Template { companyName: string; address: string; phone: string; logoUrl: string | null; }

export default function InvoiceDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { data: invoice } = useQuery<Invoice>({ queryKey: ["invoice", id], queryFn: () => apiFetch(`/invoices/${id}`) });
  const { data: template } = useQuery<Template>({ queryKey: ["invoice-template"], queryFn: () => apiFetch("/invoice-template") });

  if (!invoice) return <div className="p-6 text-muted-foreground">Loading...</div>;

  function print() { window.print(); }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6 print:hidden">
        <Button variant="outline" onClick={() => setLocation("/invoices")}>← Back</Button>
        <Button onClick={print}>🖨️ Print / PDF</Button>
      </div>

      <div className="rounded-xl border border-border bg-card p-8 space-y-6 print:border-none print:shadow-none">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-2xl font-bold text-foreground">{template?.companyName ?? "Multicorp Fire Protection Services"}</div>
            <div className="text-sm text-muted-foreground mt-1">{template?.address ?? "9693 Gerwig Lane, Columbia, MD 21046"}</div>
            <div className="text-sm text-muted-foreground">{template?.phone ?? "(410) 876-5000"}</div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-primary">INVOICE</div>
            <div className="font-mono text-lg text-foreground mt-1">{invoice.invoiceNumber}</div>
            <div className="text-sm text-muted-foreground">Date: {new Date(invoice.generatedAt).toLocaleDateString()}</div>
          </div>
        </div>

        {/* Bill To */}
        <div className="rounded-lg bg-muted/30 p-4">
          <div className="text-xs uppercase text-muted-foreground font-medium mb-1">Bill To</div>
          <div className="font-semibold text-foreground">{invoice.customerName}</div>
        </div>

        {/* Line Items */}
        <div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-border">
                <th className="py-2 text-left text-muted-foreground font-medium">Service</th>
                <th className="py-2 text-right text-muted-foreground font-medium w-20">Qty</th>
                <th className="py-2 text-right text-muted-foreground font-medium w-28">Rate</th>
                <th className="py-2 text-right text-muted-foreground font-medium w-28">Total</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.lineItems ?? []).map((item, i) => (
                <tr key={i} className="border-b border-border/50">
                  <td className="py-3 text-foreground">{item.service}</td>
                  <td className="py-3 text-right text-muted-foreground">{item.quantity}</td>
                  <td className="py-3 text-right text-muted-foreground">{formatCurrency(item.rate)}</td>
                  <td className="py-3 text-right text-foreground font-medium">{formatCurrency(item.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex justify-end mt-4">
            <div className="w-48">
              <div className="flex justify-between py-2 border-t-2 border-border">
                <span className="font-bold text-foreground">Total Due</span>
                <span className="font-bold text-green-400 text-lg">{formatCurrency(invoice.totalAmount)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="text-sm text-muted-foreground">Status: <span className="font-medium text-foreground capitalize">{invoice.status}</span></div>
          <div className="text-xs text-muted-foreground">Thank you for your business.</div>
        </div>
      </div>
    </div>
  );
}
