import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { FACILITY_LABELS } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface Customer { id: number; name: string; facilityType: string; address: string; contactName: string; contactPhone: string; contactEmail: string | null; inspectionFrequency: string; isActive: boolean; }
const BLANK = { name: "", facilityType: "commercial", address: "", contactName: "", contactPhone: "", contactEmail: "", inspectionFrequency: "annual", isActive: true };

export default function Customers() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(BLANK);
  const [editId, setEditId] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  const { data: customers = [], isLoading } = useQuery<Customer[]>({ queryKey: ["customers"], queryFn: () => apiFetch("/customers") });

  const save = useMutation({
    mutationFn: async () => {
      if (editId) return apiFetch(`/customers/${editId}`, { method: "PUT", body: JSON.stringify(form) });
      return apiFetch("/customers", { method: "POST", body: JSON.stringify(form) });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["customers"] }); setOpen(false); toast({ title: editId ? "Customer updated" : "Customer added" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const del = useMutation({
    mutationFn: (id: number) => apiFetch(`/customers/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["customers"] }); toast({ title: "Customer removed" }); },
  });

  function openCreate() { setForm(BLANK); setEditId(null); setOpen(true); }
  function openEdit(c: Customer) { setForm({ name: c.name, facilityType: c.facilityType, address: c.address, contactName: c.contactName, contactPhone: c.contactPhone, contactEmail: c.contactEmail ?? "", inspectionFrequency: c.inspectionFrequency, isActive: c.isActive }); setEditId(c.id); setOpen(true); }

  const filtered = customers.filter(c => c.name.toLowerCase().includes(search.toLowerCase()) || c.address.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-foreground">Customers</h1><p className="text-sm text-muted-foreground">Manage client accounts and pricing</p></div>
        <Button onClick={openCreate}>+ Add Customer</Button>
      </div>
      <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search customers..." className="max-w-xs" />

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.length === 0 && <div className="col-span-3 text-center text-muted-foreground py-8">No customers yet. Add your first client.</div>}
          {filtered.map(c => (
            <div key={c.id} className="rounded-xl border border-border bg-card p-4 hover:border-primary/50 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <button onClick={() => setLocation(`/customers/${c.id}`)} className="font-semibold text-primary hover:underline text-left">{c.name}</button>
                <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{FACILITY_LABELS[c.facilityType] ?? c.facilityType}</span>
              </div>
              <div className="text-xs text-muted-foreground space-y-1">
                <div>📍 {c.address}</div>
                <div>👤 {c.contactName} · {c.contactPhone}</div>
                <div>🗓️ {c.inspectionFrequency.charAt(0).toUpperCase() + c.inspectionFrequency.slice(1)} inspection</div>
              </div>
              <div className="flex gap-2 mt-3">
                <button onClick={() => openEdit(c)} className="text-xs text-muted-foreground hover:text-foreground">Edit</button>
                <button onClick={() => del.mutate(c.id)} className="text-xs text-muted-foreground hover:text-destructive">Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "Edit Customer" : "Add Customer"}</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><label className="text-xs text-muted-foreground uppercase">Company Name</label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div><label className="text-xs text-muted-foreground uppercase">Facility Type</label>
              <Select value={form.facilityType} onValueChange={v => setForm(f => ({ ...f, facilityType: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(FACILITY_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Address</label><Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground uppercase">Contact Name</label><Input value={form.contactName} onChange={e => setForm(f => ({ ...f, contactName: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground uppercase">Phone</label><Input value={form.contactPhone} onChange={e => setForm(f => ({ ...f, contactPhone: e.target.value }))} /></div>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Email (optional)</label><Input type="email" value={form.contactEmail} onChange={e => setForm(f => ({ ...f, contactEmail: e.target.value }))} /></div>
            <div><label className="text-xs text-muted-foreground uppercase">Inspection Frequency</label>
              <Select value={form.inspectionFrequency} onValueChange={v => setForm(f => ({ ...f, inspectionFrequency: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual</SelectItem>
                  <SelectItem value="semi-annual">Semi-Annual</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => save.mutate()} disabled={!form.name || save.isPending}>{save.isPending ? "Saving..." : "Save"}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
