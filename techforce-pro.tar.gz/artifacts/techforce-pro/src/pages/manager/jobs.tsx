import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, getStatusColor, STATUS_ICONS, SERVICE_LABELS, CERT_LABELS } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface Job { id: number; customerId: number; employeeId: number | null; serviceType: string; status: string; priority: string; scheduledDate: string | null; scheduledTime: string | null; revenue: number; quantity: number; notes: string | null; requiresFollowUp: boolean; followUpConfirmed: boolean; certificationRequired: string; customerName: string; employeeName: string | null; }
interface Customer { id: number; name: string; }
interface Employee { id: number; name: string; certifications: string[]; }

const STATUSES = ["pending", "in_progress", "completed", "return", "will_return", "reschedule", "emergency", "private", "drop_off"];
const BLANK = { customerId: 0, employeeId: null as number | null, serviceType: "extinguisher_inspection", status: "pending", priority: "medium", scheduledDate: "", scheduledTime: "", quantity: 1, notes: "", certificationRequired: "any" };

export default function Jobs() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(BLANK);
  const [editId, setEditId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: jobs = [], isLoading } = useQuery<Job[]>({ queryKey: ["jobs"], queryFn: () => apiFetch("/jobs") });
  const { data: customers = [] } = useQuery<Customer[]>({ queryKey: ["customers"], queryFn: () => apiFetch("/customers") });
  const { data: employees = [] } = useQuery<Employee[]>({ queryKey: ["employees"], queryFn: () => apiFetch("/employees") });

  const save = useMutation({
    mutationFn: async () => {
      const payload = { ...form, customerId: Number(form.customerId), employeeId: form.employeeId ? Number(form.employeeId) : undefined, scheduledDate: form.scheduledDate || undefined, scheduledTime: form.scheduledTime || undefined, notes: form.notes || undefined };
      if (editId) return apiFetch(`/jobs/${editId}`, { method: "PUT", body: JSON.stringify(payload) });
      return apiFetch("/jobs", { method: "POST", body: JSON.stringify(payload) });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["jobs"] }); setOpen(false); toast({ title: "Job saved" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => apiFetch(`/jobs/${id}`, { method: "PUT", body: JSON.stringify({ status }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["jobs"] }); toast({ title: "Status updated" }); },
  });

  const confirmFollowup = useMutation({
    mutationFn: (id: number) => apiFetch(`/jobs/${id}/confirm-followup`, { method: "POST" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["jobs"] }); toast({ title: "Follow-up confirmed" }); },
  });

  const del = useMutation({
    mutationFn: (id: number) => apiFetch(`/jobs/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["jobs"] }); toast({ title: "Job removed" }); },
  });

  function openCreate() { setForm(BLANK); setEditId(null); setOpen(true); }
  function openEdit(j: Job) { setForm({ customerId: j.customerId, employeeId: j.employeeId, serviceType: j.serviceType, status: j.status, priority: j.priority, scheduledDate: j.scheduledDate ?? "", scheduledTime: j.scheduledTime ?? "", quantity: j.quantity, notes: j.notes ?? "", certificationRequired: j.certificationRequired }); setEditId(j.id); setOpen(true); }

  const filtered = statusFilter === "all" ? jobs : jobs.filter(j => j.status === statusFilter);

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-foreground">Jobs</h1><p className="text-sm text-muted-foreground">All scheduled and pending work orders</p></div>
        <Button onClick={openCreate}>+ Add Job</Button>
      </div>

      <div className="flex gap-2 flex-wrap">
        {["all", ...STATUSES].map(s => (
          <button key={s} onClick={() => setStatusFilter(s)} className={`px-3 py-1 rounded-full text-xs border transition-colors ${statusFilter === s ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"}`}>
            {s === "all" ? "All" : `${STATUS_ICONS[s] ?? ""} ${s.replace(/_/g, " ")}`}
          </button>
        ))}
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Customer", "Service", "Technician", "Date", "Status", "Revenue", ""].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs text-muted-foreground font-medium uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && <tr><td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">No jobs match this filter.</td></tr>}
              {filtered.map(job => (
                <tr key={job.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{job.customerName}</td>
                  <td className="px-4 py-3 text-muted-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType}</td>
                  <td className="px-4 py-3 text-muted-foreground">{job.employeeName ?? <span className="text-amber-400 text-xs">Unassigned</span>}</td>
                  <td className="px-4 py-3 text-muted-foreground">{job.scheduledDate ?? "TBD"}</td>
                  <td className="px-4 py-3">
                    <Select value={job.status} onValueChange={v => updateStatus.mutate({ id: job.id, status: v })}>
                      <SelectTrigger className={`h-7 text-xs w-36 border ${getStatusColor(job.status)}`}><SelectValue /></SelectTrigger>
                      <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_ICONS[s] ?? ""} {s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                    </Select>
                    {job.requiresFollowUp && !job.followUpConfirmed && (
                      <button onClick={() => confirmFollowup.mutate(job.id)} className="mt-1 text-xs text-amber-400 hover:text-amber-300 block">⚠️ Confirm follow-up</button>
                    )}
                  </td>
                  <td className="px-4 py-3 text-green-400">{formatCurrency(job.revenue)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => openEdit(job)} className="text-xs text-muted-foreground hover:text-foreground">Edit</button>
                      <button onClick={() => del.mutate(job.id)} className="text-xs text-muted-foreground hover:text-destructive">Del</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "Edit Job" : "Add Job"}</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><label className="text-xs text-muted-foreground uppercase">Customer</label>
              <Select value={String(form.customerId)} onValueChange={v => setForm(f => ({ ...f, customerId: Number(v) }))}>
                <SelectTrigger><SelectValue placeholder="Select customer..." /></SelectTrigger>
                <SelectContent>{customers.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Service Type</label>
              <Select value={form.serviceType} onValueChange={v => setForm(f => ({ ...f, serviceType: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(SERVICE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Assign Technician</label>
              <Select value={form.employeeId ? String(form.employeeId) : "none"} onValueChange={v => setForm(f => ({ ...f, employeeId: v === "none" ? null : Number(v) }))}>
                <SelectTrigger><SelectValue placeholder="Unassigned" /></SelectTrigger>
                <SelectContent><SelectItem value="none">Unassigned</SelectItem>{employees.map(e => <SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground uppercase">Date</label><Input type="date" value={form.scheduledDate} onChange={e => setForm(f => ({ ...f, scheduledDate: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground uppercase">Time</label><Input type="time" value={form.scheduledTime} onChange={e => setForm(f => ({ ...f, scheduledTime: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground uppercase">Priority</label>
                <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="high">🔴 High</SelectItem><SelectItem value="medium">🟡 Medium</SelectItem><SelectItem value="low">🟢 Low</SelectItem></SelectContent>
                </Select>
              </div>
              <div><label className="text-xs text-muted-foreground uppercase">Quantity</label><Input type="number" value={form.quantity} min={1} onChange={e => setForm(f => ({ ...f, quantity: Number(e.target.value) }))} /></div>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Cert Required</label>
              <Select value={form.certificationRequired} onValueChange={v => setForm(f => ({ ...f, certificationRequired: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(CERT_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-xs text-muted-foreground uppercase">Notes</label><Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Optional notes..." /></div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={() => save.mutate()} disabled={!form.customerId || save.isPending}>{save.isPending ? "Saving..." : "Save"}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
