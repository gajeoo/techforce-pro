import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, getStatusColor, STATUS_ICONS, SERVICE_LABELS } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Job { id: number; customerName: string; serviceType: string; status: string; scheduledDate: string | null; revenue: number; notes: string | null; requiresFollowUp: boolean; followUpConfirmed: boolean; employeeName: string | null; }
const STATUSES = ["pending", "in_progress", "completed", "return", "will_return", "reschedule", "emergency"];

export default function Reschedules() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: jobs = [], isLoading } = useQuery<Job[]>({ queryKey: ["reschedules"], queryFn: () => apiFetch("/jobs/reschedules") });
  const [newDates, setNewDates] = useState<Record<number, string>>({});

  const confirmFollowup = useMutation({
    mutationFn: (id: number) => apiFetch(`/jobs/${id}/confirm-followup`, { method: "POST" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["reschedules"] }); toast({ title: "Follow-up confirmed" }); },
  });

  const reschedule = useMutation({
    mutationFn: ({ id, date }: { id: number; date: string }) => apiFetch(`/jobs/${id}`, { method: "PUT", body: JSON.stringify({ scheduledDate: date, status: "pending" }) }),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["reschedules"] });
      qc.invalidateQueries({ queryKey: ["jobs"] });
      setNewDates(d => { const n = { ...d }; delete n[vars.id]; return n; });
      toast({ title: "Job rescheduled" });
    },
  });

  return (
    <div className="p-6 space-y-4 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">📅 Reschedule Queue</h1>
        <p className="text-sm text-muted-foreground">Jobs needing a new date. Confirm follow-ups before rescheduling.</p>
      </div>

      {isLoading ? <div className="text-muted-foreground">Loading...</div> : jobs.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center text-muted-foreground">
          <div className="text-4xl mb-2">✅</div>
          <div className="font-medium">No reschedules pending!</div>
        </div>
      ) : (
        <div className="space-y-3">
          {jobs.map(job => {
            const canReschedule = !job.requiresFollowUp || job.followUpConfirmed;
            return (
              <div key={job.id} className="rounded-xl border border-purple-500/30 bg-card p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-foreground">{job.customerName}</span>
                      <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(job.status)}`}>{STATUS_ICONS[job.status]} reschedule</span>
                    </div>
                    <div className="text-sm text-muted-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType} · Previously: {job.scheduledDate ?? "no date"} · {job.employeeName ?? "Unassigned"}</div>
                    {job.notes && <div className="text-xs text-muted-foreground mt-1 italic">"{job.notes}"</div>}
                    {!job.followUpConfirmed && job.requiresFollowUp && (
                      <div className="mt-2 flex items-center gap-2">
                        <span className="text-xs text-amber-400">⚠️ Must confirm follow-up before rescheduling</span>
                        <button onClick={() => confirmFollowup.mutate(job.id)} className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 hover:bg-amber-500/30 transition-colors">Confirm</button>
                      </div>
                    )}
                    {canReschedule && (
                      <div className="mt-3 flex items-center gap-2">
                        <Input type="date" value={newDates[job.id] ?? ""} onChange={e => setNewDates(d => ({ ...d, [job.id]: e.target.value }))} className="h-8 text-sm w-40" />
                        <button onClick={() => reschedule.mutate({ id: job.id, date: newDates[job.id] })} disabled={!newDates[job.id]} className="text-xs px-3 py-1.5 rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 transition-colors">Reschedule</button>
                      </div>
                    )}
                  </div>
                  <div className="text-green-400 font-medium">{formatCurrency(job.revenue)}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
