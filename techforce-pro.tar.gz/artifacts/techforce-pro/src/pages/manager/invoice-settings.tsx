import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";

interface Template { id: number; companyName: string; address: string; phone: string; logoUrl: string | null; }

export default function InvoiceSettings() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: template, isLoading } = useQuery<Template>({ queryKey: ["invoice-template"], queryFn: () => apiFetch("/invoice-template") });
  const [form, setForm] = useState({ companyName: "", address: "", phone: "", logoUrl: "" });

  useEffect(() => {
    if (template) setForm({ companyName: template.companyName, address: template.address, phone: template.phone, logoUrl: template.logoUrl ?? "" });
  }, [template]);

  const save = useMutation({
    mutationFn: () => apiFetch("/invoice-template", { method: "PUT", body: JSON.stringify({ ...form, logoUrl: form.logoUrl || null }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["invoice-template"] }); toast({ title: "Invoice template saved ✓" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  if (isLoading) return <div className="p-6 text-muted-foreground">Loading...</div>;

  return (
    <div className="p-6 space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">⚙️ Invoice Settings</h1>
        <p className="text-sm text-muted-foreground">Customize your invoice header — appears on all generated invoices</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 space-y-4">
        <h3 className="font-semibold text-foreground">Company Branding</h3>
        <div><label className="text-xs text-muted-foreground uppercase block mb-1">Company Name</label><Input value={form.companyName} onChange={e => setForm(f => ({ ...f, companyName: e.target.value }))} /></div>
        <div><label className="text-xs text-muted-foreground uppercase block mb-1">Address</label><Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} /></div>
        <div><label className="text-xs text-muted-foreground uppercase block mb-1">Phone</label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
        <div><label className="text-xs text-muted-foreground uppercase block mb-1">Logo URL (optional)</label><Input value={form.logoUrl} onChange={e => setForm(f => ({ ...f, logoUrl: e.target.value }))} placeholder="https://..." /></div>
        <Button onClick={() => save.mutate()} disabled={save.isPending}>{save.isPending ? "Saving..." : "Save Template"}</Button>
      </div>

      {/* Live Preview */}
      <div className="rounded-xl border border-border bg-card p-6 space-y-4">
        <h3 className="font-semibold text-foreground mb-4">Preview</h3>
        <div className="rounded-lg border border-border/50 p-6 bg-background">
          <div className="flex items-start justify-between">
            <div>
              {form.logoUrl && <img src={form.logoUrl} alt="Logo" className="h-12 mb-2 object-contain" />}
              <div className="text-lg font-bold text-foreground">{form.companyName || "Company Name"}</div>
              <div className="text-sm text-muted-foreground">{form.address || "Address"}</div>
              <div className="text-sm text-muted-foreground">{form.phone || "Phone"}</div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-primary">INVOICE</div>
              <div className="font-mono text-foreground mt-1">MC-2025-0001</div>
              <div className="text-sm text-muted-foreground">Date: {new Date().toLocaleDateString()}</div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-border/50">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-border"><th className="text-left text-muted-foreground py-1">Service</th><th className="text-right text-muted-foreground py-1">Qty</th><th className="text-right text-muted-foreground py-1">Rate</th><th className="text-right text-muted-foreground py-1">Total</th></tr></thead>
              <tbody>
                <tr className="border-b border-border/50"><td className="py-2 text-foreground">Extinguisher Inspection</td><td className="py-2 text-right text-muted-foreground">5</td><td className="py-2 text-right text-muted-foreground">{formatCurrency(45)}</td><td className="py-2 text-right text-foreground">{formatCurrency(225)}</td></tr>
              </tbody>
            </table>
            <div className="flex justify-end mt-3"><div className="text-right"><div className="font-bold text-foreground">Total: <span className="text-green-400">{formatCurrency(225)}</span></div></div></div>
          </div>
        </div>
      </div>
    </div>
  );
}
