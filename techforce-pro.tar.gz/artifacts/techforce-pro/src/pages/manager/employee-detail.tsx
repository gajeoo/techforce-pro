import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, ROLE_LABELS, getStatusColor, STATUS_ICONS } from "@/lib/utils";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";

interface Employee {
  id: number; name: string; role: string; salary: number; billableRate: number;
  homeZip: string; certifications: string[]; allowedShopDays: number; shopDaysUsedYtd: number;
  utilizationPct: number; isActive: boolean;
}
interface Job { id: number; serviceType: string; status: string; scheduledDate: string | null; revenue: number; customerName: string; }

export default function EmployeeDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { data: employee } = useQuery<Employee>({ queryKey: ["employee", id], queryFn: () => apiFetch(`/employees/${id}`) });
  const { data: schedule = [] } = useQuery<Job[]>({ queryKey: ["employee-schedule", id], queryFn: () => apiFetch(`/employees/${id}/schedule`) });

  if (!employee) return <div className="p-6 text-muted-foreground">Loading...</div>;

  const dailyCost = (employee.salary * 1.3 + 10000) / 260;
  const shopDayCost = dailyCost * employee.shopDaysUsedYtd;

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-3">
        <Button variant="outline" onClick={() => setLocation("/employees")}>← Back</Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{employee.name}</h1>
          <p className="text-sm text-muted-foreground">{ROLE_LABELS[employee.role] ?? employee.role}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="stat-card"><div className="stat-label">Annual Salary</div><div className="stat-value">{formatCurrency(employee.salary)}</div></div>
        <div className="stat-card"><div className="stat-label">Bill Rate</div><div className="stat-value">${employee.billableRate}/hr</div></div>
        <div className="stat-card"><div className="stat-label">Shop Days YTD</div><div className="stat-value text-amber-400">{employee.shopDaysUsedYtd}/{employee.allowedShopDays}</div></div>
        <div className="stat-card"><div className="stat-label">Shop Day Cost YTD</div><div className="stat-value text-red-400">{formatCurrency(shopDayCost)}</div></div>
      </div>

      <div className="stat-card">
        <div className="text-sm font-medium text-muted-foreground mb-2">Profit Engine Formula</div>
        <div className="text-xs text-muted-foreground font-mono bg-muted/30 p-3 rounded-lg">
          Daily Cost = (${employee.salary.toLocaleString()} × 1.3 + $10,000) ÷ 260 = <span className="text-amber-400">{formatCurrency(dailyCost)}/day</span><br />
          Allowed Shop Days: <span className="text-blue-400">{employee.allowedShopDays} days/yr</span><br />
          Max Annual Shop Cost: <span className="text-red-400">{formatCurrency(dailyCost * employee.allowedShopDays)}</span>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">Job Schedule</h3></div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              {["Date", "Customer", "Service", "Status", "Revenue"].map(h => (
                <th key={h} className="px-4 py-2 text-left text-xs text-muted-foreground font-medium uppercase">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {schedule.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No jobs scheduled yet</td></tr>}
            {schedule.map(job => (
              <tr key={job.id} className="border-b border-border/50">
                <td className="px-4 py-3 text-muted-foreground">{job.scheduledDate ?? "TBD"}</td>
                <td className="px-4 py-3 text-foreground">{job.customerName}</td>
                <td className="px-4 py-3 text-muted-foreground capitalize">{job.serviceType.replace(/_/g, " ")}</td>
                <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(job.status)}`}>{STATUS_ICONS[job.status]} {job.status.replace(/_/g, " ")}</span></td>
                <td className="px-4 py-3 text-green-400">{formatCurrency(job.revenue)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
