import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { formatCurrency, getStatusColor, STATUS_ICONS, SERVICE_LABELS } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Job { id: number; customerName: string; serviceType: string; status: string; scheduledDate: string | null; revenue: number; notes: string | null; requiresFollowUp: boolean; followUpConfirmed: boolean; employeeName: string | null; priority: string; }

const STATUSES = ["pending", "in_progress", "completed", "return", "will_return", "reschedule", "emergency"];

export default function SupervisorDashboard() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: jobs = [], isLoading } = useQuery<Job[]>({ queryKey: ["jobs"], queryFn: () => apiFetch("/jobs") });
  const { data: returns = [] } = useQuery<Job[]>({ queryKey: ["returns"], queryFn: () => apiFetch("/jobs/returns") });
  const { data: reschedules = [] } = useQuery<Job[]>({ queryKey: ["reschedules"], queryFn: () => apiFetch("/jobs/reschedules") });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => apiFetch(`/jobs/${id}`, { method: "PUT", body: JSON.stringify({ status }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["jobs"] }); qc.invalidateQueries({ queryKey: ["returns"] }); qc.invalidateQueries({ queryKey: ["reschedules"] }); toast({ title: "Status updated" }); },
  });

  const confirmFollowup = useMutation({
    mutationFn: (id: number) => apiFetch(`/jobs/${id}/confirm-followup`, { method: "POST" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["returns"] }); toast({ title: "Follow-up confirmed ✓" }); },
  });

  const todayStr = new Date().toISOString().split("T")[0];
  const todaysJobs = jobs.filter(j => j.scheduledDate === todayStr);
  const activeJobs = jobs.filter(j => j.status === "in_progress");

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-foreground">🦺 Supervisor Dashboard</h1>
        <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="stat-card"><div className="stat-label">Today's Jobs</div><div className="stat-value">{todaysJobs.length}</div></div>
        <div className="stat-card"><div className="stat-label">In Progress</div><div className="stat-value text-blue-400">{activeJobs.length}</div></div>
        <div className="stat-card"><div className="stat-label">Returns</div><div className="stat-value text-amber-400">{returns.length}</div></div>
        <div className="stat-card"><div className="stat-label">Reschedules</div><div className="stat-value text-purple-400">{reschedules.length}</div></div>
      </div>

      {/* Today's Jobs */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">Today's Schedule</h3></div>
        {isLoading ? <div className="px-4 py-6 text-muted-foreground">Loading...</div> : todaysJobs.length === 0 ? (
          <div className="px-4 py-8 text-center text-muted-foreground">No jobs scheduled today</div>
        ) : todaysJobs.map(job => (
          <div key={job.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
            <div className="flex-1">
              <div className="font-medium text-sm text-foreground">{job.customerName}</div>
              <div className="text-xs text-muted-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType} · {job.employeeName ?? "Unassigned"}</div>
            </div>
            <div className="text-sm text-green-400">{formatCurrency(job.revenue)}</div>
            <Select value={job.status} onValueChange={v => updateStatus.mutate({ id: job.id, status: v })}>
              <SelectTrigger className={`h-7 text-xs w-36 border ${getStatusColor(job.status)}`}><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_ICONS[s] ?? ""} {s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        ))}
      </div>

      {/* Returns */}
      {returns.length > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">🔄 Returns Needing Attention</h3></div>
          {returns.map(job => (
            <div key={job.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
              <div className="flex-1">
                <div className="font-medium text-sm text-foreground">{job.customerName}</div>
                <div className="text-xs text-muted-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType} · {job.scheduledDate ?? "TBD"}</div>
                {job.requiresFollowUp && !job.followUpConfirmed && (
                  <button onClick={() => confirmFollowup.mutate(job.id)} className="text-xs mt-1 text-amber-400 hover:text-amber-300">⚠️ Confirm follow-up</button>
                )}
              </div>
              <Select value={job.status} onValueChange={v => updateStatus.mutate({ id: job.id, status: v })}>
                <SelectTrigger className={`h-7 text-xs w-36 border ${getStatusColor(job.status)}`}><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_ICONS[s] ?? ""} {s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
