import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { getStatusColor, STATUS_ICONS, SERVICE_LABELS, formatCurrency } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

interface Job { id: number; serviceType: string; status: string; scheduledDate: string | null; revenue: number; notes: string | null; }
interface Invoice { id: number; invoiceNumber: string; totalAmount: number; status: string; generatedAt: string; }
interface Customer { id: number; name: string; address: string; contactName: string; contactPhone: string; inspectionFrequency: string; }

export default function ClientPortal() {
  const { selectedCustomerId } = useAuth();
  const { data: customer } = useQuery<Customer>({ queryKey: ["customer-portal", selectedCustomerId], queryFn: () => apiFetch(`/customers/${selectedCustomerId}`), enabled: !!selectedCustomerId });
  const { data: jobs = [] } = useQuery<Job[]>({ queryKey: ["customer-jobs-portal", selectedCustomerId], queryFn: () => apiFetch(`/customers/${selectedCustomerId}/jobs`), enabled: !!selectedCustomerId });
  const { data: invoices = [] } = useQuery<Invoice[]>({ queryKey: ["customer-invoices-portal", selectedCustomerId], queryFn: () => apiFetch(`/customers/${selectedCustomerId}/invoices`), enabled: !!selectedCustomerId });

  const upcomingJobs = jobs.filter(j => j.status !== "completed").sort((a, b) => (a.scheduledDate ?? "").localeCompare(b.scheduledDate ?? ""));
  const completedJobs = jobs.filter(j => j.status === "completed");
  const openInvoices = invoices.filter(i => i.status === "sent" || i.status === "overdue");
  const totalPaid = invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.totalAmount, 0);

  if (!selectedCustomerId) return <div className="p-6 text-muted-foreground">No account selected. Please log in again.</div>;

  return (
    <div className="p-6 space-y-6 max-w-3xl mx-auto">
      <div>
        <div className="text-4xl mb-2">🏢</div>
        <h1 className="text-2xl font-bold text-foreground">{customer?.name ?? "Your Portal"}</h1>
        <p className="text-sm text-muted-foreground">{customer?.address}</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="stat-card"><div className="stat-label">Upcoming Jobs</div><div className="stat-value text-blue-400">{upcomingJobs.length}</div></div>
        <div className="stat-card"><div className="stat-label">Open Invoices</div><div className="stat-value text-amber-400">{openInvoices.length}</div></div>
        <div className="stat-card"><div className="stat-label">Paid YTD</div><div className="stat-value text-green-400">{formatCurrency(totalPaid)}</div></div>
      </div>

      {/* Upcoming Jobs */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">Upcoming Service Visits</h3></div>
        {upcomingJobs.length === 0 ? (
          <div className="px-4 py-8 text-center text-muted-foreground text-sm">No upcoming visits scheduled</div>
        ) : upcomingJobs.map(job => (
          <div key={job.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
            <div className="flex-1">
              <div className="font-medium text-sm text-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType}</div>
              <div className="text-xs text-muted-foreground">{job.scheduledDate ? `Scheduled: ${job.scheduledDate}` : "Date TBD"}</div>
            </div>
            <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(job.status)}`}>{STATUS_ICONS[job.status]} {job.status.replace(/_/g, " ")}</span>
          </div>
        ))}
      </div>

      {/* Open Invoices */}
      {openInvoices.length > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-card overflow-hidden">
          <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">⚠️ Outstanding Invoices</h3></div>
          {openInvoices.map(inv => (
            <div key={inv.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4">
              <div className="flex-1">
                <div className="font-mono text-sm font-medium text-foreground">{inv.invoiceNumber}</div>
                <div className="text-xs text-muted-foreground">{new Date(inv.generatedAt).toLocaleDateString()}</div>
              </div>
              <div className="text-amber-400 font-semibold">{formatCurrency(inv.totalAmount)}</div>
              <span className={`px-2 py-0.5 rounded text-xs border ${getStatusColor(inv.status)}`}>{inv.status}</span>
            </div>
          ))}
        </div>
      )}

      {/* Service History */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border"><h3 className="font-semibold text-foreground">Service History</h3></div>
        {completedJobs.length === 0 ? (
          <div className="px-4 py-8 text-center text-muted-foreground text-sm">No completed services yet</div>
        ) : completedJobs.map(job => (
          <div key={job.id} className="px-4 py-3 border-b border-border/50 flex items-center gap-4 opacity-75">
            <div className="flex-1">
              <div className="font-medium text-sm text-foreground">{SERVICE_LABELS[job.serviceType] ?? job.serviceType}</div>
              <div className="text-xs text-muted-foreground">{job.scheduledDate ?? "No date"}</div>
            </div>
            <span className="text-xs text-green-400">✅ Completed</span>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="font-semibold text-sm text-foreground mb-1">Your Contact</h3>
        <div className="text-sm text-muted-foreground">📞 Multicorp Fire Protection Services — (410) 876-5000</div>
        <div className="text-sm text-muted-foreground">📍 9693 Gerwig Lane, Columbia, MD 21046</div>
      </div>
    </div>
  );
}
