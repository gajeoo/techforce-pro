import { Router, type IRouter } from "express";
import healthRouter from "./health";
import employeesRouter from "./employees";
import customersRouter from "./customers";
import jobsRouter from "./jobs";
import openJobsRouter from "./open-jobs";
import schedulesRouter from "./schedules";
import timeOffRouter from "./timeoff";
import invoicesRouter from "./invoices";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(employeesRouter);
router.use(customersRouter);
router.use(jobsRouter);
router.use(openJobsRouter);
router.use(schedulesRouter);
router.use(timeOffRouter);
router.use(invoicesRouter);

export default router;
