import { Router } from "express";
import { db } from "@workspace/db";
import { timeOffRequestsTable, employeesTable, jobsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { CreateTimeOffRequestBody, ReviewTimeOffRequestParams, ReviewTimeOffRequestBody } from "@workspace/api-zod";

const router = Router();

router.get("/time-off", async (req, res) => {
  const requests = await db.select().from(timeOffRequestsTable).orderBy(timeOffRequestsTable.createdAt);
  const employees = await db.select().from(employeesTable);
  const employeeMap = Object.fromEntries(employees.map(e => [e.id, e]));
  res.json(requests.map(r => ({ ...r, employeeName: employeeMap[r.employeeId]?.name ?? "Unknown" })));
});

router.post("/time-off", async (req, res) => {
  const body = CreateTimeOffRequestBody.parse(req.body);
  const [employee] = await db.select().from(employeesTable).where(eq(employeesTable.id, body.employeeId));
  if (!employee) return res.status(404).json({ error: "Employee not found" });

  // Auto-approve/deny logic
  let status = "approved";
  let denialReason: string | null = null;

  // Rule 1: Check shop day limit (90% threshold)
  const usedPct = employee.allowedShopDays > 0 ? employee.shopDaysUsedYtd / employee.allowedShopDays : 1;
  if (usedPct >= 0.9) {
    status = "denied";
    denialReason = `Shop day limit reached (${employee.shopDaysUsedYtd}/${employee.allowedShopDays} used). No more approved until next year.`;
  }

  // Rule 2: Check utilization below 85%
  if (status === "approved" && Number(employee.utilizationPct) < 85) {
    status = "denied";
    denialReason = `Utilization at ${employee.utilizationPct}% — below 85% threshold. Must be billable.`;
  }

  // Rule 3: Check if scheduled for a billable job on that date
  if (status === "approved") {
    const conflictJobs = await db.select().from(jobsTable).where(
      and(eq(jobsTable.employeeId, body.employeeId), eq(jobsTable.scheduledDate, body.requestedDate))
    );
    const billableConflicts = conflictJobs.filter(j => j.status !== "completed");
    if (billableConflicts.length > 0) {
      const job = billableConflicts[0];
      status = "denied";
      denialReason = `Scheduled for $${Number(job.revenue).toLocaleString()} job on this date. Revenue beats bench time.`;
    }
  }

  // If approved, increment shop days used
  if (status === "approved") {
    await db.update(employeesTable).set({ shopDaysUsedYtd: employee.shopDaysUsedYtd + 1 }).where(eq(employeesTable.id, body.employeeId));
  }

  const [request] = await db.insert(timeOffRequestsTable).values({
    employeeId: body.employeeId,
    requestedDate: body.requestedDate,
    status,
    denialReason,
  }).returning();

  res.status(201).json({ ...request, employeeName: employee.name });
});

router.post("/time-off/:id/review", async (req, res) => {
  const { id } = ReviewTimeOffRequestParams.parse({ id: Number(req.params.id) });
  const body = ReviewTimeOffRequestBody.parse(req.body);
  const [request] = await db.update(timeOffRequestsTable).set({
    status: body.status,
    denialReason: body.denialReason ?? null,
  }).where(eq(timeOffRequestsTable.id, id)).returning();
  if (!request) return res.status(404).json({ error: "Request not found" });
  const [employee] = await db.select().from(employeesTable).where(eq(employeesTable.id, request.employeeId));
  res.json({ ...request, employeeName: employee?.name ?? "Unknown" });
});

export default router;
