import { Router } from "express";
import { db } from "@workspace/db";
import { customersTable, customerPricingTable, jobsTable, invoicesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  CreateCustomerBody, UpdateCustomerBody, GetCustomerParams, DeleteCustomerParams,
  GetCustomerPricingParams, UpsertCustomerPricingParams, UpsertCustomerPricingBody,
  GetCustomerJobsParams, GetCustomerInvoicesParams
} from "@workspace/api-zod";

const router = Router();

router.get("/customers", async (req, res) => {
  const customers = await db.select().from(customersTable).orderBy(customersTable.name);
  res.json(customers);
});

router.post("/customers", async (req, res) => {
  const body = CreateCustomerBody.parse(req.body);
  const [customer] = await db.insert(customersTable).values({
    name: body.name,
    facilityType: body.facilityType,
    address: body.address,
    contactName: body.contactName,
    contactPhone: body.contactPhone,
    contactEmail: body.contactEmail ?? null,
    inspectionFrequency: body.inspectionFrequency ?? "annual",
    isActive: body.isActive ?? true,
  }).returning();
  res.status(201).json(customer);
});

router.get("/customers/:id", async (req, res) => {
  const { id } = GetCustomerParams.parse({ id: Number(req.params.id) });
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, id));
  if (!customer) return res.status(404).json({ error: "Customer not found" });
  res.json(customer);
});

router.put("/customers/:id", async (req, res) => {
  const { id } = GetCustomerParams.parse({ id: Number(req.params.id) });
  const body = UpdateCustomerBody.parse(req.body);
  const [customer] = await db.update(customersTable).set({
    ...(body.name && { name: body.name }),
    ...(body.facilityType && { facilityType: body.facilityType }),
    ...(body.address && { address: body.address }),
    ...(body.contactName && { contactName: body.contactName }),
    ...(body.contactPhone && { contactPhone: body.contactPhone }),
    ...(body.contactEmail !== undefined && { contactEmail: body.contactEmail ?? null }),
    ...(body.inspectionFrequency && { inspectionFrequency: body.inspectionFrequency }),
    ...(body.isActive !== undefined && { isActive: body.isActive }),
  }).where(eq(customersTable.id, id)).returning();
  if (!customer) return res.status(404).json({ error: "Customer not found" });
  res.json(customer);
});

router.delete("/customers/:id", async (req, res) => {
  const { id } = DeleteCustomerParams.parse({ id: Number(req.params.id) });
  await db.delete(customersTable).where(eq(customersTable.id, id));
  res.status(204).send();
});

router.get("/customers/:id/pricing", async (req, res) => {
  const { id } = GetCustomerPricingParams.parse({ id: Number(req.params.id) });
  const pricing = await db.select().from(customerPricingTable).where(eq(customerPricingTable.customerId, id));
  res.json(pricing.map(p => ({ ...p, customerRate: Number(p.customerRate), standardRate: Number(p.standardRate) })));
});

router.post("/customers/:id/pricing", async (req, res) => {
  const { id } = UpsertCustomerPricingParams.parse({ id: Number(req.params.id) });
  const body = UpsertCustomerPricingBody.parse(req.body);
  const existing = await db.select().from(customerPricingTable).where(
    and(eq(customerPricingTable.customerId, id), eq(customerPricingTable.serviceType, body.serviceType))
  );
  let result;
  if (existing.length > 0) {
    const [updated] = await db.update(customerPricingTable).set({
      customerRate: String(body.customerRate),
      standardRate: String(body.standardRate),
      unit: body.unit,
    }).where(and(eq(customerPricingTable.customerId, id), eq(customerPricingTable.serviceType, body.serviceType))).returning();
    result = updated;
  } else {
    const [created] = await db.insert(customerPricingTable).values({
      customerId: id,
      serviceType: body.serviceType,
      customerRate: String(body.customerRate),
      standardRate: String(body.standardRate),
      unit: body.unit,
    }).returning();
    result = created;
  }
  res.json({ ...result, customerRate: Number(result.customerRate), standardRate: Number(result.standardRate) });
});

router.get("/customers/:id/jobs", async (req, res) => {
  const { id } = GetCustomerJobsParams.parse({ id: Number(req.params.id) });
  const jobs = await db.select().from(jobsTable).where(eq(jobsTable.customerId, id));
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, id));
  res.json(jobs.map(j => ({ ...j, revenue: Number(j.revenue), customerName: customer?.name ?? "Unknown", customerAddress: customer?.address ?? "", employeeName: null, requiresFollowUp: j.requiresFollowUp, followUpConfirmed: j.followUpConfirmed, certificationRequired: j.certificationRequired })));
});

router.get("/customers/:id/invoices", async (req, res) => {
  const { id } = GetCustomerInvoicesParams.parse({ id: Number(req.params.id) });
  const invoices = await db.select().from(invoicesTable).where(eq(invoicesTable.customerId, id));
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, id));
  res.json(invoices.map(i => ({ ...i, totalAmount: Number(i.totalAmount), customerName: customer?.name ?? "Unknown" })));
});

export default router;
