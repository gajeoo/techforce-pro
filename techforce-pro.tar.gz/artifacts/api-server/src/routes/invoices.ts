import { Router } from "express";
import { db } from "@workspace/db";
import { invoicesTable, customersTable, invoiceTemplateTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateInvoiceBody, GetInvoiceParams, UpdateInvoiceParams, UpdateInvoiceBody } from "@workspace/api-zod";

const router = Router();

router.get("/invoices", async (req, res) => {
  const invoices = await db.select().from(invoicesTable).orderBy(invoicesTable.generatedAt);
  const customers = await db.select().from(customersTable);
  const customerMap = Object.fromEntries(customers.map(c => [c.id, c]));
  res.json(invoices.map(i => ({ ...i, totalAmount: Number(i.totalAmount), customerName: customerMap[i.customerId]?.name ?? "Unknown" })));
});

router.post("/invoices", async (req, res) => {
  const body = CreateInvoiceBody.parse(req.body);
  const invoiceNumber = `MC-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000).padStart(4, "0")}`;
  const totalAmount = (body.lineItems ?? []).reduce((sum: number, item: { total: number }) => sum + item.total, 0);
  const [invoice] = await db.insert(invoicesTable).values({
    invoiceNumber,
    customerId: body.customerId,
    jobId: body.jobId ?? null,
    lineItems: body.lineItems ?? [],
    totalAmount: String(totalAmount),
    status: body.status ?? "draft",
  }).returning();
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, body.customerId));
  res.status(201).json({ ...invoice, totalAmount: Number(invoice.totalAmount), customerName: customer?.name ?? "Unknown" });
});

router.get("/invoices/:id", async (req, res) => {
  const { id } = GetInvoiceParams.parse({ id: Number(req.params.id) });
  const [invoice] = await db.select().from(invoicesTable).where(eq(invoicesTable.id, id));
  if (!invoice) return res.status(404).json({ error: "Invoice not found" });
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, invoice.customerId));
  res.json({ ...invoice, totalAmount: Number(invoice.totalAmount), customerName: customer?.name ?? "Unknown" });
});

router.put("/invoices/:id", async (req, res) => {
  const { id } = UpdateInvoiceParams.parse({ id: Number(req.params.id) });
  const body = UpdateInvoiceBody.parse(req.body);
  const [invoice] = await db.update(invoicesTable).set({ status: body.status }).where(eq(invoicesTable.id, id)).returning();
  if (!invoice) return res.status(404).json({ error: "Invoice not found" });
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, invoice.customerId));
  res.json({ ...invoice, totalAmount: Number(invoice.totalAmount), customerName: customer?.name ?? "Unknown" });
});

// Invoice template
router.get("/invoice-template", async (req, res) => {
  const [template] = await db.select().from(invoiceTemplateTable);
  if (!template) {
    const [created] = await db.insert(invoiceTemplateTable).values({
      companyName: "Multicorp Fire Protection Services",
      address: "9693 Gerwig Lane, Columbia, MD 21046",
      phone: "(410) 876-5000",
    }).returning();
    return res.json(created);
  }
  res.json(template);
});

router.put("/invoice-template", async (req, res) => {
  const [existing] = await db.select().from(invoiceTemplateTable);
  if (existing) {
    const [updated] = await db.update(invoiceTemplateTable).set({
      companyName: req.body.companyName ?? existing.companyName,
      address: req.body.address ?? existing.address,
      phone: req.body.phone ?? existing.phone,
      logoUrl: req.body.logoUrl ?? existing.logoUrl,
      updatedAt: new Date(),
    }).where(eq(invoiceTemplateTable.id, existing.id)).returning();
    return res.json(updated);
  }
  const [created] = await db.insert(invoiceTemplateTable).values({
    companyName: req.body.companyName ?? "Multicorp Fire Protection Services",
    address: req.body.address ?? "9693 Gerwig Lane, Columbia, MD 21046",
    phone: req.body.phone ?? "(410) 876-5000",
    logoUrl: req.body.logoUrl ?? null,
  }).returning();
  res.json(created);
});

export default router;
