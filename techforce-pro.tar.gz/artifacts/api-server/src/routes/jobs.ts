import { Router } from "express";
import { db } from "@workspace/db";
import { jobsTable, customersTable, employeesTable, invoicesTable } from "@workspace/db";
import { eq, and, or } from "drizzle-orm";
import {
  CreateJobBody, UpdateJobBody, GetJobParams, DeleteJobParams, ConfirmJobFollowupParams, ListJobsQueryParams
} from "@workspace/api-zod";

const router = Router();

async function enrichJob(job: typeof jobsTable.$inferSelect) {
  const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, job.customerId));
  let employeeName: string | null = null;
  if (job.employeeId) {
    const [emp] = await db.select().from(employeesTable).where(eq(employeesTable.id, job.employeeId));
    employeeName = emp?.name ?? null;
  }
  return {
    ...job,
    revenue: Number(job.revenue),
    customerName: customer?.name ?? "Unknown",
    customerAddress: customer?.address ?? "",
    employeeName,
    requiresFollowUp: job.requiresFollowUp,
    followUpConfirmed: job.followUpConfirmed,
    certificationRequired: job.certificationRequired,
  };
}

router.get("/jobs", async (req, res) => {
  const query = ListJobsQueryParams.parse(req.query);
  let jobs = await db.select().from(jobsTable).orderBy(jobsTable.scheduledDate);
  if (query.status) jobs = jobs.filter(j => j.status === query.status);
  if (query.employeeId) jobs = jobs.filter(j => j.employeeId === Number(query.employeeId));
  if (query.date) jobs = jobs.filter(j => j.scheduledDate === query.date);
  const customers = await db.select().from(customersTable);
  const employees = await db.select().from(employeesTable);
  const customerMap = Object.fromEntries(customers.map(c => [c.id, c]));
  const employeeMap = Object.fromEntries(employees.map(e => [e.id, e]));
  res.json(jobs.map(j => ({
    ...j,
    revenue: Number(j.revenue),
    customerName: customerMap[j.customerId]?.name ?? "Unknown",
    customerAddress: customerMap[j.customerId]?.address ?? "",
    employeeName: j.employeeId ? (employeeMap[j.employeeId]?.name ?? null) : null,
    requiresFollowUp: j.requiresFollowUp,
    followUpConfirmed: j.followUpConfirmed,
    certificationRequired: j.certificationRequired,
  })));
});

router.post("/jobs", async (req, res) => {
  const body = CreateJobBody.parse(req.body);
  // Auto-calc revenue from customer pricing if possible
  let revenue = 0;
  const { customerPricingTable } = await import("@workspace/db");
  const pricing = await db.select().from(customerPricingTable).where(
    and(eq(customerPricingTable.customerId, body.customerId), eq(customerPricingTable.serviceType, body.serviceType))
  );
  if (pricing.length > 0) {
    revenue = Number(pricing[0].customerRate) * body.quantity;
  }
  const [job] = await db.insert(jobsTable).values({
    customerId: body.customerId,
    employeeId: body.employeeId ?? null,
    serviceType: body.serviceType,
    status: body.status ?? "pending",
    priority: body.priority,
    scheduledDate: body.scheduledDate ?? null,
    scheduledTime: body.scheduledTime ?? null,
    revenue: String(revenue),
    quantity: body.quantity,
    notes: body.notes ?? null,
    requiresFollowUp: false,
    followUpConfirmed: false,
    certificationRequired: body.certificationRequired,
  }).returning();
  res.status(201).json(await enrichJob(job));
});

router.get("/jobs/returns", async (req, res) => {
  const jobs = await db.select().from(jobsTable).where(
    or(eq(jobsTable.status, "return"), eq(jobsTable.status, "will_return"))
  );
  const customers = await db.select().from(customersTable);
  const employees = await db.select().from(employeesTable);
  const customerMap = Object.fromEntries(customers.map(c => [c.id, c]));
  const employeeMap = Object.fromEntries(employees.map(e => [e.id, e]));
  res.json(jobs.map(j => ({
    ...j,
    revenue: Number(j.revenue),
    customerName: customerMap[j.customerId]?.name ?? "Unknown",
    customerAddress: customerMap[j.customerId]?.address ?? "",
    employeeName: j.employeeId ? (employeeMap[j.employeeId]?.name ?? null) : null,
    requiresFollowUp: j.requiresFollowUp,
    followUpConfirmed: j.followUpConfirmed,
    certificationRequired: j.certificationRequired,
  })));
});

router.get("/jobs/reschedules", async (req, res) => {
  const jobs = await db.select().from(jobsTable).where(eq(jobsTable.status, "reschedule"));
  const customers = await db.select().from(customersTable);
  const employees = await db.select().from(employeesTable);
  const customerMap = Object.fromEntries(customers.map(c => [c.id, c]));
  const employeeMap = Object.fromEntries(employees.map(e => [e.id, e]));
  res.json(jobs.map(j => ({
    ...j,
    revenue: Number(j.revenue),
    customerName: customerMap[j.customerId]?.name ?? "Unknown",
    customerAddress: customerMap[j.customerId]?.address ?? "",
    employeeName: j.employeeId ? (employeeMap[j.employeeId]?.name ?? null) : null,
    requiresFollowUp: j.requiresFollowUp,
    followUpConfirmed: j.followUpConfirmed,
    certificationRequired: j.certificationRequired,
  })));
});

router.get("/jobs/:id", async (req, res) => {
  const { id } = GetJobParams.parse({ id: Number(req.params.id) });
  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, id));
  if (!job) return res.status(404).json({ error: "Job not found" });
  res.json(await enrichJob(job));
});

router.put("/jobs/:id", async (req, res) => {
  const { id } = GetJobParams.parse({ id: Number(req.params.id) });
  const body = UpdateJobBody.parse(req.body);
  const [existing] = await db.select().from(jobsTable).where(eq(jobsTable.id, id));
  if (!existing) return res.status(404).json({ error: "Job not found" });

  const updates: Partial<typeof jobsTable.$inferInsert> = {};
  if (body.employeeId !== undefined) updates.employeeId = body.employeeId ?? null;
  if (body.status !== undefined) {
    updates.status = body.status;
    // If changing to completed, increment employee shop day counter if it was a shop day
    if (body.status === "completed" && existing.employeeId) {
      // Auto-generate invoice if completed
      const { customerPricingTable } = await import("@workspace/db");
      const [customer] = await db.select().from(customersTable).where(eq(customersTable.id, existing.customerId));
      if (customer) {
        const lineItems = [{
          service: existing.serviceType.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase()),
          quantity: existing.quantity,
          rate: Number(existing.revenue) / existing.quantity,
          total: Number(existing.revenue),
        }];
        const invoiceNumber = `MC-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000).padStart(4, "0")}`;
        await db.insert(invoicesTable).values({
          invoiceNumber,
          customerId: existing.customerId,
          jobId: id,
          lineItems,
          totalAmount: String(existing.revenue),
          status: "draft",
        });
      }
    }
  }
  if (body.scheduledDate !== undefined) updates.scheduledDate = body.scheduledDate ?? null;
  if (body.scheduledTime !== undefined) updates.scheduledTime = body.scheduledTime ?? null;
  if (body.notes !== undefined) updates.notes = body.notes ?? null;
  if (body.requiresFollowUp !== undefined) updates.requiresFollowUp = body.requiresFollowUp;

  const [job] = await db.update(jobsTable).set(updates).where(eq(jobsTable.id, id)).returning();
  res.json(await enrichJob(job));
});

router.delete("/jobs/:id", async (req, res) => {
  const { id } = DeleteJobParams.parse({ id: Number(req.params.id) });
  await db.delete(jobsTable).where(eq(jobsTable.id, id));
  res.status(204).send();
});

router.post("/jobs/:id/confirm-followup", async (req, res) => {
  const { id } = ConfirmJobFollowupParams.parse({ id: Number(req.params.id) });
  const [job] = await db.update(jobsTable).set({ followUpConfirmed: true }).where(eq(jobsTable.id, id)).returning();
  if (!job) return res.status(404).json({ error: "Job not found" });
  res.json(await enrichJob(job));
});

export default router;
