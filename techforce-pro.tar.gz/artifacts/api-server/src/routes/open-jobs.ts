import { Router } from "express";
import { db } from "@workspace/db";
import { openJobsTable, employeesTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { CreateOpenJobBody, UpdateOpenJobParams, UpdateOpenJobBody, DeleteOpenJobParams } from "@workspace/api-zod";

const router = Router();

const PRIORITY_ORDER: Record<string, number> = { high: 0, medium: 1, low: 2 };

router.get("/open-jobs", async (req, res) => {
  const jobs = await db.select().from(openJobsTable);
  const employees = await db.select().from(employeesTable);
  const employeeMap = Object.fromEntries(employees.map(e => [e.id, e]));
  const sorted = jobs.sort((a, b) => (PRIORITY_ORDER[a.priority] ?? 1) - (PRIORITY_ORDER[b.priority] ?? 1));
  res.json(sorted.map(j => ({
    ...j,
    assignedEmployeeName: j.assignedEmployeeId ? (employeeMap[j.assignedEmployeeId]?.name ?? null) : null,
  })));
});

router.post("/open-jobs", async (req, res) => {
  const body = CreateOpenJobBody.parse(req.body);
  const [job] = await db.insert(openJobsTable).values({
    title: body.title,
    clientName: body.clientName,
    certRequired: body.certRequired,
    priority: body.priority,
    notes: body.notes ?? null,
  }).returning();
  res.status(201).json({ ...job, assignedEmployeeName: null });
});

router.put("/open-jobs/:id", async (req, res) => {
  const { id } = UpdateOpenJobParams.parse({ id: Number(req.params.id) });
  const body = UpdateOpenJobBody.parse(req.body);
  const [job] = await db.update(openJobsTable).set({
    ...(body.title && { title: body.title }),
    ...(body.clientName && { clientName: body.clientName }),
    ...(body.certRequired && { certRequired: body.certRequired }),
    ...(body.priority && { priority: body.priority }),
    ...(body.notes !== undefined && { notes: body.notes ?? null }),
  }).where(eq(openJobsTable.id, id)).returning();
  if (!job) return res.status(404).json({ error: "Open job not found" });
  res.json({ ...job, assignedEmployeeName: null });
});

router.delete("/open-jobs/:id", async (req, res) => {
  const { id } = DeleteOpenJobParams.parse({ id: Number(req.params.id) });
  await db.delete(openJobsTable).where(eq(openJobsTable.id, id));
  res.status(204).send();
});

export default router;
