import { Router } from "express";
import { db } from "@workspace/db";
import { employeesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateEmployeeBody, UpdateEmployeeBody, GetEmployeeParams, DeleteEmployeeParams, GetEmployeeScheduleParams, GetEmployeeScheduleQueryParams } from "@workspace/api-zod";
import { jobsTable } from "@workspace/db";
import { and } from "drizzle-orm";

const router = Router();

function calcAllowedShopDays(role: string, salary: number): number {
  const dailyCost = (salary * 1.3 + 10000) / 260;
  if (role === "suppression_lead") return 2;
  if (role === "sprinkler_tech") return 3;
  if (role === "extinguisher_tech") return 5;
  if (role === "helper") return 12;
  return 0;
}

router.get("/employees", async (req, res) => {
  const employees = await db.select().from(employeesTable).orderBy(employeesTable.name);
  res.json(employees.map(e => ({ ...e, salary: Number(e.salary), billableRate: Number(e.billableRate), utilizationPct: Number(e.utilizationPct) })));
});

router.post("/employees", async (req, res) => {
  const body = CreateEmployeeBody.parse(req.body);
  const allowedShopDays = calcAllowedShopDays(body.role, body.salary as number);
  const [employee] = await db.insert(employeesTable).values({
    name: body.name,
    role: body.role,
    salary: String(body.salary),
    billableRate: String(body.billableRate),
    homeZip: body.homeZip,
    certifications: body.certifications ?? [],
    allowedShopDays,
    shopDaysUsedYtd: 0,
    utilizationPct: "0",
    isActive: body.isActive ?? true,
  }).returning();
  res.status(201).json({ ...employee, salary: Number(employee.salary), billableRate: Number(employee.billableRate), utilizationPct: Number(employee.utilizationPct) });
});

router.get("/employees/:id", async (req, res) => {
  const { id } = GetEmployeeParams.parse({ id: Number(req.params.id) });
  const [employee] = await db.select().from(employeesTable).where(eq(employeesTable.id, id));
  if (!employee) return res.status(404).json({ error: "Employee not found" });
  res.json({ ...employee, salary: Number(employee.salary), billableRate: Number(employee.billableRate), utilizationPct: Number(employee.utilizationPct) });
});

router.put("/employees/:id", async (req, res) => {
  const { id } = GetEmployeeParams.parse({ id: Number(req.params.id) });
  const body = UpdateEmployeeBody.parse(req.body);
  const allowedShopDays = body.role && body.salary ? calcAllowedShopDays(body.role, body.salary as number) : undefined;
  const [employee] = await db.update(employeesTable).set({
    ...(body.name && { name: body.name }),
    ...(body.role && { role: body.role }),
    ...(body.salary !== undefined && { salary: String(body.salary) }),
    ...(body.billableRate !== undefined && { billableRate: String(body.billableRate) }),
    ...(body.homeZip && { homeZip: body.homeZip }),
    ...(body.certifications && { certifications: body.certifications }),
    ...(allowedShopDays !== undefined && { allowedShopDays }),
    ...(body.isActive !== undefined && { isActive: body.isActive }),
  }).where(eq(employeesTable.id, id)).returning();
  if (!employee) return res.status(404).json({ error: "Employee not found" });
  res.json({ ...employee, salary: Number(employee.salary), billableRate: Number(employee.billableRate), utilizationPct: Number(employee.utilizationPct) });
});

router.delete("/employees/:id", async (req, res) => {
  const { id } = DeleteEmployeeParams.parse({ id: Number(req.params.id) });
  await db.delete(employeesTable).where(eq(employeesTable.id, id));
  res.status(204).send();
});

router.get("/employees/:id/schedule", async (req, res) => {
  const { id } = GetEmployeeScheduleParams.parse({ id: Number(req.params.id) });
  const { date } = GetEmployeeScheduleQueryParams.parse(req.query);
  let query = db.select().from(jobsTable).where(eq(jobsTable.employeeId, id));
  const jobs = await db.select().from(jobsTable).where(
    date ? and(eq(jobsTable.employeeId, id), eq(jobsTable.scheduledDate, date as string)) : eq(jobsTable.employeeId, id)
  );
  // Fetch customer names
  const { customersTable } = await import("@workspace/db");
  const customers = await db.select().from(customersTable);
  const customerMap = Object.fromEntries(customers.map(c => [c.id, c]));
  const { employeesTable: empTable } = await import("@workspace/db");
  const [emp] = await db.select().from(empTable).where(eq(empTable.id, id));
  res.json(jobs.map(j => ({
    ...j,
    revenue: Number(j.revenue),
    customerName: customerMap[j.customerId]?.name ?? "Unknown",
    customerAddress: customerMap[j.customerId]?.address ?? "",
    employeeName: emp?.name ?? null,
    requiresFollowUp: j.requiresFollowUp,
    followUpConfirmed: j.followUpConfirmed,
    certificationRequired: j.certificationRequired,
  })));
});

export default router;
