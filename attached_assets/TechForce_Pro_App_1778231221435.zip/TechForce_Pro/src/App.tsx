import { Navigate, Route, Routes } from "react-router-dom";
import { AppLayout } from "./components/AppLayout";
import ErrorBoundary from "./components/ErrorBoundary";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { PublicLayout } from "./components/PublicLayout";
import { PublicOnlyRoute } from "./components/PublicOnlyRoute";
import { Toaster } from "./components/ui/sonner";
import { ThemeProvider } from "./contexts/ThemeContext";
import {
  CatalogPage,
  CustomerDetailPage,
  CustomerPortalPage,
  CustomersPage,
  DashboardPage,
  EmployeesPage,
  JobDetailPage,
  JobsPage,
  LandingPage,
  LoginPage,
  PricingPage,
  ReportsPage,
  SchedulePage,
  SettingsPage,
  ShopDayCalculatorPage,
  SignupPage,
  SupervisorPortalPage,
  TechPortalPage,
  GPSTrackingPage,
} from "./pages";

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <Toaster />
        <Routes>
          <Route element={<PublicLayout />}>
            <Route path="/" element={<LandingPage />} />
            <Route element={<PublicOnlyRoute />}>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
            </Route>
          </Route>

          <Route element={<ProtectedRoute />}>
            <Route element={<AppLayout />}>
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/schedule" element={<SchedulePage />} />
              <Route path="/employees" element={<EmployeesPage />} />
              <Route path="/jobs" element={<JobsPage />} />
              <Route path="/jobs/:id" element={<JobDetailPage />} />
              <Route path="/customers" element={<CustomersPage />} />
              <Route path="/customers/:id" element={<CustomerDetailPage />} />
              <Route path="/catalogs" element={<CatalogPage />} />
              <Route path="/shop-calculator" element={<ShopDayCalculatorPage />} />
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/pricing" element={<PricingPage />} />
              <Route path="/tech-portal" element={<TechPortalPage />} />
              <Route path="/supervisor" element={<SupervisorPortalPage />} />
              <Route path="/customer-portal" element={<CustomerPortalPage />} />
              <Route path="/gps-tracking" element={<GPSTrackingPage />} />
              <Route path="/settings" element={<SettingsPage />} />
            </Route>
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
