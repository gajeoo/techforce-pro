// ─── Mock data for Multicorp Fire Protection Services ───────────────────
// TechForce Pro — Full production demo data

// ─── Types ──────────────────────────────────────────────────────────────

export type Employee = {
  id: string;
  name: string;
  role: string;
  certs: string[];
  salary: number;
  billRate: number;
  utilization: number;
  shopDaysUsed: number;
  shopDaysAllowed: number;
  revenueYTD: number;
  revenueThisMonth: number;
  status: "active" | "on-job" | "shop" | "off";
  avatar: string;
  phone: string;
  hireDate: string;
  shopDayHistory: number[]; // last 6 months used
};

export type JobDocument = {
  id: string;
  name: string;
  type: "photo" | "pdf" | "document";
  uploadedBy: string;
  uploadedAt: string;
  size: string;
};

export type Job = {
  id: string;
  client: string;
  customerId: string;
  locationId?: string;
  address: string;
  type: string;
  serviceCategory: "suppression" | "extinguisher" | "sprinkler" | "exit-light" | "mixed";
  certRequired: string;
  revenue: number;
  status: "completed" | "in-progress" | "pending" | "return" | "reschedule" | "emergency";
  techId: string;
  techName: string;
  scheduledDate: string;
  scheduledTime: string;
  dueDate: string;
  priority: "high" | "medium" | "low";
  statusIcon: string;
  notes?: string;
  documents: JobDocument[];
};

export type WeekSchedule = {
  techId: string;
  techName: string;
  cert: string;
  days: { label: string; value: string; type: "billable" | "shop" | "training" | "off" | "open" }[];
};

export type CustomerLocation = {
  id: string;
  name: string;
  address: string;
  isPrimary: boolean;
};

export type Customer = {
  id: string;
  name: string;
  type: string;
  contact: string;
  phone: string;
  extinguisher: string;
  suppression: string;
  sprinkler: string;
  exitLight: string;
  jobCount: number;
  revenueYTD: number;
  lastService: string;
  contractStatus: "active" | "expiring" | "pending";
  locations: CustomerLocation[];
};

// ─── Employees ──────────────────────────────────────────────────────────

export const employees: Employee[] = [
  {
    id: "1", name: "Sarah Johnson", role: "Suppression Lead", certs: ["Suppression", "Extinguisher"],
    salary: 85000, billRate: 1600, utilization: 98, shopDaysUsed: 1, shopDaysAllowed: 2,
    revenueYTD: 140000, revenueThisMonth: 28000, status: "on-job", avatar: "SJ",
    phone: "(410) 555-0101", hireDate: "2019-03-15",
    shopDayHistory: [1, 2, 1, 2, 1, 1],
  },
  {
    id: "2", name: "Derek Williams", role: "Sprinkler Tech", certs: ["Sprinkler"],
    salary: 70000, billRate: 1200, utilization: 91, shopDaysUsed: 2, shopDaysAllowed: 3,
    revenueYTD: 108000, revenueThisMonth: 19200, status: "on-job", avatar: "DW",
    phone: "(410) 555-0102", hireDate: "2020-07-22",
    shopDayHistory: [3, 2, 3, 3, 2, 2],
  },
  {
    id: "3", name: "Marcus Taylor", role: "Extinguisher Tech", certs: ["Extinguisher"],
    salary: 55000, billRate: 900, utilization: 87, shopDaysUsed: 4, shopDaysAllowed: 5,
    revenueYTD: 81000, revenueThisMonth: 14400, status: "active", avatar: "MT",
    phone: "(410) 555-0103", hireDate: "2021-01-10",
    shopDayHistory: [5, 4, 5, 4, 5, 4],
  },
  {
    id: "4", name: "James Rodriguez", role: "Helper / Apprentice", certs: ["Extinguisher"],
    salary: 40000, billRate: 500, utilization: 78, shopDaysUsed: 10, shopDaysAllowed: 12,
    revenueYTD: 41000, revenueThisMonth: 7500, status: "shop", avatar: "JR",
    phone: "(410) 555-0104", hireDate: "2024-09-01",
    shopDayHistory: [12, 11, 10, 11, 12, 10],
  },
  {
    id: "5", name: "Kevin Park", role: "Extinguisher Tech", certs: ["Extinguisher", "Exit Lights"],
    salary: 55000, billRate: 900, utilization: 92, shopDaysUsed: 3, shopDaysAllowed: 5,
    revenueYTD: 86400, revenueThisMonth: 14400, status: "on-job", avatar: "KP",
    phone: "(410) 555-0105", hireDate: "2022-04-18",
    shopDayHistory: [4, 3, 5, 3, 4, 3],
  },
  {
    id: "6", name: "Angela Davis", role: "Suppression Tech", certs: ["Suppression"],
    salary: 75000, billRate: 1400, utilization: 94, shopDaysUsed: 1, shopDaysAllowed: 2,
    revenueYTD: 126000, revenueThisMonth: 25200, status: "active", avatar: "AD",
    phone: "(410) 555-0106", hireDate: "2020-11-03",
    shopDayHistory: [2, 1, 2, 1, 2, 1],
  },
];

// ─── Today's Jobs ───────────────────────────────────────────────────────

export const todayJobs: Job[] = [
  {
    id: "J-1001", client: "Olive Garden — Columbia", customerId: "C-6", locationId: "C-6-L1",
    address: "6100 Dobbin Rd, Columbia, MD 21045",
    type: "Hood Suppression Inspection", serviceCategory: "suppression", certRequired: "Suppression", revenue: 1400,
    status: "completed", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-06-10", scheduledTime: "7:30 AM", dueDate: "2026-06-15", priority: "high", statusIcon: "✅",
    documents: [
      { id: "D-1", name: "hood_photo_before.jpg", type: "photo", uploadedBy: "Sarah Johnson", uploadedAt: "2026-06-10", size: "2.3 MB" },
      { id: "D-2", name: "inspection_report.pdf", type: "pdf", uploadedBy: "Sarah Johnson", uploadedAt: "2026-06-10", size: "340 KB" },
    ],
  },
  {
    id: "J-1002", client: "Lincoln Elementary", customerId: "C-2", locationId: "C-2-L1",
    address: "890 School Ave, Baltimore, MD 21228",
    type: "Extinguisher Inspection (x24)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 600,
    status: "return", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-06-10", scheduledTime: "8:00 AM", dueDate: "2026-06-12", priority: "medium", statusIcon: "🔄",
    notes: "18 of 24 done, 6 remaining",
    documents: [
      { id: "D-3", name: "ext_tags_photo.jpg", type: "photo", uploadedBy: "Marcus Taylor", uploadedAt: "2026-06-10", size: "1.8 MB" },
    ],
  },
  {
    id: "J-1003", client: "Metro Office Park", customerId: "C-3", locationId: "C-3-L1",
    address: "456 Commerce Dr, Columbia, MD 21046",
    type: "Sprinkler Annual Test", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 1200,
    status: "reschedule", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-06-10", scheduledTime: "8:00 AM", dueDate: "2026-06-20", priority: "high", statusIcon: "📅",
    notes: "No building access — reschedule with property mgr",
    documents: [],
  },
  {
    id: "J-1004", client: "Harbor Condos", customerId: "C-5", locationId: "C-5-L1",
    address: "100 Harbor Way, Baltimore, MD 21230",
    type: "Exit Light Inspection (x20)", serviceCategory: "exit-light", certRequired: "Exit Lights", revenue: 200,
    status: "in-progress", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-06-10", scheduledTime: "9:00 AM", dueDate: "2026-06-15", priority: "medium", statusIcon: "🔧",
    documents: [],
  },
  {
    id: "J-1005", client: "ABC Restaurant", customerId: "C-1", locationId: "C-1-L1",
    address: "2345 Main St, Columbia, MD 21044",
    type: "Hood Suppression Service", serviceCategory: "suppression", certRequired: "Suppression", revenue: 1400,
    status: "pending", techId: "6", techName: "Angela Davis",
    scheduledDate: "2026-06-10", scheduledTime: "10:00 AM", dueDate: "2026-06-10", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-1006", client: "Sunrise Group Home", customerId: "C-4", locationId: "C-4-L1",
    address: "78 Elm St, Essex, MD 21221",
    type: "Extinguisher + Exit Lights", serviceCategory: "mixed", certRequired: "Extinguisher", revenue: 420,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-06-10", scheduledTime: "1:00 PM", dueDate: "2026-06-14", priority: "low", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-1007", client: "Chipotle — Rt 1", customerId: "C-8", locationId: "C-8-L1",
    address: "8775 Baltimore National Pike, Ellicott City, MD",
    type: "Hood Suppression Check", serviceCategory: "suppression", certRequired: "Suppression", revenue: 500,
    status: "pending", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-06-10", scheduledTime: "1:30 PM", dueDate: "2026-06-10", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-1008", client: "Patapsco High School", customerId: "C-10", locationId: "C-10-L1",
    address: "8100 Wise Ave, Dundalk, MD 21222",
    type: "Extinguisher Round (x12)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 300,
    status: "completed", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-06-10", scheduledTime: "12:00 PM", dueDate: "2026-06-10", priority: "medium", statusIcon: "✅",
    documents: [
      { id: "D-4", name: "completed_checklist.pdf", type: "pdf", uploadedBy: "Marcus Taylor", uploadedAt: "2026-06-10", size: "520 KB" },
    ],
  },
];

// ─── All Customer Jobs (comprehensive list for customer detail) ─────────

export const allCustomerJobs: Job[] = [
  // ABC Restaurant jobs
  ...todayJobs.filter(j => j.customerId === "C-1"),
  {
    id: "J-2001", client: "ABC Restaurant", customerId: "C-1", locationId: "C-1-L1",
    address: "2345 Main St, Columbia, MD 21044",
    type: "Hood Suppression Semi-Annual", serviceCategory: "suppression", certRequired: "Suppression", revenue: 450,
    status: "completed", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-03-15", scheduledTime: "9:00 AM", dueDate: "2026-03-30", priority: "high", statusIcon: "✅",
    documents: [
      { id: "D-10", name: "march_inspection.pdf", type: "pdf", uploadedBy: "Sarah Johnson", uploadedAt: "2026-03-15", size: "450 KB" },
    ],
  },
  {
    id: "J-2002", client: "ABC Restaurant", customerId: "C-1", locationId: "C-1-L1",
    address: "2345 Main St, Columbia, MD 21044",
    type: "Extinguisher Annual (x6)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 210,
    status: "completed", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-04-20", scheduledTime: "8:00 AM", dueDate: "2026-04-30", priority: "medium", statusIcon: "✅",
    documents: [
      { id: "D-11", name: "ext_tags.jpg", type: "photo", uploadedBy: "Marcus Taylor", uploadedAt: "2026-04-20", size: "1.2 MB" },
    ],
  },
  {
    id: "J-2003", client: "ABC Restaurant — Ellicott City", customerId: "C-1", locationId: "C-1-L2",
    address: "8432 Frederick Rd, Ellicott City, MD 21043",
    type: "Hood Suppression Inspection", serviceCategory: "suppression", certRequired: "Suppression", revenue: 500,
    status: "pending", techId: "6", techName: "Angela Davis",
    scheduledDate: "2026-06-18", scheduledTime: "9:00 AM", dueDate: "2026-06-25", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2004", client: "ABC Restaurant — Ellicott City", customerId: "C-1", locationId: "C-1-L2",
    address: "8432 Frederick Rd, Ellicott City, MD 21043",
    type: "Extinguisher Annual (x8)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 280,
    status: "pending", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-06-18", scheduledTime: "10:30 AM", dueDate: "2026-06-25", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2005", client: "ABC Restaurant — Glen Burnie", customerId: "C-1", locationId: "C-1-L3",
    address: "6901 Ritchie Hwy, Glen Burnie, MD 21061",
    type: "Hood Suppression Service", serviceCategory: "suppression", certRequired: "Suppression", revenue: 500,
    status: "pending", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-07-05", scheduledTime: "8:00 AM", dueDate: "2026-07-15", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2006", client: "ABC Restaurant — Glen Burnie", customerId: "C-1", locationId: "C-1-L3",
    address: "6901 Ritchie Hwy, Glen Burnie, MD 21061",
    type: "Extinguisher Annual (x4)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 140,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-07-05", scheduledTime: "10:00 AM", dueDate: "2026-07-15", priority: "low", statusIcon: "⏳",
    documents: [],
  },
  // Lincoln Elementary jobs
  ...todayJobs.filter(j => j.customerId === "C-2"),
  {
    id: "J-2010", client: "Lincoln Elementary", customerId: "C-2", locationId: "C-2-L1",
    address: "890 School Ave, Baltimore, MD 21228",
    type: "Sprinkler Annual Test", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 800,
    status: "completed", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-05-10", scheduledTime: "7:30 AM", dueDate: "2026-05-15", priority: "high", statusIcon: "✅",
    documents: [
      { id: "D-20", name: "sprinkler_flow_report.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2026-05-10", size: "680 KB" },
    ],
  },
  {
    id: "J-2011", client: "Lincoln Elementary — Annex", customerId: "C-2", locationId: "C-2-L2",
    address: "900 School Ave, Baltimore, MD 21228",
    type: "Extinguisher Inspection (x12)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 300,
    status: "pending", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-06-20", scheduledTime: "8:00 AM", dueDate: "2026-06-30", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2012", client: "Lincoln Elementary — Gym", customerId: "C-2", locationId: "C-2-L3",
    address: "910 School Ave, Baltimore, MD 21228",
    type: "Exit Light Inspection (x8)", serviceCategory: "exit-light", certRequired: "Exit Lights", revenue: 96,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-06-20", scheduledTime: "10:00 AM", dueDate: "2026-06-30", priority: "low", statusIcon: "⏳",
    documents: [],
  },
  // Metro Office Park jobs
  ...todayJobs.filter(j => j.customerId === "C-3"),
  {
    id: "J-2020", client: "Metro Office Park — Bldg A", customerId: "C-3", locationId: "C-3-L1",
    address: "456 Commerce Dr, Bldg A, Columbia, MD 21046",
    type: "Sprinkler System Annual", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 1200,
    status: "completed", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-04-22", scheduledTime: "8:00 AM", dueDate: "2026-04-30", priority: "high", statusIcon: "✅",
    documents: [
      { id: "D-30", name: "bldg_a_sprinkler.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2026-04-22", size: "890 KB" },
    ],
  },
  {
    id: "J-2021", client: "Metro Office Park — Bldg B", customerId: "C-3", locationId: "C-3-L2",
    address: "458 Commerce Dr, Bldg B, Columbia, MD 21046",
    type: "Extinguisher Inspection (x16)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 480,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-06-22", scheduledTime: "9:00 AM", dueDate: "2026-06-30", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2022", client: "Metro Office Park — Bldg C", customerId: "C-3", locationId: "C-3-L3",
    address: "460 Commerce Dr, Bldg C, Columbia, MD 21046",
    type: "Sprinkler + Exit Lights", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 1500,
    status: "pending", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-07-10", scheduledTime: "8:00 AM", dueDate: "2026-07-20", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  // Sunrise Group Home
  ...todayJobs.filter(j => j.customerId === "C-4"),
  {
    id: "J-2030", client: "Sunrise Group Home", customerId: "C-4", locationId: "C-4-L1",
    address: "78 Elm St, Essex, MD 21221",
    type: "Suppression Semi-Annual", serviceCategory: "suppression", certRequired: "Suppression", revenue: 350,
    status: "completed", techId: "6", techName: "Angela Davis",
    scheduledDate: "2026-03-12", scheduledTime: "9:00 AM", dueDate: "2026-03-15", priority: "high", statusIcon: "✅",
    documents: [
      { id: "D-40", name: "suppression_report.pdf", type: "pdf", uploadedBy: "Angela Davis", uploadedAt: "2026-03-12", size: "320 KB" },
    ],
  },
  {
    id: "J-2031", client: "Sunrise Group Home — West Wing", customerId: "C-4", locationId: "C-4-L2",
    address: "80 Elm St, Essex, MD 21221",
    type: "Extinguisher Inspection (x10)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 300,
    status: "pending", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-06-25", scheduledTime: "9:00 AM", dueDate: "2026-06-30", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  // Harbor Condos
  ...todayJobs.filter(j => j.customerId === "C-5"),
  {
    id: "J-2040", client: "Harbor Condos — Tower A", customerId: "C-5", locationId: "C-5-L1",
    address: "100 Harbor Way, Tower A, Baltimore, MD 21230",
    type: "Sprinkler Standpipe Test", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 1500,
    status: "pending", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-07-01", scheduledTime: "8:00 AM", dueDate: "2026-07-10", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2041", client: "Harbor Condos — Tower B", customerId: "C-5", locationId: "C-5-L2",
    address: "102 Harbor Way, Tower B, Baltimore, MD 21230",
    type: "Extinguisher Annual (x30)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 840,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-07-01", scheduledTime: "8:00 AM", dueDate: "2026-07-10", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  // Olive Garden
  ...todayJobs.filter(j => j.customerId === "C-6"),
  {
    id: "J-2050", client: "Olive Garden — Columbia", customerId: "C-6", locationId: "C-6-L1",
    address: "6100 Dobbin Rd, Columbia, MD 21045",
    type: "Extinguisher Annual (x8)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 280,
    status: "completed", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-05-20", scheduledTime: "8:00 AM", dueDate: "2026-05-30", priority: "medium", statusIcon: "✅",
    documents: [],
  },
  {
    id: "J-2051", client: "Olive Garden — Towson", customerId: "C-6", locationId: "C-6-L2",
    address: "825 Dulaney Valley Rd, Towson, MD 21204",
    type: "Hood Suppression Inspection", serviceCategory: "suppression", certRequired: "Suppression", revenue: 500,
    status: "pending", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-06-20", scheduledTime: "8:00 AM", dueDate: "2026-06-30", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2052", client: "Olive Garden — Towson", customerId: "C-6", locationId: "C-6-L2",
    address: "825 Dulaney Valley Rd, Towson, MD 21204",
    type: "Extinguisher Annual (x6)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 210,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-06-20", scheduledTime: "10:00 AM", dueDate: "2026-06-30", priority: "low", statusIcon: "⏳",
    documents: [],
  },
  // BCOGov
  {
    id: "J-2060", client: "BCOGov — Glen Arm Main", customerId: "C-7", locationId: "C-7-L1",
    address: "11600 Manor Rd, Glen Arm, MD 21057",
    type: "Sprinkler Annual Test", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 900,
    status: "completed", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-05-05", scheduledTime: "8:00 AM", dueDate: "2026-05-10", priority: "high", statusIcon: "✅",
    documents: [
      { id: "D-60", name: "bcogov_sprinkler_cert.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2026-05-05", size: "1.1 MB" },
    ],
  },
  {
    id: "J-2061", client: "BCOGov — Glen Arm Main", customerId: "C-7", locationId: "C-7-L1",
    address: "11600 Manor Rd, Glen Arm, MD 21057",
    type: "Extinguisher Round (x40)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 880,
    status: "completed", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-05-05", scheduledTime: "8:00 AM", dueDate: "2026-05-10", priority: "medium", statusIcon: "✅",
    documents: [],
  },
  {
    id: "J-2062", client: "BCOGov — Satellite Office", customerId: "C-7", locationId: "C-7-L2",
    address: "205 Washington Ave, Towson, MD 21204",
    type: "Suppression System Check", serviceCategory: "suppression", certRequired: "Suppression", revenue: 600,
    status: "pending", techId: "6", techName: "Angela Davis",
    scheduledDate: "2026-06-28", scheduledTime: "9:00 AM", dueDate: "2026-07-05", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2063", client: "BCOGov — Warehouse", customerId: "C-7", locationId: "C-7-L3",
    address: "4100 Industrial Blvd, Baltimore, MD 21226",
    type: "Extinguisher Inspection (x20)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 440,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-07-02", scheduledTime: "8:00 AM", dueDate: "2026-07-10", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  // Chipotle
  ...todayJobs.filter(j => j.customerId === "C-8"),
  {
    id: "J-2070", client: "Chipotle — Rt 1", customerId: "C-8", locationId: "C-8-L1",
    address: "8775 Baltimore National Pike, Ellicott City, MD",
    type: "Extinguisher Annual (x4)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 140,
    status: "completed", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-04-10", scheduledTime: "8:00 AM", dueDate: "2026-04-15", priority: "low", statusIcon: "✅",
    documents: [],
  },
  {
    id: "J-2071", client: "Chipotle — Columbia", customerId: "C-8", locationId: "C-8-L2",
    address: "10300 Little Patuxent Pkwy, Columbia, MD 21044",
    type: "Hood Suppression Check", serviceCategory: "suppression", certRequired: "Suppression", revenue: 450,
    status: "pending", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-06-22", scheduledTime: "1:00 PM", dueDate: "2026-06-30", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  // Towson Town Center
  {
    id: "J-2080", client: "Towson Town Center — Main", customerId: "C-9", locationId: "C-9-L1",
    address: "825 Dulaney Valley Rd, Towson, MD 21204",
    type: "Sprinkler System Annual", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 1100,
    status: "completed", techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-04-15", scheduledTime: "7:30 AM", dueDate: "2026-04-20", priority: "high", statusIcon: "✅",
    documents: [],
  },
  {
    id: "J-2081", client: "Towson Town Center — Food Court", customerId: "C-9", locationId: "C-9-L2",
    address: "825 Dulaney Valley Rd, Food Court Level, Towson, MD 21204",
    type: "Hood Suppression Inspection (x4)", serviceCategory: "suppression", certRequired: "Suppression", revenue: 1800,
    status: "pending", techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-06-28", scheduledTime: "7:00 AM", dueDate: "2026-07-05", priority: "high", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2082", client: "Towson Town Center — Main", customerId: "C-9", locationId: "C-9-L1",
    address: "825 Dulaney Valley Rd, Towson, MD 21204",
    type: "Extinguisher Round (x24)", serviceCategory: "extinguisher", certRequired: "Extinguisher", revenue: 672,
    status: "pending", techId: "3", techName: "Marcus Taylor",
    scheduledDate: "2026-07-05", scheduledTime: "8:00 AM", dueDate: "2026-07-15", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  // Patapsco High School
  ...todayJobs.filter(j => j.customerId === "C-10"),
  {
    id: "J-2090", client: "Patapsco High School", customerId: "C-10", locationId: "C-10-L1",
    address: "8100 Wise Ave, Dundalk, MD 21222",
    type: "Exit Light Inspection (x30)", serviceCategory: "exit-light", certRequired: "Exit Lights", revenue: 360,
    status: "pending", techId: "5", techName: "Kevin Park",
    scheduledDate: "2026-06-25", scheduledTime: "8:00 AM", dueDate: "2026-06-30", priority: "medium", statusIcon: "⏳",
    documents: [],
  },
  {
    id: "J-2091", client: "Patapsco High School — Gym", customerId: "C-10", locationId: "C-10-L2",
    address: "8100 Wise Ave, Gym Bldg, Dundalk, MD 21222",
    type: "Suppression Check", serviceCategory: "suppression", certRequired: "Suppression", revenue: 400,
    status: "pending", techId: "6", techName: "Angela Davis",
    scheduledDate: "2026-06-25", scheduledTime: "10:00 AM", dueDate: "2026-06-30", priority: "high", statusIcon: "⏳",
    documents: [],
  },
];

// ─── Week Schedule ──────────────────────────────────────────────────────

export const weekSchedule: WeekSchedule[] = [
  {
    techId: "1", techName: "Sarah J.", cert: "SUPP",
    days: [
      { label: "Mon", value: "$1,400", type: "billable" },
      { label: "Tue", value: "$1,900", type: "billable" },
      { label: "Wed", value: "$1,400", type: "billable" },
      { label: "Thu", value: "$1,400", type: "billable" },
      { label: "Fri", value: "$1,400", type: "billable" },
    ],
  },
  {
    techId: "2", techName: "Derek W.", cert: "SPR",
    days: [
      { label: "Mon", value: "$1,200", type: "billable" },
      { label: "Tue", value: "SHOP", type: "shop" },
      { label: "Wed", value: "$1,200", type: "billable" },
      { label: "Thu", value: "$1,200", type: "billable" },
      { label: "Fri", value: "SHOP", type: "shop" },
    ],
  },
  {
    techId: "3", techName: "Marcus T.", cert: "EXT",
    days: [
      { label: "Mon", value: "$900", type: "billable" },
      { label: "Tue", value: "$900", type: "billable" },
      { label: "Wed", value: "Train", type: "training" },
      { label: "Thu", value: "$900", type: "billable" },
      { label: "Fri", value: "$900", type: "billable" },
    ],
  },
  {
    techId: "5", techName: "Kevin P.", cert: "EXT",
    days: [
      { label: "Mon", value: "$900", type: "billable" },
      { label: "Tue", value: "$620", type: "billable" },
      { label: "Wed", value: "$900", type: "billable" },
      { label: "Thu", value: "$900", type: "billable" },
      { label: "Fri", value: "Train", type: "training" },
    ],
  },
  {
    techId: "6", techName: "Angela D.", cert: "SUPP",
    days: [
      { label: "Mon", value: "$1,400", type: "billable" },
      { label: "Tue", value: "$1,400", type: "billable" },
      { label: "Wed", value: "$1,400", type: "billable" },
      { label: "Thu", value: "SHOP", type: "shop" },
      { label: "Fri", value: "$1,400", type: "billable" },
    ],
  },
  {
    techId: "4", techName: "James R.", cert: "EXT",
    days: [
      { label: "Mon", value: "$500", type: "billable" },
      { label: "Tue", value: "SHOP", type: "shop" },
      { label: "Wed", value: "SHOP", type: "shop" },
      { label: "Thu", value: "$500", type: "billable" },
      { label: "Fri", value: "$500", type: "billable" },
    ],
  },
];

// ─── Profit Alerts ──────────────────────────────────────────────────────

export const profitAlerts = [
  { tech: "James R.", message: "Utilization at 78% — below 85% threshold. 10 of 12 shop days used.", severity: "high" as const },
  { tech: "Marcus T.", message: "4 of 5 shop days used — 1 remaining this month", severity: "medium" as const },
  { tech: "Derek W.", message: "2 shop days this week — $2,400 revenue impact", severity: "high" as const },
];

// ─── Open Jobs ──────────────────────────────────────────────────────────

export const openJobs = [
  { id: "OJ-1", job: "Hood Suppression Check", client: "Chipotle — Rt 1", cert: "Suppression", priority: "high" as const, revenue: 500 },
  { id: "OJ-2", job: "Extinguisher Round (x12)", client: "Patapsco HS", cert: "Extinguisher", priority: "medium" as const, revenue: 300 },
  { id: "OJ-3", job: "Truck Inventory Check", client: "Internal", cert: "Any", priority: "low" as const, revenue: 0 },
  { id: "OJ-4", job: "Exit Light Replacement (x8)", client: "Towson Mall", cert: "Exit Lights", priority: "medium" as const, revenue: 240 },
  { id: "OJ-5", job: "Sprinkler Flow Test", client: "Columbia Gateway", cert: "Sprinkler", priority: "high" as const, revenue: 1200 },
];

// ─── Customers ──────────────────────────────────────────────────────────

export const customers: Customer[] = [
  {
    id: "C-1", name: "ABC Restaurant", type: "Restaurant", contact: "Mike Chen", phone: "(410) 555-2001",
    extinguisher: "$35/unit", suppression: "$450", sprinkler: "—", exitLight: "$15/unit",
    jobCount: 12, revenueYTD: 18400, lastService: "2026-06-02", contractStatus: "active",
    locations: [
      { id: "C-1-L1", name: "Main — Columbia", address: "2345 Main St, Columbia, MD 21044", isPrimary: true },
      { id: "C-1-L2", name: "Ellicott City", address: "8432 Frederick Rd, Ellicott City, MD 21043", isPrimary: false },
      { id: "C-1-L3", name: "Glen Burnie", address: "6901 Ritchie Hwy, Glen Burnie, MD 21061", isPrimary: false },
    ],
  },
  {
    id: "C-2", name: "Lincoln Elementary", type: "School", contact: "Principal Davis", phone: "(410) 555-2002",
    extinguisher: "$25/unit", suppression: "—", sprinkler: "$800", exitLight: "$12/unit",
    jobCount: 8, revenueYTD: 12200, lastService: "2026-05-28", contractStatus: "active",
    locations: [
      { id: "C-2-L1", name: "Main Building", address: "890 School Ave, Baltimore, MD 21228", isPrimary: true },
      { id: "C-2-L2", name: "Annex Building", address: "900 School Ave, Baltimore, MD 21228", isPrimary: false },
      { id: "C-2-L3", name: "Gymnasium", address: "910 School Ave, Baltimore, MD 21228", isPrimary: false },
    ],
  },
  {
    id: "C-3", name: "Metro Office Park", type: "Commercial", contact: "Tom Baker", phone: "(410) 555-2003",
    extinguisher: "$30/unit", suppression: "—", sprinkler: "$1,200", exitLight: "$15/unit",
    jobCount: 6, revenueYTD: 15600, lastService: "2026-06-05", contractStatus: "active",
    locations: [
      { id: "C-3-L1", name: "Building A", address: "456 Commerce Dr, Bldg A, Columbia, MD 21046", isPrimary: true },
      { id: "C-3-L2", name: "Building B", address: "458 Commerce Dr, Bldg B, Columbia, MD 21046", isPrimary: false },
      { id: "C-3-L3", name: "Building C", address: "460 Commerce Dr, Bldg C, Columbia, MD 21046", isPrimary: false },
    ],
  },
  {
    id: "C-4", name: "Sunrise Group Home", type: "Group Home", contact: "Lisa Hernandez", phone: "(410) 555-2004",
    extinguisher: "$30/unit", suppression: "$350", sprinkler: "$500", exitLight: "$12/unit",
    jobCount: 4, revenueYTD: 6800, lastService: "2026-06-01", contractStatus: "active",
    locations: [
      { id: "C-4-L1", name: "Main Building", address: "78 Elm St, Essex, MD 21221", isPrimary: true },
      { id: "C-4-L2", name: "West Wing", address: "80 Elm St, Essex, MD 21221", isPrimary: false },
    ],
  },
  {
    id: "C-5", name: "Harbor Condos", type: "Condo", contact: "Board — Jeff Lin", phone: "(410) 555-2005",
    extinguisher: "$28/unit", suppression: "—", sprinkler: "$1,500", exitLight: "$10/unit",
    jobCount: 3, revenueYTD: 8100, lastService: "2026-05-15", contractStatus: "expiring",
    locations: [
      { id: "C-5-L1", name: "Tower A", address: "100 Harbor Way, Tower A, Baltimore, MD 21230", isPrimary: true },
      { id: "C-5-L2", name: "Tower B", address: "102 Harbor Way, Tower B, Baltimore, MD 21230", isPrimary: false },
    ],
  },
  {
    id: "C-6", name: "Olive Garden", type: "Restaurant", contact: "Mgr — Sandra", phone: "(410) 555-2006",
    extinguisher: "$35/unit", suppression: "$500", sprinkler: "—", exitLight: "$15/unit",
    jobCount: 6, revenueYTD: 11200, lastService: "2026-06-10", contractStatus: "active",
    locations: [
      { id: "C-6-L1", name: "Columbia", address: "6100 Dobbin Rd, Columbia, MD 21045", isPrimary: true },
      { id: "C-6-L2", name: "Towson", address: "825 Dulaney Valley Rd, Towson, MD 21204", isPrimary: false },
    ],
  },
  {
    id: "C-7", name: "BCOGov — Glen Arm", type: "Government", contact: "Facilities Dept", phone: "(410) 555-2007",
    extinguisher: "$22/unit", suppression: "—", sprinkler: "$900", exitLight: "$10/unit",
    jobCount: 10, revenueYTD: 22400, lastService: "2026-06-08", contractStatus: "active",
    locations: [
      { id: "C-7-L1", name: "Main Campus", address: "11600 Manor Rd, Glen Arm, MD 21057", isPrimary: true },
      { id: "C-7-L2", name: "Satellite Office", address: "205 Washington Ave, Towson, MD 21204", isPrimary: false },
      { id: "C-7-L3", name: "Warehouse", address: "4100 Industrial Blvd, Baltimore, MD 21226", isPrimary: false },
    ],
  },
  {
    id: "C-8", name: "Chipotle", type: "Restaurant", contact: "Dist. Mgr — Ray", phone: "(410) 555-2008",
    extinguisher: "$35/unit", suppression: "$450", sprinkler: "—", exitLight: "$15/unit",
    jobCount: 4, revenueYTD: 7200, lastService: "2026-05-20", contractStatus: "active",
    locations: [
      { id: "C-8-L1", name: "Rt 1 — Ellicott City", address: "8775 Baltimore National Pike, Ellicott City, MD", isPrimary: true },
      { id: "C-8-L2", name: "Columbia", address: "10300 Little Patuxent Pkwy, Columbia, MD 21044", isPrimary: false },
    ],
  },
  {
    id: "C-9", name: "Towson Town Center", type: "Commercial", contact: "Property Mgmt", phone: "(410) 555-2009",
    extinguisher: "$28/unit", suppression: "$400", sprinkler: "$1,100", exitLight: "$12/unit",
    jobCount: 5, revenueYTD: 14800, lastService: "2026-06-03", contractStatus: "pending",
    locations: [
      { id: "C-9-L1", name: "Main Mall", address: "825 Dulaney Valley Rd, Towson, MD 21204", isPrimary: true },
      { id: "C-9-L2", name: "Food Court Level", address: "825 Dulaney Valley Rd, Food Court Level, Towson, MD 21204", isPrimary: false },
    ],
  },
  {
    id: "C-10", name: "Patapsco High School", type: "School", contact: "Facilities — Mr. Brooks", phone: "(410) 555-2010",
    extinguisher: "$25/unit", suppression: "$400", sprinkler: "$750", exitLight: "$10/unit",
    jobCount: 4, revenueYTD: 8200, lastService: "2026-06-10", contractStatus: "active",
    locations: [
      { id: "C-10-L1", name: "Main Building", address: "8100 Wise Ave, Dundalk, MD 21222", isPrimary: true },
      { id: "C-10-L2", name: "Gymnasium", address: "8100 Wise Ave, Gym Bldg, Dundalk, MD 21222", isPrimary: false },
    ],
  },
];

// ─── Monthly revenue data (for reports) ─────────────────────────────────

export const monthlyRevenue = [
  { month: "Jan", revenue: 82400, cost: 36200, profit: 46200, shopDays: 42 },
  { month: "Feb", revenue: 75800, cost: 36200, profit: 39600, shopDays: 48 },
  { month: "Mar", revenue: 98200, cost: 36200, profit: 62000, shopDays: 35 },
  { month: "Apr", revenue: 91600, cost: 36200, profit: 55400, shopDays: 38 },
  { month: "May", revenue: 104200, cost: 36200, profit: 68000, shopDays: 32 },
  { month: "Jun", revenue: 108700, cost: 36200, profit: 72500, shopDays: 30 },
];

// ─── Return / Reschedule jobs ───────────────────────────────────────────

export const returnJobs: (Job & { notes: string })[] = [
  { ...todayJobs[1], id: "RET-1", notes: "18 of 24 done, 6 remaining. Parts on truck." },
  {
    id: "RET-2", client: "Sunrise Group Home", customerId: "C-4", locationId: "C-4-L1",
    address: "78 Elm St, Essex, MD 21221",
    type: "Sprinkler Head Replacement", serviceCategory: "sprinkler", certRequired: "Sprinkler", revenue: 500,
    status: "return" as const, techId: "2", techName: "Derek Williams",
    scheduledDate: "2026-06-08", scheduledTime: "10:00 AM", dueDate: "2026-06-15", priority: "medium" as const,
    statusIcon: "🔄", notes: "Parts ordered — awaiting delivery. Est. Thursday.",
    documents: [],
  },
];

export const rescheduleJobs: (Job & { notes: string; followUpRequired: boolean; followUpDone: boolean })[] = [
  {
    ...todayJobs[2], id: "RSC-1", notes: "Access denied by building mgmt. Rescheduled with property mgr for June 18.",
    followUpRequired: true, followUpDone: false,
  },
  {
    id: "RSC-2", client: "Willow Creek Condo", customerId: "C-5", locationId: "C-5-L1",
    address: "200 Willow Dr, Columbia, MD 21044",
    type: "Hood Check", serviceCategory: "suppression", certRequired: "Suppression", revenue: 450,
    status: "reschedule" as const, techId: "1", techName: "Sarah Johnson",
    scheduledDate: "2026-06-05", scheduledTime: "9:00 AM", dueDate: "2026-06-15", priority: "medium" as const,
    statusIcon: "📅", notes: "Follow-up confirmed. Ready to reschedule.",
    followUpRequired: true, followUpDone: true,
    documents: [],
  },
];

// ─── Helper to get service category colors ──────────────────────────────

export const serviceCategoryColors: Record<string, { bg: string; text: string; label: string }> = {
  "suppression": { bg: "bg-red-100 dark:bg-red-900/30", text: "text-red-700 dark:text-red-300", label: "Suppression" },
  "extinguisher": { bg: "bg-blue-100 dark:bg-blue-900/30", text: "text-blue-700 dark:text-blue-300", label: "Extinguisher" },
  "sprinkler": { bg: "bg-cyan-100 dark:bg-cyan-900/30", text: "text-cyan-700 dark:text-cyan-300", label: "Sprinkler" },
  "exit-light": { bg: "bg-amber-100 dark:bg-amber-900/30", text: "text-amber-700 dark:text-amber-300", label: "Exit Light" },
  "mixed": { bg: "bg-purple-100 dark:bg-purple-900/30", text: "text-purple-700 dark:text-purple-300", label: "Mixed" },
};

// ─── Previous Year Job History (2025) ───────────────────────────────────
// Shows what was done at each location in the previous year

export type PreviousYearJob = {
  id: string;
  jobId: string;
  client: string;
  customerId: string;
  locationId: string;
  address: string;
  type: string;
  serviceCategory: "suppression" | "extinguisher" | "sprinkler" | "exit-light" | "mixed";
  revenue: number;
  status: "completed" | "incomplete";
  techName: string;
  completedDate: string;
  dueDate: string;
  notes?: string;
  documents: JobDocument[];
};

export const previousYearJobs: PreviousYearJob[] = [
  // ABC Restaurant — 2025
  {
    id: "PY-1001", jobId: "J-PY-1001", client: "ABC Restaurant", customerId: "C-1", locationId: "C-1-L1",
    address: "2345 Main St, Columbia, MD 21044",
    type: "Hood Suppression Semi-Annual", serviceCategory: "suppression", revenue: 420,
    status: "completed", techName: "Sarah Johnson", completedDate: "2025-03-20", dueDate: "2025-03-30",
    documents: [
      { id: "PD-1", name: "2025_march_supp_report.pdf", type: "pdf", uploadedBy: "Sarah Johnson", uploadedAt: "2025-03-20", size: "380 KB" },
    ],
  },
  {
    id: "PY-1002", jobId: "J-PY-1002", client: "ABC Restaurant", customerId: "C-1", locationId: "C-1-L1",
    address: "2345 Main St, Columbia, MD 21044",
    type: "Hood Suppression Semi-Annual", serviceCategory: "suppression", revenue: 420,
    status: "completed", techName: "Sarah Johnson", completedDate: "2025-09-15", dueDate: "2025-09-30",
    documents: [
      { id: "PD-2", name: "2025_sept_supp_report.pdf", type: "pdf", uploadedBy: "Sarah Johnson", uploadedAt: "2025-09-15", size: "410 KB" },
    ],
  },
  {
    id: "PY-1003", jobId: "J-PY-1003", client: "ABC Restaurant", customerId: "C-1", locationId: "C-1-L1",
    address: "2345 Main St, Columbia, MD 21044",
    type: "Extinguisher Annual (x6)", serviceCategory: "extinguisher", revenue: 180,
    status: "completed", techName: "Marcus Taylor", completedDate: "2025-04-10", dueDate: "2025-04-30",
    documents: [
      { id: "PD-3", name: "2025_ext_tags.jpg", type: "photo", uploadedBy: "Marcus Taylor", uploadedAt: "2025-04-10", size: "1.4 MB" },
    ],
  },
  {
    id: "PY-1004", jobId: "J-PY-1004", client: "ABC Restaurant — Ellicott City", customerId: "C-1", locationId: "C-1-L2",
    address: "8432 Frederick Rd, Ellicott City, MD 21043",
    type: "Hood Suppression Inspection", serviceCategory: "suppression", revenue: 450,
    status: "completed", techName: "Angela Davis", completedDate: "2025-06-22", dueDate: "2025-06-30",
    documents: [
      { id: "PD-4", name: "2025_ec_supp_cert.pdf", type: "pdf", uploadedBy: "Angela Davis", uploadedAt: "2025-06-22", size: "520 KB" },
    ],
  },
  // Lincoln Elementary — 2025
  {
    id: "PY-2001", jobId: "J-PY-2001", client: "Lincoln Elementary", customerId: "C-2", locationId: "C-2-L1",
    address: "890 School Ave, Baltimore, MD 21228",
    type: "Sprinkler Annual Test", serviceCategory: "sprinkler", revenue: 750,
    status: "completed", techName: "Derek Williams", completedDate: "2025-05-12", dueDate: "2025-05-15",
    documents: [
      { id: "PD-10", name: "2025_sprinkler_cert.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2025-05-12", size: "720 KB" },
    ],
  },
  {
    id: "PY-2002", jobId: "J-PY-2002", client: "Lincoln Elementary", customerId: "C-2", locationId: "C-2-L1",
    address: "890 School Ave, Baltimore, MD 21228",
    type: "Extinguisher Inspection (x20)", serviceCategory: "extinguisher", revenue: 500,
    status: "completed", techName: "Marcus Taylor", completedDate: "2025-05-12", dueDate: "2025-05-15",
    documents: [],
  },
  // Metro Office Park — 2025
  {
    id: "PY-3001", jobId: "J-PY-3001", client: "Metro Office Park — Bldg A", customerId: "C-3", locationId: "C-3-L1",
    address: "456 Commerce Dr, Bldg A, Columbia, MD 21046",
    type: "Sprinkler System Annual", serviceCategory: "sprinkler", revenue: 1100,
    status: "completed", techName: "Derek Williams", completedDate: "2025-04-20", dueDate: "2025-04-30",
    documents: [
      { id: "PD-20", name: "2025_metro_sprinkler.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2025-04-20", size: "950 KB" },
    ],
  },
  {
    id: "PY-3002", jobId: "J-PY-3002", client: "Metro Office Park — Bldg B", customerId: "C-3", locationId: "C-3-L2",
    address: "458 Commerce Dr, Bldg B, Columbia, MD 21046",
    type: "Extinguisher Inspection (x14)", serviceCategory: "extinguisher", revenue: 420,
    status: "completed", techName: "Kevin Park", completedDate: "2025-04-20", dueDate: "2025-04-30",
    documents: [],
  },
  // Olive Garden — 2025
  {
    id: "PY-6001", jobId: "J-PY-6001", client: "Olive Garden — Columbia", customerId: "C-6", locationId: "C-6-L1",
    address: "6100 Dobbin Rd, Columbia, MD 21045",
    type: "Hood Suppression Inspection", serviceCategory: "suppression", revenue: 480,
    status: "completed", techName: "Sarah Johnson", completedDate: "2025-06-10", dueDate: "2025-06-15",
    documents: [
      { id: "PD-30", name: "2025_og_supp.pdf", type: "pdf", uploadedBy: "Sarah Johnson", uploadedAt: "2025-06-10", size: "400 KB" },
    ],
  },
  {
    id: "PY-6002", jobId: "J-PY-6002", client: "Olive Garden — Columbia", customerId: "C-6", locationId: "C-6-L1",
    address: "6100 Dobbin Rd, Columbia, MD 21045",
    type: "Extinguisher Annual (x8)", serviceCategory: "extinguisher", revenue: 240,
    status: "completed", techName: "Marcus Taylor", completedDate: "2025-06-10", dueDate: "2025-06-30",
    documents: [],
  },
  // Harbor Condos — 2025
  {
    id: "PY-5001", jobId: "J-PY-5001", client: "Harbor Condos — Tower A", customerId: "C-5", locationId: "C-5-L1",
    address: "100 Harbor Way, Tower A, Baltimore, MD 21230",
    type: "Sprinkler Standpipe Test", serviceCategory: "sprinkler", revenue: 1400,
    status: "completed", techName: "Derek Williams", completedDate: "2025-07-08", dueDate: "2025-07-15",
    documents: [
      { id: "PD-40", name: "2025_harbor_sprinkler.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2025-07-08", size: "880 KB" },
    ],
  },
  // BCOGov — 2025
  {
    id: "PY-7001", jobId: "J-PY-7001", client: "BCOGov — Glen Arm Main", customerId: "C-7", locationId: "C-7-L1",
    address: "11600 Manor Rd, Glen Arm, MD 21057",
    type: "Sprinkler Annual Test", serviceCategory: "sprinkler", revenue: 850,
    status: "completed", techName: "Derek Williams", completedDate: "2025-05-08", dueDate: "2025-05-10",
    documents: [
      { id: "PD-50", name: "2025_bcogov_sprinkler.pdf", type: "pdf", uploadedBy: "Derek Williams", uploadedAt: "2025-05-08", size: "1.2 MB" },
    ],
  },
  {
    id: "PY-7002", jobId: "J-PY-7002", client: "BCOGov — Glen Arm Main", customerId: "C-7", locationId: "C-7-L1",
    address: "11600 Manor Rd, Glen Arm, MD 21057",
    type: "Extinguisher Round (x38)", serviceCategory: "extinguisher", revenue: 836,
    status: "completed", techName: "Marcus Taylor", completedDate: "2025-05-08", dueDate: "2025-05-10",
    documents: [],
  },
  // Chipotle — 2025
  {
    id: "PY-8001", jobId: "J-PY-8001", client: "Chipotle — Rt 1", customerId: "C-8", locationId: "C-8-L1",
    address: "8775 Baltimore National Pike, Ellicott City, MD",
    type: "Hood Suppression Check", serviceCategory: "suppression", revenue: 420,
    status: "completed", techName: "Angela Davis", completedDate: "2025-06-15", dueDate: "2025-06-30",
    documents: [
      { id: "PD-60", name: "2025_chipotle_supp.pdf", type: "pdf", uploadedBy: "Angela Davis", uploadedAt: "2025-06-15", size: "350 KB" },
    ],
  },
  // Towson Town Center — 2025
  {
    id: "PY-9001", jobId: "J-PY-9001", client: "Towson Town Center — Main", customerId: "C-9", locationId: "C-9-L1",
    address: "825 Dulaney Valley Rd, Towson, MD 21204",
    type: "Sprinkler System Annual", serviceCategory: "sprinkler", revenue: 1050,
    status: "completed", techName: "Derek Williams", completedDate: "2025-04-18", dueDate: "2025-04-20",
    documents: [],
  },
  // Patapsco HS — 2025
  {
    id: "PY-10001", jobId: "J-PY-10001", client: "Patapsco High School", customerId: "C-10", locationId: "C-10-L1",
    address: "8100 Wise Ave, Dundalk, MD 21222",
    type: "Extinguisher Round (x10)", serviceCategory: "extinguisher", revenue: 250,
    status: "completed", techName: "Kevin Park", completedDate: "2025-06-12", dueDate: "2025-06-30",
    documents: [
      { id: "PD-70", name: "2025_patapsco_ext.pdf", type: "pdf", uploadedBy: "Kevin Park", uploadedAt: "2025-06-12", size: "300 KB" },
    ],
  },
  // Sunrise Group Home — 2025
  {
    id: "PY-4001", jobId: "J-PY-4001", client: "Sunrise Group Home", customerId: "C-4", locationId: "C-4-L1",
    address: "78 Elm St, Essex, MD 21221",
    type: "Suppression Semi-Annual", serviceCategory: "suppression", revenue: 320,
    status: "completed", techName: "Angela Davis", completedDate: "2025-03-10", dueDate: "2025-03-15",
    documents: [],
  },
  {
    id: "PY-4002", jobId: "J-PY-4002", client: "Sunrise Group Home", customerId: "C-4", locationId: "C-4-L1",
    address: "78 Elm St, Essex, MD 21221",
    type: "Suppression Semi-Annual", serviceCategory: "suppression", revenue: 320,
    status: "completed", techName: "Sarah Johnson", completedDate: "2025-09-18", dueDate: "2025-09-30",
    documents: [
      { id: "PD-80", name: "2025_sunrise_supp_sept.pdf", type: "pdf", uploadedBy: "Sarah Johnson", uploadedAt: "2025-09-18", size: "290 KB" },
    ],
  },
];

// ─── Helper: Get all jobs for a specific job (current + prev year at same location) ───
export function getJobHistory(jobId: string): { currentYearJobs: Job[]; previousYearJobs: PreviousYearJob[] } {
  const job = [...allCustomerJobs, ...todayJobs].find(j => j.id === jobId);
  if (!job) return { currentYearJobs: [], previousYearJobs: [] };

  // Get all current year jobs at same customer/location
  const currentYearJobs = allCustomerJobs.filter(j =>
    j.customerId === job.customerId &&
    (j.locationId === job.locationId || !job.locationId) &&
    j.id !== job.id
  );

  // Get previous year jobs at same customer/location
  const prevYearAtLocation = previousYearJobs.filter(j =>
    j.customerId === job.customerId &&
    (j.locationId === job.locationId || !job.locationId)
  );

  return { currentYearJobs, previousYearJobs: prevYearAtLocation };
}

// ─── Helper: Get employee's weekly schedule with job details ───────────
export type EmployeeWeekDay = {
  label: string;
  date: string;
  type: "billable" | "shop" | "training" | "off" | "open";
  revenue: number;
  jobs: { id: string; client: string; type: string; time: string; revenue: number; status: string }[];
};

export type EmployeeWeekSchedule = {
  techId: string;
  techName: string;
  cert: string;
  specialty: string;
  weekRevenue: number;
  shopDaysThisWeek: number;
  days: EmployeeWeekDay[];
};

export const employeeWeekSchedules: EmployeeWeekSchedule[] = [
  {
    techId: "1", techName: "Sarah J.", cert: "SUPP", specialty: "Suppression Lead",
    weekRevenue: 7500, shopDaysThisWeek: 0,
    days: [
      { label: "Mon", date: "6/9", type: "billable", revenue: 1400, jobs: [
        { id: "J-1001", client: "Olive Garden", type: "Hood Suppression", time: "7:30 AM", revenue: 1400, status: "completed" },
      ]},
      { label: "Tue", date: "6/10", type: "billable", revenue: 1900, jobs: [
        { id: "J-1005", client: "ABC Restaurant", type: "Hood Suppression", time: "10:00 AM", revenue: 1400, status: "pending" },
        { id: "J-1007", client: "Chipotle", type: "Hood Suppression Check", time: "1:30 PM", revenue: 500, status: "pending" },
      ]},
      { label: "Wed", date: "6/11", type: "billable", revenue: 1400, jobs: [
        { id: "J-2051", client: "Olive Garden — Towson", type: "Hood Suppression", time: "8:00 AM", revenue: 1400, status: "pending" },
      ]},
      { label: "Thu", date: "6/12", type: "billable", revenue: 1400, jobs: [
        { id: "J-2071", client: "Chipotle — Columbia", type: "Hood Suppression", time: "1:00 PM", revenue: 1400, status: "pending" },
      ]},
      { label: "Fri", date: "6/13", type: "billable", revenue: 1400, jobs: [
        { id: "J-2005", client: "ABC — Glen Burnie", type: "Hood Suppression", time: "8:00 AM", revenue: 1400, status: "pending" },
      ]},
    ],
  },
  {
    techId: "2", techName: "Derek W.", cert: "SPR", specialty: "Sprinkler Tech",
    weekRevenue: 3600, shopDaysThisWeek: 2,
    days: [
      { label: "Mon", date: "6/9", type: "billable", revenue: 1200, jobs: [
        { id: "J-1003", client: "Metro Office Park", type: "Sprinkler Annual", time: "8:00 AM", revenue: 1200, status: "reschedule" },
      ]},
      { label: "Tue", date: "6/10", type: "shop", revenue: 0, jobs: [] },
      { label: "Wed", date: "6/11", type: "billable", revenue: 1200, jobs: [
        { id: "J-2022", client: "Metro — Bldg C", type: "Sprinkler + Exit", time: "8:00 AM", revenue: 1200, status: "pending" },
      ]},
      { label: "Thu", date: "6/12", type: "billable", revenue: 1200, jobs: [
        { id: "J-2040", client: "Harbor Condos", type: "Sprinkler Standpipe", time: "8:00 AM", revenue: 1200, status: "pending" },
      ]},
      { label: "Fri", date: "6/13", type: "shop", revenue: 0, jobs: [] },
    ],
  },
  {
    techId: "3", techName: "Marcus T.", cert: "EXT", specialty: "Extinguisher Tech",
    weekRevenue: 3600, shopDaysThisWeek: 0,
    days: [
      { label: "Mon", date: "6/9", type: "billable", revenue: 900, jobs: [
        { id: "J-1002", client: "Lincoln Elementary", type: "Ext Inspection (x24)", time: "8:00 AM", revenue: 600, status: "return" },
        { id: "J-1008", client: "Patapsco HS", type: "Ext Round (x12)", time: "12:00 PM", revenue: 300, status: "completed" },
      ]},
      { label: "Tue", date: "6/10", type: "billable", revenue: 900, jobs: [
        { id: "J-2011", client: "Lincoln — Annex", type: "Ext Inspection (x12)", time: "8:00 AM", revenue: 300, status: "pending" },
        { id: "J-2004", client: "ABC — Ellicott City", type: "Ext Annual (x8)", time: "10:30 AM", revenue: 280, status: "pending" },
      ]},
      { label: "Wed", date: "6/11", type: "training", revenue: 0, jobs: [] },
      { label: "Thu", date: "6/12", type: "billable", revenue: 900, jobs: [
        { id: "J-2082", client: "Towson Town Center", type: "Ext Round (x24)", time: "8:00 AM", revenue: 672, status: "pending" },
      ]},
      { label: "Fri", date: "6/13", type: "billable", revenue: 900, jobs: [
        { id: "J-2031", client: "Sunrise — West Wing", type: "Ext Inspection (x10)", time: "9:00 AM", revenue: 300, status: "pending" },
      ]},
    ],
  },
  {
    techId: "5", techName: "Kevin P.", cert: "EXT", specialty: "Extinguisher Tech",
    weekRevenue: 3320, shopDaysThisWeek: 0,
    days: [
      { label: "Mon", date: "6/9", type: "billable", revenue: 900, jobs: [
        { id: "J-1004", client: "Harbor Condos", type: "Exit Light (x20)", time: "9:00 AM", revenue: 200, status: "in-progress" },
        { id: "J-1006", client: "Sunrise Group Home", type: "Ext + Exit Lights", time: "1:00 PM", revenue: 420, status: "pending" },
      ]},
      { label: "Tue", date: "6/10", type: "billable", revenue: 620, jobs: [
        { id: "J-2021", client: "Metro — Bldg B", type: "Ext Inspection (x16)", time: "9:00 AM", revenue: 480, status: "pending" },
      ]},
      { label: "Wed", date: "6/11", type: "billable", revenue: 900, jobs: [
        { id: "J-2041", client: "Harbor — Tower B", type: "Ext Annual (x30)", time: "8:00 AM", revenue: 840, status: "pending" },
      ]},
      { label: "Thu", date: "6/12", type: "billable", revenue: 900, jobs: [
        { id: "J-2090", client: "Patapsco HS", type: "Exit Light (x30)", time: "8:00 AM", revenue: 360, status: "pending" },
      ]},
      { label: "Fri", date: "6/13", type: "training", revenue: 0, jobs: [] },
    ],
  },
  {
    techId: "6", techName: "Angela D.", cert: "SUPP", specialty: "Suppression Tech",
    weekRevenue: 5600, shopDaysThisWeek: 1,
    days: [
      { label: "Mon", date: "6/9", type: "billable", revenue: 1400, jobs: [
        { id: "J-2062", client: "BCOGov — Satellite", type: "Suppression Check", time: "9:00 AM", revenue: 600, status: "pending" },
      ]},
      { label: "Tue", date: "6/10", type: "billable", revenue: 1400, jobs: [
        { id: "J-2091", client: "Patapsco — Gym", type: "Suppression Check", time: "10:00 AM", revenue: 400, status: "pending" },
      ]},
      { label: "Wed", date: "6/11", type: "billable", revenue: 1400, jobs: [
        { id: "J-2003", client: "ABC — Ellicott City", type: "Hood Suppression", time: "9:00 AM", revenue: 500, status: "pending" },
      ]},
      { label: "Thu", date: "6/12", type: "shop", revenue: 0, jobs: [] },
      { label: "Fri", date: "6/13", type: "billable", revenue: 1400, jobs: [
        { id: "J-2081", client: "Towson — Food Court", type: "Hood Suppression (x4)", time: "7:00 AM", revenue: 1800, status: "pending" },
      ]},
    ],
  },
  {
    techId: "4", techName: "James R.", cert: "EXT", specialty: "Helper / Apprentice",
    weekRevenue: 1500, shopDaysThisWeek: 2,
    days: [
      { label: "Mon", date: "6/9", type: "billable", revenue: 500, jobs: [
        { id: "J-2063", client: "BCOGov — Warehouse", type: "Ext Inspection (x20)", time: "8:00 AM", revenue: 440, status: "pending" },
      ]},
      { label: "Tue", date: "6/10", type: "shop", revenue: 0, jobs: [] },
      { label: "Wed", date: "6/11", type: "shop", revenue: 0, jobs: [] },
      { label: "Thu", date: "6/12", type: "billable", revenue: 500, jobs: [
        { id: "J-2006", client: "ABC — Glen Burnie", type: "Ext Annual (x4)", time: "10:00 AM", revenue: 140, status: "pending" },
      ]},
      { label: "Fri", date: "6/13", type: "billable", revenue: 500, jobs: [
        { id: "J-2052", client: "Olive Garden — Towson", type: "Ext Annual (x6)", time: "10:00 AM", revenue: 210, status: "pending" },
      ]},
    ],
  },
];
