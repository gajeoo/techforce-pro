import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Camera,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  ClipboardList,
  FileText,
  LogIn,
  LogOut,
  MapPin,
  MessageSquare,
  Phone,
  Upload,
  Wrench,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { todayJobs, employees } from "@/lib/mockData";

// Simulated current tech
const currentTech = employees[0]; // Marcus Johnson

// Today's jobs for this tech
const myJobs = todayJobs.filter(j => j.techId === currentTech.id || j.techName === currentTech.name).length > 0
  ? todayJobs.filter(j => j.techId === currentTech.id || j.techName === currentTech.name)
  : todayJobs.slice(0, 4); // fallback

type JobStatus = "pending" | "en-route" | "on-site" | "in-progress" | "completed";

interface TechJob {
  id: string;
  client: string;
  address: string;
  type: string;
  scheduledTime: string;
  status: JobStatus;
  notes: string;
  units: number;
  serviceType: string;
}

const techJobs: TechJob[] = [
  { id: "TJ-001", client: "Applebee's — Columbia", address: "6181 Old Dobbin Ln, Columbia, MD 21045", type: "Suppression + Extinguisher", scheduledTime: "8:00 AM", status: "completed", notes: "Hood system inspected, 3 extinguishers recharged", units: 12, serviceType: "suppression" },
  { id: "TJ-002", client: "Five Guys — Ellicott City", address: "8775 Centre Park Dr, Columbia, MD 21045", type: "Suppression Inspection", scheduledTime: "10:30 AM", status: "in-progress", notes: "", units: 6, serviceType: "suppression" },
  { id: "TJ-003", client: "Taco Bell — Laurel", address: "3500 Russett Green, Laurel, MD 20724", type: "Extinguisher Annual", scheduledTime: "1:00 PM", status: "pending", notes: "", units: 8, serviceType: "extinguisher" },
  { id: "TJ-004", client: "Chipotle — Savage", address: "8861 McGaw Ct, Columbia, MD 21045", type: "Suppression 6yr", scheduledTime: "3:00 PM", status: "pending", notes: "", units: 4, serviceType: "suppression" },
];

const statusOrder: JobStatus[] = ["pending", "en-route", "on-site", "in-progress", "completed"];

function getStatusBg(status: JobStatus) {
  const map: Record<JobStatus, string> = {
    "pending": "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
    "en-route": "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
    "on-site": "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
    "in-progress": "bg-primary/10 text-primary",
    "completed": "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
  };
  return map[status];
}

function getStatusIcon(status: JobStatus) {
  if (status === "completed") return <CheckCircle2 className="size-4 text-emerald-600" />;
  if (status === "in-progress") return <Wrench className="size-4 text-primary" />;
  if (status === "en-route") return <MapPin className="size-4 text-blue-600" />;
  if (status === "on-site") return <Clock className="size-4 text-amber-600" />;
  return <Clock className="size-4 text-gray-400" />;
}

export function TechPortalPage() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState(techJobs);
  const [clockedIn, setClockedIn] = useState(true);
  const [clockTime] = useState("7:45 AM");
  const [clockLocation] = useState("39.2156° N, 76.8585° W — Shop, Columbia MD");
  const [selectedJob, setSelectedJob] = useState<TechJob | null>(null);
  const [completeOpen, setCompleteOpen] = useState(false);
  const [shopRequestOpen, setShopRequestOpen] = useState(false);

  const completedCount = jobs.filter(j => j.status === "completed").length;

  function advanceStatus(jobId: string) {
    setJobs(prev => prev.map(j => {
      if (j.id !== jobId) return j;
      const idx = statusOrder.indexOf(j.status);
      if (idx < statusOrder.length - 1) {
        const next = statusOrder[idx + 1];
        if (next === "completed") {
          setSelectedJob(j);
          setCompleteOpen(true);
          return j;
        }
        return { ...j, status: next };
      }
      return j;
    }));
  }

  function completeJob() {
    if (!selectedJob) return;
    setJobs(prev => prev.map(j => j.id === selectedJob.id ? { ...j, status: "completed" as JobStatus } : j));
    setSelectedJob(null);
    setCompleteOpen(false);
  }

  function getNextAction(status: JobStatus) {
    if (status === "pending") return "Start Route";
    if (status === "en-route") return "Arrived";
    if (status === "on-site") return "Begin Work";
    if (status === "in-progress") return "Complete";
    return "";
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <ClipboardList className="size-6 text-primary shrink-0" />
            My Work
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {currentTech.name} — {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
          </p>
        </div>
        <div className="flex gap-2 self-start sm:self-auto">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            onClick={() => setShopRequestOpen(true)}
          >
            <Wrench className="size-3.5" /> Request Shop Day
          </Button>
          <Button
            variant={clockedIn ? "destructive" : "default"}
            size="sm"
            className="gap-1.5"
            onClick={() => setClockedIn(!clockedIn)}
          >
            {clockedIn ? <LogOut className="size-3.5" /> : <LogIn className="size-3.5" />}
            {clockedIn ? "Clock Out" : "Clock In"}
          </Button>
        </div>
      </div>

      {/* Status Bar — NO financial data */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase mb-1">Clock Status</div>
            <div className="flex items-center gap-2">
              <div className={`size-3 rounded-full ${clockedIn ? "bg-emerald-500 animate-pulse" : "bg-gray-400"}`} />
              <span className="text-sm font-bold">{clockedIn ? `In since ${clockTime}` : "Clocked Out"}</span>
            </div>
            {clockedIn && (
              <div className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                <MapPin className="size-2.5" /> {clockLocation}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase mb-1">Progress</div>
            <div className="text-lg font-extrabold">{completedCount}/{jobs.length}</div>
            <Progress value={(completedCount / jobs.length) * 100} className="h-2 mt-1" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase mb-1">Units Serviced</div>
            <div className="text-lg font-extrabold text-blue-600">
              {jobs.filter(j => j.status === "completed").reduce((s, j) => s + j.units, 0)}
            </div>
            <div className="text-[10px] text-muted-foreground">of {jobs.reduce((s, j) => s + j.units, 0)} total</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase mb-1">Shop Days</div>
            <div className="text-lg font-extrabold">{currentTech.shopDaysUsed}/{currentTech.shopDaysAllowed}</div>
            <div className="text-[10px] text-muted-foreground">{currentTech.shopDaysAllowed - currentTech.shopDaysUsed} remaining this month</div>
          </CardContent>
        </Card>
      </div>

      {/* Job Cards — Agenda View — NO revenue/$ shown */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Today's Route</h2>
        {jobs.map((job, idx) => (
          <Card
            key={job.id}
            className={`overflow-hidden transition-all ${job.status === "completed" ? "opacity-70" : "hover:shadow-md"}`}
          >
            {/* Status stripe */}
            <div className={`h-1 ${job.status === "completed" ? "bg-emerald-500" : job.status === "in-progress" ? "bg-primary" : job.status === "en-route" ? "bg-blue-500" : job.status === "on-site" ? "bg-amber-500" : "bg-gray-300"}`} />
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                {/* Timeline indicator */}
                <div className="flex flex-col items-center gap-1 shrink-0">
                  <div className="text-xs font-bold text-muted-foreground">{idx + 1}</div>
                  {getStatusIcon(job.status)}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3
                        className="text-sm font-bold text-primary cursor-pointer hover:underline"
                        onClick={() => navigate(`/jobs/${myJobs[idx]?.id || job.id}`)}
                      >
                        {job.client}
                      </h3>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                        <MapPin className="size-3" /> {job.address}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-sm font-bold">{job.scheduledTime}</div>
                      <div className="text-[10px] text-muted-foreground">{job.units} units</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className="text-[10px]">{job.type}</Badge>
                    <Badge className={`text-[10px] ${getStatusBg(job.status)}`} variant="secondary">{job.status.replace("-", " ")}</Badge>
                  </div>

                  {job.notes && (
                    <p className="text-xs text-muted-foreground mt-2 bg-muted/50 rounded p-2">
                      <MessageSquare className="size-3 inline mr-1" />{job.notes}
                    </p>
                  )}

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 mt-3">
                    {job.status !== "completed" && (
                      <Button
                        size="sm"
                        className="gap-1.5 text-xs"
                        onClick={() => advanceStatus(job.id)}
                      >
                        {job.status === "in-progress" ? <Check className="size-3" /> : <ChevronRight className="size-3" />}
                        {getNextAction(job.status)}
                      </Button>
                    )}
                    {job.status === "completed" && (
                      <Button size="sm" variant="outline" className="gap-1.5 text-xs text-emerald-600" disabled>
                        <CheckCircle2 className="size-3" /> Completed
                      </Button>
                    )}
                    <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                      <Camera className="size-3" /> Photo
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                      <FileText className="size-3" /> Notes
                    </Button>
                    <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
                      <Phone className="size-3" /> Call
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Stats — NO financial data */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Weekly Summary</CardTitle>
          <CardDescription>Your performance this week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-lg p-3">
              <div className="text-2xl font-extrabold text-emerald-600">16</div>
              <div className="text-xs text-muted-foreground">Jobs This Week</div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
              <div className="text-2xl font-extrabold text-blue-600">142</div>
              <div className="text-xs text-muted-foreground">Units Serviced</div>
            </div>
            <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3">
              <div className="text-2xl font-extrabold text-amber-600">94%</div>
              <div className="text-xs text-muted-foreground">On-Time Rate</div>
            </div>
            <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-3">
              <div className="text-2xl font-extrabold text-red-600">1</div>
              <div className="text-xs text-muted-foreground">Shop Day Used</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Job Completion Dialog */}
      <Dialog open={completeOpen} onOpenChange={setCompleteOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="size-5 text-emerald-600" />
              Complete Job — {selectedJob?.client}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Units Serviced</Label>
                <Input type="number" defaultValue={selectedJob?.units} />
              </div>
              <div>
                <Label className="text-xs">Service Type</Label>
                <Select defaultValue={selectedJob?.serviceType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="suppression">Suppression</SelectItem>
                    <SelectItem value="extinguisher">Extinguisher</SelectItem>
                    <SelectItem value="sprinkler">Sprinkler</SelectItem>
                    <SelectItem value="exit-light">Exit Light</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs">Work Notes</Label>
              <Textarea placeholder="Describe work performed..." rows={3} />
            </div>
            <div>
              <Label className="text-xs">Deficiencies Found</Label>
              <Textarea placeholder="Any issues found (optional)..." rows={2} />
            </div>
            <div className="border border-dashed border-muted-foreground/30 rounded-lg p-4 text-center">
              <Upload className="size-6 mx-auto text-muted-foreground mb-2" />
              <p className="text-xs text-muted-foreground">Drop photos here or click to upload</p>
              <Button variant="outline" size="sm" className="mt-2 gap-1.5 text-xs">
                <Camera className="size-3" /> Take Photo
              </Button>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCompleteOpen(false)}>Cancel</Button>
              <Button className="gap-1.5 bg-emerald-600 hover:bg-emerald-700" onClick={completeJob}>
                <CheckCircle2 className="size-3.5" /> Mark Complete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Shop Day Request Dialog */}
      <Dialog open={shopRequestOpen} onOpenChange={setShopRequestOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wrench className="size-5 text-primary" />
              Request Shop Day
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted/50 rounded-lg p-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Shop days used this month:</span>
                <span className="font-bold">{currentTech.shopDaysUsed}/{currentTech.shopDaysAllowed}</span>
              </div>
            </div>
            <div>
              <Label className="text-xs">Requested Date</Label>
              <Input type="date" />
            </div>
            <div>
              <Label className="text-xs">Reason</Label>
              <Select>
                <SelectTrigger><SelectValue placeholder="Select reason" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="recharge">Recharging Extinguishers</SelectItem>
                  <SelectItem value="inventory">Inventory & Stocking</SelectItem>
                  <SelectItem value="truck">Truck Maintenance</SelectItem>
                  <SelectItem value="training">Training / Certification</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Notes</Label>
              <Textarea placeholder="Additional details..." rows={2} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setShopRequestOpen(false)}>Cancel</Button>
              <Button onClick={() => setShopRequestOpen(false)}>Submit Request</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
