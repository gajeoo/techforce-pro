import { useState } from "react";
import {
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  FileText,
  MapPin,
  MessageSquare,
  Phone,
  Plus,
  Search,
  ShieldCheck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

// Simulated customer portal data
const customerInfo = {
  name: "Howard County Public Schools",
  type: "School",
  contactName: "Karen Mitchell",
  phone: "(410) 555-3300",
  email: "kmitchell@hcpss.org",
  locationCount: 8,
  contractExpiry: "Dec 31, 2026",
  contractStatus: "active" as const,
  annualValue: "$42,500",
};

const customerLocations = [
  { id: "L-001", name: "Wilde Lake High School", address: "5460 Trumpeter Rd, Columbia, MD", lastService: "Apr 15, 2026", nextService: "Oct 15, 2026", status: "current" },
  { id: "L-002", name: "Oakland Mills Middle", address: "9540 Kilimanjaro Rd, Columbia, MD", lastService: "Apr 16, 2026", nextService: "Oct 16, 2026", status: "current" },
  { id: "L-003", name: "Talbott Springs Elementary", address: "9550 Basket Ring Rd, Columbia, MD", lastService: "Mar 22, 2026", nextService: "Sep 22, 2026", status: "current" },
  { id: "L-004", name: "Harper's Choice Middle", address: "5450 Beaverkill Rd, Columbia, MD", lastService: "May 1, 2026", nextService: "Nov 1, 2026", status: "current" },
  { id: "L-005", name: "Hammond High School", address: "8800 Guilford Rd, Columbia, MD", lastService: "Feb 10, 2026", nextService: "Aug 10, 2026", status: "due-soon" },
  { id: "L-006", name: "Admin Building", address: "10910 Clarksville Pike, Ellicott City, MD", lastService: "Jan 20, 2026", nextService: "Jul 20, 2026", status: "overdue" },
];

const upcomingServices = [
  { id: "S-001", location: "Hammond High School", type: "Extinguisher Annual + Suppression", date: "Jun 18, 2026", tech: "Marcus Johnson", status: "scheduled", time: "8:00 AM — 12:00 PM" },
  { id: "S-002", location: "Admin Building", type: "Full Fire Safety Inspection", date: "Jun 25, 2026", tech: "Sarah Chen", status: "scheduled", time: "9:00 AM — 2:00 PM" },
  { id: "S-003", location: "Wilde Lake High School", type: "Sprinkler System Test", date: "Jul 10, 2026", tech: "TBD", status: "pending", time: "7:00 AM — 11:00 AM" },
];

const pastInspections = [
  { id: "I-001", location: "Talbott Springs Elementary", type: "Extinguisher Annual", date: "Mar 22, 2026", result: "pass", units: 24, deficiencies: 0, certFile: "cert_talbott_2026.pdf" },
  { id: "I-002", location: "Harper's Choice Middle", type: "Suppression + Extinguisher", date: "May 1, 2026", result: "pass", units: 18, deficiencies: 1, certFile: "cert_harpers_2026.pdf" },
  { id: "I-003", location: "Wilde Lake High School", type: "Full Fire Safety", date: "Apr 15, 2026", result: "pass", units: 32, deficiencies: 2, certFile: "cert_wildelake_2026.pdf" },
  { id: "I-004", location: "Oakland Mills Middle", type: "Extinguisher Annual", date: "Apr 16, 2026", result: "pass", units: 20, deficiencies: 0, certFile: "cert_oakland_2026.pdf" },
  { id: "I-005", location: "Hammond High School", type: "Suppression Inspection", date: "Feb 10, 2026", result: "fail", units: 14, deficiencies: 3, certFile: "" },
];

export function CustomerPortalPage() {
  const [requestOpen, setRequestOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [searchLoc, setSearchLoc] = useState("");

  const filteredLocations = customerLocations.filter(l =>
    l.name.toLowerCase().includes(searchLoc.toLowerCase()) ||
    l.address.toLowerCase().includes(searchLoc.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Building2 className="size-6 text-primary shrink-0" />
            Customer Portal
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Welcome, {customerInfo.contactName} — {customerInfo.name}
          </p>
        </div>
        <div className="flex gap-2 self-start sm:self-auto">
          <Button variant="outline" size="sm" className="gap-1.5">
            <Phone className="size-3.5" /> Call Us
          </Button>
          <Button size="sm" className="gap-1.5" onClick={() => setRequestOpen(true)}>
            <Plus className="size-3.5" /> Request Service
          </Button>
        </div>
      </div>

      {/* Account Summary */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">Account Value</div>
            <div className="text-xl font-extrabold text-emerald-600">{customerInfo.annualValue}</div>
            <div className="text-[10px] text-muted-foreground">annual contract</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">Locations</div>
            <div className="text-xl font-extrabold">{customerInfo.locationCount}</div>
            <div className="text-[10px] text-muted-foreground">service sites</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">Contract Status</div>
            <div className="flex items-center gap-1.5 mt-1">
              <Badge variant="default" className="bg-emerald-600 text-xs">Active</Badge>
            </div>
            <div className="text-[10px] text-muted-foreground mt-1">Expires {customerInfo.contractExpiry}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">Compliance</div>
            <div className="text-xl font-extrabold text-emerald-600">83%</div>
            <div className="text-[10px] text-muted-foreground">5/6 locations current</div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Services */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <Calendar className="size-4 text-primary" />
                Upcoming Services
              </CardTitle>
              <CardDescription>{upcomingServices.length} scheduled inspections</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {upcomingServices.map(svc => (
              <div key={svc.id} className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/20 transition-colors">
                <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Calendar className="size-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold">{svc.location}</h3>
                    <Badge variant={svc.status === "scheduled" ? "default" : "secondary"} className={`text-[10px] ${svc.status === "scheduled" ? "bg-emerald-600" : ""}`}>
                      {svc.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{svc.type}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1"><Clock className="size-3" /> {svc.date} · {svc.time}</span>
                    <span>Tech: {svc.tech}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Locations Grid */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <MapPin className="size-4 text-primary" />
                Your Locations
              </CardTitle>
              <CardDescription>{customerLocations.length} service sites</CardDescription>
            </div>
            <div className="relative max-w-xs">
              <Search className="absolute left-2 top-2 size-3.5 text-muted-foreground" />
              <Input placeholder="Search locations..." className="pl-7 h-8 text-xs" value={searchLoc} onChange={e => setSearchLoc(e.target.value)} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {filteredLocations.map(loc => {
              const statusColor = loc.status === "current" ? "border-emerald-200 dark:border-emerald-800" : loc.status === "due-soon" ? "border-amber-200 dark:border-amber-800" : "border-red-200 dark:border-red-800";
              const statusBadge = loc.status === "current"
                ? <Badge variant="default" className="bg-emerald-600 text-[9px]">Current</Badge>
                : loc.status === "due-soon"
                ? <Badge variant="default" className="bg-amber-600 text-[9px]">Due Soon</Badge>
                : <Badge variant="destructive" className="text-[9px]">Overdue</Badge>;
              return (
                <div
                  key={loc.id}
                  className={`rounded-xl border p-4 cursor-pointer hover:shadow-sm transition-all ${statusColor} ${selectedLocation === loc.id ? "ring-2 ring-primary" : ""}`}
                  onClick={() => setSelectedLocation(selectedLocation === loc.id ? null : loc.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-sm font-bold leading-tight">{loc.name}</h3>
                    {statusBadge}
                  </div>
                  <p className="text-[11px] text-muted-foreground flex items-center gap-1 mb-2">
                    <MapPin className="size-3 shrink-0" /> {loc.address}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>Last: {loc.lastService}</span>
                    <span className="font-medium">Next: {loc.nextService}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Past Inspections & Certificates */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <FileText className="size-4 text-primary" />
                Inspection History & Certificates
              </CardTitle>
              <CardDescription>Download certificates and view inspection results</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Desktop */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-2 font-medium text-xs text-muted-foreground">Location</th>
                  <th className="text-left py-2 px-2 font-medium text-xs text-muted-foreground">Service</th>
                  <th className="text-left py-2 px-2 font-medium text-xs text-muted-foreground">Date</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Units</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Result</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Issues</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Certificate</th>
                </tr>
              </thead>
              <tbody>
                {pastInspections.map(ins => (
                  <tr key={ins.id} className="border-b border-muted/50 hover:bg-muted/20 transition-colors">
                    <td className="py-2.5 px-2 font-semibold text-xs">{ins.location}</td>
                    <td className="py-2.5 px-2 text-xs text-muted-foreground">{ins.type}</td>
                    <td className="py-2.5 px-2 text-xs text-muted-foreground">{ins.date}</td>
                    <td className="py-2.5 px-2 text-center text-xs">{ins.units}</td>
                    <td className="py-2.5 px-2 text-center">
                      {ins.result === "pass" ? (
                        <Badge variant="default" className="bg-emerald-600 text-[10px] gap-1">
                          <CheckCircle2 className="size-3" /> Pass
                        </Badge>
                      ) : (
                        <Badge variant="destructive" className="text-[10px]">Fail</Badge>
                      )}
                    </td>
                    <td className="py-2.5 px-2 text-center text-xs">
                      {ins.deficiencies > 0 ? (
                        <span className="text-amber-600 font-bold">{ins.deficiencies}</span>
                      ) : (
                        <span className="text-emerald-600">None</span>
                      )}
                    </td>
                    <td className="py-2.5 px-2 text-center">
                      {ins.certFile ? (
                        <Button variant="outline" size="sm" className="text-xs gap-1 h-7">
                          <Download className="size-3" /> PDF
                        </Button>
                      ) : (
                        <span className="text-[10px] text-muted-foreground">Pending</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile */}
          <div className="md:hidden space-y-3">
            {pastInspections.map(ins => (
              <div key={ins.id} className="rounded-lg border p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold">{ins.location}</span>
                  {ins.result === "pass" ? (
                    <Badge variant="default" className="bg-emerald-600 text-[10px] gap-1">
                      <ShieldCheck className="size-3" /> Pass
                    </Badge>
                  ) : (
                    <Badge variant="destructive" className="text-[10px]">Fail</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">{ins.type} · {ins.date}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-muted-foreground">{ins.units} units · {ins.deficiencies} issues</span>
                  {ins.certFile && (
                    <Button variant="outline" size="sm" className="text-[10px] gap-1 h-6 px-2">
                      <Download className="size-3" /> Certificate
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Contact / Support */}
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold flex items-center gap-2">
                <MessageSquare className="size-4 text-primary" />
                Need Help?
              </h3>
              <p className="text-xs text-muted-foreground mt-1">
                Contact Multicorp Fire Protection Services for questions about your account, schedule changes, or emergency service.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                <Phone className="size-3" /> (410) 555-FIRE
              </Button>
              <Button size="sm" className="gap-1.5 text-xs" onClick={() => setRequestOpen(true)}>
                <Plus className="size-3" /> Request Service
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Service Request Dialog */}
      <Dialog open={requestOpen} onOpenChange={setRequestOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="size-5 text-primary" />
              Request Service
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs">Location</Label>
              <Select>
                <SelectTrigger><SelectValue placeholder="Select location..." /></SelectTrigger>
                <SelectContent>
                  {customerLocations.map(loc => (
                    <SelectItem key={loc.id} value={loc.id}>{loc.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Service Type</Label>
                <Select>
                  <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ext-annual">Extinguisher Annual</SelectItem>
                    <SelectItem value="suppression">Suppression Inspection</SelectItem>
                    <SelectItem value="sprinkler">Sprinkler Test</SelectItem>
                    <SelectItem value="exit-light">Exit Light Inspection</SelectItem>
                    <SelectItem value="full">Full Fire Safety</SelectItem>
                    <SelectItem value="emergency">Emergency Service</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Urgency</Label>
                <Select>
                  <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="routine">Routine</SelectItem>
                    <SelectItem value="soon">Within 2 Weeks</SelectItem>
                    <SelectItem value="urgent">Urgent (24-48 hrs)</SelectItem>
                    <SelectItem value="emergency">Emergency (ASAP)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs">Preferred Date (optional)</Label>
              <Input type="date" />
            </div>
            <div>
              <Label className="text-xs">Notes</Label>
              <Textarea placeholder="Any additional details about the service needed..." rows={3} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setRequestOpen(false)}>Cancel</Button>
              <Button onClick={() => setRequestOpen(false)}>Submit Request</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
