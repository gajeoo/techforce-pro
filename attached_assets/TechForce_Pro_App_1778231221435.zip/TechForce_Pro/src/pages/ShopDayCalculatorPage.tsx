import {
  ArrowDown,
  ArrowUp,
  Calculator,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Lightbulb,
  Minus,
  Plus,
  RotateCcw,
  TrendingUp,
  UserPlus,
  Users,
} from "lucide-react";
import { useCallback, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

// ─── Types ──────────────────────────────────────────────────────────────

type TechRow = {
  id: string;
  name: string;
  salary: number;
  dailyRate: number;      // revenue per billable day — the key linkage
  shopDays: number;
  maxShopDays: number;
  isShopGuy: boolean;
};

const WORK_DAYS = 22;

// ─── Initial data from real employees ───────────────────────────────────
// dailyRate = monthlyRevenue / (22 - baselineShopDays)

const initialTechs: TechRow[] = [
  { id: "1", name: "Sarah Johnson",    salary: 85000, dailyRate: Math.round(28000 / (22 - 1)),  shopDays: 1,  maxShopDays: 2,  isShopGuy: false },
  { id: "2", name: "Derek Williams",   salary: 70000, dailyRate: Math.round(19200 / (22 - 2)),  shopDays: 2,  maxShopDays: 3,  isShopGuy: false },
  { id: "3", name: "Marcus Taylor",    salary: 55000, dailyRate: Math.round(14400 / (22 - 4)),  shopDays: 4,  maxShopDays: 5,  isShopGuy: false },
  { id: "4", name: "James Rodriguez",  salary: 40000, dailyRate: Math.round(7500 / (22 - 10)),  shopDays: 10, maxShopDays: 12, isShopGuy: false },
  { id: "5", name: "Kevin Park",       salary: 55000, dailyRate: Math.round(14400 / (22 - 3)),  shopDays: 3,  maxShopDays: 5,  isShopGuy: false },
  { id: "6", name: "Angela Davis",     salary: 75000, dailyRate: Math.round(25200 / (22 - 1)),  shopDays: 1,  maxShopDays: 2,  isShopGuy: false },
];

// ─── Scenario presets ───────────────────────────────────────────────────

const scenarios = [
  {
    label: "🧑‍🔧 Hire a Shop Guy",
    description: "Add a dedicated shop guy so techs spend less time in the shop",
    apply: (techs: TechRow[]) => {
      const updated = techs.filter(t => !t.isShopGuy).map(t => ({
        ...t,
        shopDays: Math.max(0, Math.round(t.shopDays * 0.3)),
      }));
      updated.push({
        id: "shop-guy",
        name: "New Shop Guy",
        salary: 35000,
        dailyRate: 0,
        shopDays: 20,
        maxShopDays: 22,
        isShopGuy: true,
      });
      return updated;
    },
  },
  {
    label: "🚀 Max Utilization",
    description: "Every tech at peak — minimal shop days",
    apply: (techs: TechRow[]) =>
      techs.filter(t => !t.isShopGuy).map(t => ({
        ...t,
        shopDays: Math.max(1, Math.round(t.maxShopDays * 0.25)),
      })),
  },
  {
    label: "🤝 Generous Shop Time",
    description: "Give techs more shop time — see impact on margins",
    apply: (techs: TechRow[]) =>
      techs.filter(t => !t.isShopGuy).map(t => ({
        ...t,
        shopDays: t.maxShopDays,
      })),
  },
  {
    label: "📉 Slow Month",
    description: "Revenue drops 25% but costs stay fixed",
    apply: (techs: TechRow[]) =>
      techs.filter(t => !t.isShopGuy).map(t => ({
        ...t,
        dailyRate: Math.round(t.dailyRate * 0.75),
        shopDays: Math.min(22, Math.round(t.shopDays * 1.5)),
      })),
  },
];

// ─── Calculation helpers ────────────────────────────────────────────────

function calcTechProfit(t: TechRow) {
  const billableDays = WORK_DAYS - t.shopDays;
  const monthlyRevenue = t.dailyRate * billableDays;
  const monthlySalary = t.salary / 12;
  const overhead = t.salary * 0.30 / 12;
  const totalCost = monthlySalary + overhead;
  const utilization = Math.round((billableDays / WORK_DAYS) * 100);
  const profit = monthlyRevenue - totalCost;
  return { monthlyRevenue, monthlySalary, overhead, totalCost, billableDays, utilization, profit };
}

// ─── Component ──────────────────────────────────────────────────────────

export function ShopDayCalculatorPage() {
  const [techs, setTechs] = useState<TechRow[]>(initialTechs);
  const [showHowTo, setShowHowTo] = useState(false);

  const updateTech = useCallback((id: string, field: keyof TechRow, value: number) => {
    setTechs(prev => prev.map(t => t.id === id ? { ...t, [field]: value } : t));
  }, []);

  const removeTech = useCallback((id: string) => {
    setTechs(prev => prev.filter(t => t.id !== id));
  }, []);

  const addTech = useCallback(() => {
    setTechs(prev => [...prev, {
      id: `new-${Date.now()}`,
      name: `Tech ${prev.length + 1}`,
      salary: 50000,
      dailyRate: 600,
      shopDays: 3,
      maxShopDays: 5,
      isShopGuy: false,
    }]);
  }, []);

  const reset = useCallback(() => setTechs(initialTechs), []);

  // ─── Totals ─────────────────────────────────────────────────────────

  const totals = useMemo(() => {
    let revenue = 0, cost = 0, shopDays = 0, billDays = 0;
    techs.forEach(t => {
      const c = calcTechProfit(t);
      revenue += c.monthlyRevenue;
      cost += c.totalCost;
      shopDays += t.shopDays;
      billDays += c.billableDays;
    });
    const profit = revenue - cost;
    const margin = revenue > 0 ? Math.round((profit / revenue) * 100) : 0;
    const avgUtil = techs.length > 0 ? Math.round((billDays / (techs.length * WORK_DAYS)) * 100) : 0;
    return { revenue, cost, profit, margin, shopDays, billDays, avgUtil };
  }, [techs]);

  // ─── Compare to baseline ───────────────────────────────────────────

  const baseline = useMemo(() => {
    let revenue = 0, cost = 0, shopDays = 0;
    initialTechs.forEach(t => {
      const c = calcTechProfit(t);
      revenue += c.monthlyRevenue;
      cost += c.totalCost;
      shopDays += t.shopDays;
    });
    return { revenue, cost, profit: revenue - cost, shopDays };
  }, []);

  const profitDelta = totals.profit - baseline.profit;
  const shopDelta = totals.shopDays - baseline.shopDays;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Calculator className="size-6 text-primary shrink-0" />
            Shop Day Calculator
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Simulate scenarios to optimize profitability
          </p>
        </div>
        <div className="flex gap-2 self-start sm:self-auto">
          <Button variant="outline" size="sm" onClick={reset} className="gap-1.5 text-xs">
            <RotateCcw className="size-3" /> Reset
          </Button>
          <Button size="sm" onClick={addTech} className="gap-1.5 text-xs">
            <UserPlus className="size-3" /> Add Tech
          </Button>
        </div>
      </div>

      {/* ── KPI Summary ────────────────────────────────────────────── */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        <Card className={profitDelta >= 0 ? "border-emerald-200 dark:border-emerald-800" : "border-red-200 dark:border-red-800"}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Monthly Profit</span>
              <DollarSign className="size-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold">${Math.round(totals.profit).toLocaleString()}</div>
            {profitDelta !== 0 && (
              <div className={`text-xs mt-1 font-medium flex items-center gap-1 ${profitDelta > 0 ? "text-emerald-600" : "text-red-600"}`}>
                {profitDelta > 0 ? <ArrowUp className="size-3" /> : <ArrowDown className="size-3" />}
                ${Math.abs(Math.round(profitDelta)).toLocaleString()} vs baseline
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Revenue</span>
              <TrendingUp className="size-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold">${Math.round(totals.revenue).toLocaleString()}</div>
            <div className="text-xs mt-1 text-muted-foreground">Margin: {totals.margin}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Avg Utilization</span>
              <Users className="size-4 text-blue-600" />
            </div>
            <div className="text-xl font-extrabold">{totals.avgUtil}%</div>
            <Progress value={totals.avgUtil} className="h-1.5 mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Total Shop Days</span>
              <Calculator className="size-4 text-red-600" />
            </div>
            <div className="text-xl font-extrabold">{totals.shopDays}</div>
            {shopDelta !== 0 && (
              <div className={`text-xs mt-1 font-medium ${shopDelta < 0 ? "text-emerald-600" : "text-red-600"}`}>
                {shopDelta > 0 ? "+" : ""}{shopDelta} vs baseline
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Scenario Presets ───────────────────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Lightbulb className="size-4 text-amber-500" />
            What-If Scenarios
          </CardTitle>
          <CardDescription>Click to apply — use Reset to go back</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {scenarios.map(sc => (
              <button
                key={sc.label}
                onClick={() => setTechs(sc.apply(techs))}
                className="text-left border rounded-xl p-3 hover:bg-primary/5 hover:border-primary/30 transition-all group"
              >
                <div className="text-sm font-bold group-hover:text-primary transition-colors">{sc.label}</div>
                <div className="text-[11px] text-muted-foreground mt-0.5">{sc.description}</div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ── Calculator Table ───────────────────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Per-Technician Calculator</CardTitle>
          <CardDescription>
            Edit values directly — profit recalculates instantly.
            <span className="text-primary font-medium"> Revenue = daily rate × billable days, so shop day changes directly affect profit.</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Desktop */}
          <div className="hidden lg:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-foreground/20">
                  <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Technician</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Annual Salary</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Daily Rate</th>
                  <th className="text-center py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Shop Days</th>
                  <th className="text-center py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Billable</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Revenue</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Util %</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Total Cost</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Profit</th>
                  <th className="py-3 px-2"></th>
                </tr>
              </thead>
              <tbody>
                {techs.map(tech => {
                  const c = calcTechProfit(tech);
                  return (
                    <tr key={tech.id} className={`border-b border-muted/50 ${tech.isShopGuy ? "bg-blue-50/50 dark:bg-blue-950/10" : ""}`}>
                      <td className="py-3 px-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm">{tech.name}</span>
                          {tech.isShopGuy && <Badge className="bg-blue-600 text-[10px]">Shop Guy</Badge>}
                        </div>
                      </td>
                      <td className="py-3 px-2 text-right">
                        <Input
                          type="number"
                          value={tech.salary}
                          onChange={e => updateTech(tech.id, "salary", Number(e.target.value))}
                          className="w-24 text-right text-xs h-8 ml-auto"
                        />
                      </td>
                      <td className="py-3 px-2 text-right">
                        <Input
                          type="number"
                          value={tech.dailyRate}
                          onChange={e => updateTech(tech.id, "dailyRate", Number(e.target.value))}
                          className="w-20 text-right text-xs h-8 ml-auto"
                        />
                      </td>
                      <td className="py-3 px-2">
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="ghost" size="icon" className="size-6" onClick={() => updateTech(tech.id, "shopDays", Math.max(0, tech.shopDays - 1))}>
                            <Minus className="size-3" />
                          </Button>
                          <span className={`text-lg font-extrabold w-8 text-center ${tech.shopDays > tech.maxShopDays ? "text-red-600" : ""}`}>
                            {tech.shopDays}
                          </span>
                          <Button variant="ghost" size="icon" className="size-6" onClick={() => updateTech(tech.id, "shopDays", Math.min(22, tech.shopDays + 1))}>
                            <Plus className="size-3" />
                          </Button>
                        </div>
                      </td>
                      <td className="py-3 px-2 text-center text-sm font-medium">{c.billableDays}</td>
                      <td className="py-3 px-2 text-right text-xs font-semibold text-emerald-600">${Math.round(c.monthlyRevenue).toLocaleString()}</td>
                      <td className="py-3 px-2 text-right">
                        <span className={`font-bold ${c.utilization >= 85 ? "text-emerald-600" : c.utilization >= 70 ? "text-amber-600" : "text-red-600"}`}>
                          {c.utilization}%
                        </span>
                      </td>
                      <td className="py-3 px-2 text-right text-xs text-muted-foreground">${Math.round(c.totalCost).toLocaleString()}</td>
                      <td className="py-3 px-2 text-right">
                        <span className={`font-bold ${c.profit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                          ${Math.round(c.profit).toLocaleString()}
                        </span>
                      </td>
                      <td className="py-3 px-2">
                        <Button variant="ghost" size="icon" className="size-6 text-muted-foreground hover:text-destructive" onClick={() => removeTech(tech.id)}>
                          ×
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-foreground/20 bg-muted/30">
                  <td className="py-3 px-2 font-bold text-xs uppercase">Total ({techs.length})</td>
                  <td className="py-3 px-2 text-right font-bold text-xs">${Math.round(techs.reduce((s, t) => s + t.salary, 0)).toLocaleString()}</td>
                  <td className="py-3 px-2"></td>
                  <td className="py-3 px-2 text-center font-bold text-red-600">{totals.shopDays}</td>
                  <td className="py-3 px-2 text-center font-bold">{totals.billDays}</td>
                  <td className="py-3 px-2 text-right font-bold text-xs text-emerald-600">${Math.round(totals.revenue).toLocaleString()}</td>
                  <td className="py-3 px-2 text-right font-bold">{totals.avgUtil}%</td>
                  <td className="py-3 px-2 text-right font-bold text-xs">${Math.round(totals.cost).toLocaleString()}</td>
                  <td className="py-3 px-2 text-right font-extrabold text-emerald-600">${Math.round(totals.profit).toLocaleString()}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="lg:hidden space-y-3">
            {techs.map(tech => {
              const c = calcTechProfit(tech);
              return (
                <div key={tech.id} className={`border rounded-xl p-4 ${tech.isShopGuy ? "border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/10" : ""}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{tech.name}</span>
                      {tech.isShopGuy && <Badge className="bg-blue-600 text-[10px]">Shop Guy</Badge>}
                    </div>
                    <Button variant="ghost" size="icon" className="size-6 text-muted-foreground" onClick={() => removeTech(tech.id)}>×</Button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mb-3">
                    <div>
                      <label className="text-[10px] text-muted-foreground block mb-0.5">Annual Salary</label>
                      <Input type="number" value={tech.salary} onChange={e => updateTech(tech.id, "salary", Number(e.target.value))} className="text-xs h-8" />
                    </div>
                    <div>
                      <label className="text-[10px] text-muted-foreground block mb-0.5">Daily Rate</label>
                      <Input type="number" value={tech.dailyRate} onChange={e => updateTech(tech.id, "dailyRate", Number(e.target.value))} className="text-xs h-8" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-medium">Shop Days</span>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" className="size-7" onClick={() => updateTech(tech.id, "shopDays", Math.max(0, tech.shopDays - 1))}>
                        <Minus className="size-3" />
                      </Button>
                      <span className="text-xl font-extrabold w-8 text-center">{tech.shopDays}</span>
                      <Button variant="outline" size="icon" className="size-7" onClick={() => updateTech(tech.id, "shopDays", Math.min(22, tech.shopDays + 1))}>
                        <Plus className="size-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center">
                    <div className="bg-muted/50 rounded-lg p-2">
                      <div className="text-[9px] text-muted-foreground">Util</div>
                      <div className={`text-sm font-bold ${c.utilization >= 85 ? "text-emerald-600" : "text-red-600"}`}>{c.utilization}%</div>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-2">
                      <div className="text-[9px] text-muted-foreground">Billable</div>
                      <div className="text-sm font-bold">{c.billableDays}d</div>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-2">
                      <div className="text-[9px] text-muted-foreground">Revenue</div>
                      <div className="text-sm font-bold text-emerald-600">${(c.monthlyRevenue / 1000).toFixed(1)}K</div>
                    </div>
                    <div className={`rounded-lg p-2 ${c.profit >= 0 ? "bg-emerald-50 dark:bg-emerald-900/20" : "bg-red-50 dark:bg-red-900/20"}`}>
                      <div className="text-[9px] text-muted-foreground">Profit</div>
                      <div className={`text-sm font-bold ${c.profit >= 0 ? "text-emerald-600" : "text-red-600"}`}>${Math.round(c.profit).toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Revenue Impact Explainer ───────────────────────────────── */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-4">
          <p className="text-sm font-semibold flex items-center gap-2 mb-2">
            <Calculator className="size-4 text-primary" />
            How Shop Days Affect Profit
          </p>
          <div className="text-xs text-muted-foreground space-y-1">
            <p>• Each tech has a <strong>daily rate</strong> — what they generate per billable day on the field.</p>
            <p>• <strong>Revenue = daily rate × billable days</strong> (22 work days − shop days).</p>
            <p>• Adding 1 shop day removes 1 billable day → reduces revenue by the daily rate → directly lowers profit.</p>
            <p>• Cost (salary + 30% overhead) stays fixed regardless of shop days — that's why shop days hit margins hard.</p>
          </div>
        </CardContent>
      </Card>

      {/* ── Insights Panel ─────────────────────────────────────────── */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="border-emerald-200 dark:border-emerald-800 bg-emerald-50/30 dark:bg-emerald-950/10">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="size-4 text-emerald-600" />
              <span className="text-sm font-bold text-emerald-700 dark:text-emerald-400">Best Performer</span>
            </div>
            {(() => {
              const best = techs.filter(t => !t.isShopGuy).sort((a, b) => calcTechProfit(b).profit - calcTechProfit(a).profit)[0];
              if (!best) return null;
              const c = calcTechProfit(best);
              return (
                <div>
                  <p className="font-semibold">{best.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    ${Math.round(c.profit).toLocaleString()}/mo profit · {c.utilization}% utilization · {best.shopDays} shop days
                  </p>
                </div>
              );
            })()}
          </CardContent>
        </Card>

        <Card className="border-amber-200 dark:border-amber-800 bg-amber-50/30 dark:bg-amber-950/10">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="size-4 text-amber-600" />
              <span className="text-sm font-bold text-amber-700 dark:text-amber-400">Key Insight</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {profitDelta > 0 && `This scenario adds $${Math.round(profitDelta).toLocaleString()}/month in profit — $${Math.round(profitDelta * 12).toLocaleString()}/year. `}
              {profitDelta < 0 && `This scenario costs $${Math.abs(Math.round(profitDelta)).toLocaleString()}/month extra — $${Math.abs(Math.round(profitDelta * 12)).toLocaleString()}/year lost. `}
              {totals.shopDays > 25 && `${totals.shopDays} total shop days is high — consider the "Hire a Shop Guy" scenario to free up techs. `}
              {totals.avgUtil < 80 && `Avg utilization is ${totals.avgUtil}% — below the 85% target. Reduce shop days or reassign work. `}
              {totals.avgUtil >= 90 && totals.shopDays <= 25 && `Strong utilization at ${totals.avgUtil}% with manageable shop days. Margin is ${totals.margin}%. `}
              {profitDelta === 0 && totals.avgUtil >= 80 && totals.avgUtil < 90 && `Current scenario matches baseline. Try adjusting shop days or adding a shop guy to see impact. `}
              {shopDelta !== 0 && `Each shop day change shifts revenue by the tech's daily rate. ${Math.abs(shopDelta)} day${Math.abs(shopDelta) > 1 ? "s" : ""} ${shopDelta > 0 ? "added" : "removed"} vs baseline.`}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ── How to Use ─────────────────────────────────────────────── */}
      <Card>
        <CardContent className="p-4">
          <button
            onClick={() => setShowHowTo(!showHowTo)}
            className="flex items-center justify-between w-full text-left"
          >
            <span className="text-sm font-bold flex items-center gap-2">
              <Lightbulb className="size-4 text-primary" />
              How to Use This Calculator
            </span>
            {showHowTo ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
          </button>
          {showHowTo && (
            <div className="mt-3 space-y-2 text-xs text-muted-foreground">
              <p>1. <strong>Adjust shop days</strong> — Use +/− to change any tech's monthly shop days. Revenue drops automatically (fewer billable days = less revenue = less profit).</p>
              <p>2. <strong>Edit daily rates</strong> — If a tech's rate changes (different job mix, raise, etc.), update the daily rate and see the profit impact.</p>
              <p>3. <strong>Try a scenario</strong> — Click a preset above to model common situations (hiring, slow months, etc.)</p>
              <p>4. <strong>Add/remove techs</strong> — Use the + button to model hiring decisions before committing</p>
              <p>5. <strong>Compare</strong> — KPI cards at the top show the delta vs. your current baseline</p>
              <p>6. <strong>Reset</strong> — Click Reset to return to real current-month data anytime</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
