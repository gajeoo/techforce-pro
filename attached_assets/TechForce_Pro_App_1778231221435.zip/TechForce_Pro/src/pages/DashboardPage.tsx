import { useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  CalendarDays,
  Clock,
  DollarSign,
  Flame,
  TrendingDown,
  TrendingUp,
  Users,
  Wrench,
  Zap,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  employees,
  customers,
  profitAlerts,
  todayJobs,
  weekSchedule,
  employeeWeekSchedules,
} from "@/lib/mockData";

// ─── Helpers ────────────────────────────────────────────────────────────

function getDayBg(type: string) {
  if (type === "billable") return "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300";
  if (type === "shop") return "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 font-bold";
  if (type === "training") return "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300";
  if (type === "off") return "bg-muted text-muted-foreground";
  return "bg-muted/50 text-muted-foreground";
}

function getStatusColor(status: string) {
  if (status === "completed") return "bg-emerald-600";
  if (status === "in-progress") return "bg-blue-600";
  if (status === "return") return "bg-amber-600";
  if (status === "reschedule") return "bg-primary";
  if (status === "emergency") return "bg-red-600";
  return "bg-muted-foreground";
}

function getStatusLabel(status: string) {
  if (status === "completed") return "Done";
  if (status === "in-progress") return "Active";
  if (status === "return") return "Return";
  if (status === "reschedule") return "Reschedule";
  if (status === "emergency") return "Emergency";
  return "Pending";
}

// ─── Stats ──────────────────────────────────────────────────────────────

const todayRevenue = todayJobs.reduce((s, j) => s + j.revenue, 0);
const completedJobs = todayJobs.filter(j => j.status === "completed").length;
const activeJobs = todayJobs.filter(j => j.status === "in-progress").length;
const pendingJobs = todayJobs.filter(j => j.status === "pending").length;
const issueJobs = todayJobs.filter(j => j.status === "return" || j.status === "reschedule").length;

const stats = [
  {
    title: "Revenue Today",
    value: `$${todayRevenue.toLocaleString()}`,
    sub: `${todayJobs.length} jobs dispatched`,
    icon: DollarSign,
    color: "text-emerald-600",
    bg: "bg-emerald-100 dark:bg-emerald-900/30",
    link: "/jobs",
  },
  {
    title: "Revenue YTD",
    value: "$582K",
    sub: "+22% vs last year",
    icon: TrendingUp,
    color: "text-emerald-600",
    bg: "bg-emerald-100 dark:bg-emerald-900/30",
    link: "/reports",
  },
  {
    title: "Team Utilization",
    value: "89%",
    sub: "+4% from last month",
    icon: Users,
    color: "text-blue-600",
    bg: "bg-blue-100 dark:bg-blue-900/30",
    link: "/employees",
  },
  {
    title: "Lost to Shop Days",
    value: "$12,400",
    sub: "−14% vs last year",
    icon: TrendingDown,
    color: "text-red-600",
    bg: "bg-red-100 dark:bg-red-900/30",
    link: "/shop-calculator",
  },
];

// ─── Component ──────────────────────────────────────────────────────────

export function DashboardPage() {
  const navigate = useNavigate();
  const [emergencyOpen, setEmergencyOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Flame className="size-7 text-primary shrink-0" />
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Tuesday, June 10, 2026 — Columbia, MD
          </p>
        </div>
        <Dialog open={emergencyOpen} onOpenChange={setEmergencyOpen}>
          <DialogTrigger asChild>
            <Button variant="destructive" size="sm" className="gap-1.5 self-start sm:self-auto">
              <Zap className="size-3.5" /> Emergency Override
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-600">
                <Zap className="size-5" /> Emergency Job Override
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-300">
                Emergency override will reassign the nearest available technician immediately. This may reschedule existing jobs.
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Customer</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                    <SelectContent>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Override Tech</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Auto-assign" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto — Nearest Available</SelectItem>
                      {employees.map(e => (
                        <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs">Emergency Description</Label>
                <Textarea placeholder="Describe the emergency..." rows={3} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Address</Label>
                  <Input placeholder="123 Main St..." />
                </div>
                <div>
                  <Label className="text-xs">Estimated Revenue ($)</Label>
                  <Input type="number" placeholder="0" />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setEmergencyOpen(false)}>Cancel</Button>
                <Button variant="destructive" className="gap-1.5" onClick={() => setEmergencyOpen(false)}>
                  <Zap className="size-3.5" /> Dispatch Emergency
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* ── KPI Cards — clickable ─────────────────────────────────────── */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        {stats.map(stat => (
          <Card
            key={stat.title}
            className="relative overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => navigate(stat.link)}
          >
            <CardContent className="p-4 sm:p-5">
              <div className="flex items-start justify-between mb-3">
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider leading-tight">
                  {stat.title}
                </span>
                <div className={`rounded-lg p-2 ${stat.bg} shrink-0`}>
                  <stat.icon className={`size-4 ${stat.color}`} />
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-extrabold tracking-tight">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.sub}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Today's Status Bar ────────────────────────────────────────── */}
      <Card className="cursor-pointer hover:shadow-sm transition-shadow" onClick={() => navigate("/jobs")}>
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="size-4 text-primary" />
            <span className="text-sm font-bold">Today's Progress</span>
            <ArrowRight className="size-3 text-muted-foreground ml-auto" />
          </div>
          <div className="flex gap-1 h-3 rounded-full overflow-hidden mb-3">
            {completedJobs > 0 && (
              <div className="bg-emerald-500 transition-all" style={{ width: `${(completedJobs / todayJobs.length) * 100}%` }} />
            )}
            {activeJobs > 0 && (
              <div className="bg-blue-500 transition-all" style={{ width: `${(activeJobs / todayJobs.length) * 100}%` }} />
            )}
            {pendingJobs > 0 && (
              <div className="bg-gray-300 dark:bg-gray-600 transition-all" style={{ width: `${(pendingJobs / todayJobs.length) * 100}%` }} />
            )}
            {issueJobs > 0 && (
              <div className="bg-amber-500 transition-all" style={{ width: `${(issueJobs / todayJobs.length) * 100}%` }} />
            )}
          </div>
          <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs">
            <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-emerald-500" /> {completedJobs} Completed</span>
            <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-blue-500" /> {activeJobs} In Progress</span>
            <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-gray-400" /> {pendingJobs} Pending</span>
            <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-amber-500" /> {issueJobs} Needs Attention</span>
          </div>
        </CardContent>
      </Card>

      {/* ── Profit Alerts — clickable ─────────────────────────────────── */}
      {profitAlerts.length > 0 && (
        <Card className="border-red-200 dark:border-red-900/50 bg-red-50/50 dark:bg-red-950/20">
          <CardContent className="p-4 sm:p-5">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="size-4 text-red-600" />
              <span className="text-sm font-bold text-red-700 dark:text-red-400">Profit Leak Alerts</span>
              <Button variant="link" size="sm" className="ml-auto p-0 h-auto text-xs text-red-600" onClick={() => navigate("/shop-calculator")}>
                Open Calculator →
              </Button>
            </div>
            <div className="space-y-2">
              {profitAlerts.map((alert, i) => {
                return (
                  <div
                    key={i}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 py-2 border-b border-red-200/50 dark:border-red-800/30 last:border-0 text-sm cursor-pointer hover:bg-red-100/30 dark:hover:bg-red-900/10 rounded px-2 -mx-2 transition-colors"
                    onClick={() => navigate("/employees")}
                  >
                    <div>
                      <span className="font-semibold text-red-700 dark:text-red-400">{alert.tech}: </span>
                      <span className="text-muted-foreground">{alert.message}</span>
                    </div>
                    <Badge variant={alert.severity === "high" ? "destructive" : "secondary"} className="text-[10px] self-start sm:self-auto shrink-0">
                      {alert.severity}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Shop Day Tracker — clickable cards ────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <Wrench className="size-4 text-primary" />
                Shop Day Tracker — This Month
              </CardTitle>
              <CardDescription>Each tech's monthly shop day allocation and usage</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/shop-calculator" className="gap-1.5">
                Calculator <ArrowRight className="size-3" />
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {employees.map(emp => {
              const pct = (emp.shopDaysUsed / emp.shopDaysAllowed) * 100;
              const remaining = emp.shopDaysAllowed - emp.shopDaysUsed;
              const isWarning = pct >= 80;
              const isDanger = pct >= 100;
              return (
                <div
                  key={emp.id}
                  className={`rounded-xl border p-4 cursor-pointer hover:shadow-sm transition-all ${isDanger ? "border-red-300 bg-red-50/50 dark:border-red-800 dark:bg-red-950/20" : isWarning ? "border-amber-200 bg-amber-50/30 dark:border-amber-800 dark:bg-amber-950/10" : "border-border hover:border-primary/30"}`}
                  onClick={() => navigate("/employees")}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="size-8 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">
                        {emp.avatar}
                      </div>
                      <div>
                        <div className="text-sm font-semibold leading-tight">{emp.name.split(" ")[0]}</div>
                        <div className="text-[11px] text-muted-foreground">{emp.role}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-lg font-extrabold ${isDanger ? "text-red-600" : isWarning ? "text-amber-600" : "text-foreground"}`}>
                        {emp.shopDaysUsed}/{emp.shopDaysAllowed}
                      </div>
                      <div className="text-[10px] text-muted-foreground">{remaining > 0 ? `${remaining} left` : "maxed out"}</div>
                    </div>
                  </div>
                  <Progress
                    value={Math.min(pct, 100)}
                    className={`h-2 ${isDanger ? "[&>div]:bg-red-600" : isWarning ? "[&>div]:bg-amber-500" : ""}`}
                  />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Main Grid: Schedule + Dispatch ────────────────────────────── */}
      <div className="grid gap-6 lg:grid-cols-5">
        {/* Weekly Schedule — clickable rows */}
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-sm flex items-center gap-2">
                  <CalendarDays className="size-4" />
                  Week of June 9–13
                </CardTitle>
                <CardDescription>Revenue per day · Shop days in red</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/schedule" className="gap-1">Full Schedule <ArrowRight className="size-3" /></Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-1 font-medium text-muted-foreground text-xs">Tech</th>
                    <th className="text-left py-2 px-1 font-medium text-muted-foreground text-xs">Cert</th>
                    {["Mon", "Tue", "Wed", "Thu", "Fri"].map(d => (
                      <th key={d} className="text-center py-2 px-1 font-medium text-muted-foreground text-xs">{d}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {weekSchedule.map(row => {
                    const weekSched = employeeWeekSchedules.find(s => s.techId === row.techId);
                    return (
                      <tr
                        key={row.techId}
                        className="border-b border-muted/50 hover:bg-muted/20 cursor-pointer transition-colors"
                        onClick={() => navigate("/schedule")}
                      >
                        <td className="py-2 px-1 font-semibold text-xs">{row.techName}</td>
                        <td className="py-2 px-1">
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-primary border-primary/40">
                            {row.cert}
                          </Badge>
                        </td>
                        {row.days.map((day, di) => {
                          const dayJobs = weekSched?.days[di]?.jobs || [];
                          return (
                            <td key={di} className="py-1.5 px-0.5 text-center">
                              <div
                                className={`rounded px-1.5 py-1 text-xs font-medium ${getDayBg(day.type)} ${dayJobs.length > 0 ? "hover:ring-2 hover:ring-primary/40" : ""}`}
                                onClick={(e) => {
                                  if (dayJobs.length === 1) {
                                    e.stopPropagation();
                                    navigate(`/jobs/${dayJobs[0].id}`);
                                  }
                                }}
                              >
                                {day.value}
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {weekSchedule.slice(0, 4).map(row => (
                <div
                  key={row.techId}
                  className="border rounded-lg p-3 cursor-pointer hover:bg-muted/20 transition-colors"
                  onClick={() => navigate("/schedule")}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-sm">{row.techName}</span>
                    <Badge variant="outline" className="text-[10px] text-primary border-primary/40">{row.cert}</Badge>
                  </div>
                  <div className="flex gap-1">
                    {row.days.map((day, di) => (
                      <div key={di} className={`flex-1 rounded px-1 py-1.5 text-center text-[10px] font-medium ${getDayBg(day.type)}`}>
                        <div className="text-[9px] opacity-70 mb-0.5">{day.label}</div>
                        {day.value}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap justify-end gap-4 mt-3 text-xs text-muted-foreground">
              <span>Week Revenue: <strong className="text-emerald-600">$28,620</strong></span>
              <span>Cost: <strong>$7,550</strong></span>
              <span>Margin: <strong className="text-emerald-600">$21,070</strong></span>
            </div>
          </CardContent>
        </Card>

        {/* Today's Dispatch — clickable */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-sm">Today's Dispatch</CardTitle>
                <CardDescription>{todayJobs.length} jobs · ${todayRevenue.toLocaleString()}</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/jobs" className="gap-1">All Jobs <ArrowRight className="size-3" /></Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {todayJobs.slice(0, 6).map(job => (
                <div
                  key={job.id}
                  className="flex items-center gap-3 py-2.5 px-3 rounded-lg border hover:bg-muted/30 transition-colors cursor-pointer"
                  onClick={() => navigate(`/jobs/${job.id}`)}
                >
                  <div className="text-base shrink-0">{job.statusIcon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-semibold truncate text-primary">{job.client}</p>
                      <span className="text-xs font-bold text-emerald-600 shrink-0">${job.revenue.toLocaleString()}</span>
                    </div>
                    <p className="text-[11px] text-muted-foreground truncate">{job.type}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-muted-foreground">{job.techName} · {job.scheduledTime}</span>
                      <span className={`text-[9px] font-bold text-white px-1.5 py-0.5 rounded-full ${getStatusColor(job.status)}`}>
                        {getStatusLabel(job.status)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Employee Profit Table — clickable rows ────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm">Employee Profit Dashboard</CardTitle>
              <CardDescription>YTD ROI per technician — click through for details</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/employees" className="gap-1">All Employees <ArrowRight className="size-3" /></Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Employee</th>
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Role</th>
                  <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Revenue</th>
                  <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Salary Cost</th>
                  <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Net Profit</th>
                  <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Util</th>
                  <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Shop Days</th>
                </tr>
              </thead>
              <tbody>
                {employees.map(emp => {
                  const salaryCost = emp.salary * 0.4;
                  const netProfit = emp.revenueYTD - salaryCost;
                  const utilColor = emp.utilization >= 90 ? "text-emerald-600" : emp.utilization >= 85 ? "text-amber-600" : "text-red-600";
                  const shopPct = emp.shopDaysUsed / emp.shopDaysAllowed;
                  const shopColor = shopPct >= 0.8 ? "text-red-600" : "text-muted-foreground";
                  return (
                    <tr
                      key={emp.id}
                      className="border-b border-muted/50 hover:bg-muted/30 transition-colors cursor-pointer"
                      onClick={() => navigate("/employees")}
                    >
                      <td className="py-2.5 px-2">
                        <div className="flex items-center gap-2">
                          <div className="size-7 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary shrink-0">
                            {emp.avatar}
                          </div>
                          <span className="font-semibold text-xs text-primary">{emp.name}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-xs text-muted-foreground">{emp.role}</td>
                      <td className="py-2.5 px-2 text-right text-xs font-medium text-emerald-600">${emp.revenueYTD.toLocaleString()}</td>
                      <td className="py-2.5 px-2 text-right text-xs text-muted-foreground">${salaryCost.toLocaleString()}</td>
                      <td className="py-2.5 px-2 text-right text-xs font-bold">${Math.round(netProfit).toLocaleString()}</td>
                      <td className={`py-2.5 px-2 text-right text-xs font-bold ${utilColor}`}>{emp.utilization}%</td>
                      <td className={`py-2.5 px-2 text-right text-xs font-medium ${shopColor}`}>{emp.shopDaysUsed}/{emp.shopDaysAllowed}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-3">
            {employees.map(emp => {
              const netProfit = emp.revenueYTD - emp.salary * 0.4;
              return (
                <div
                  key={emp.id}
                  className="border rounded-lg p-3 cursor-pointer hover:bg-muted/20 transition-colors"
                  onClick={() => navigate("/employees")}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="size-8 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">
                        {emp.avatar}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-primary">{emp.name}</div>
                        <div className="text-[11px] text-muted-foreground">{emp.role}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-emerald-600">${(netProfit / 1000).toFixed(0)}K</div>
                      <div className="text-[10px] text-muted-foreground">profit</div>
                    </div>
                  </div>
                  <div className="flex gap-3 text-xs">
                    <span>Util: <strong className={emp.utilization >= 85 ? "text-emerald-600" : "text-red-600"}>{emp.utilization}%</strong></span>
                    <span>Shop: <strong>{emp.shopDaysUsed}/{emp.shopDaysAllowed}</strong></span>
                    <span>Rev: <strong>${(emp.revenueYTD / 1000).toFixed(0)}K</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
