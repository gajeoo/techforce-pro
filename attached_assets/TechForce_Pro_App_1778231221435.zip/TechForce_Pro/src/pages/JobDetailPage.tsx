import { useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  Calendar,
  Camera,
  CheckCircle2,
  Clock,
  Download,
  Eye,
  FileText,
  History,
  Image,
  MapPin,
  Phone,
  Plus,
  Upload,
  User,
  Wrench,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  allCustomerJobs,
  todayJobs,
  previousYearJobs,
  employees,
  customers,
  serviceCategoryColors,
} from "@/lib/mockData";
import type { JobDocument, PreviousYearJob } from "@/lib/mockData";

function getStatusBadge(status: string) {
  if (status === "completed") return <Badge variant="default" className="bg-emerald-600 text-xs">✅ Completed</Badge>;
  if (status === "in-progress") return <Badge variant="default" className="bg-blue-600 text-xs">🔧 In Progress</Badge>;
  if (status === "return") return <Badge variant="default" className="bg-amber-600 text-xs">🔄 Return Needed</Badge>;
  if (status === "reschedule") return <Badge variant="default" className="bg-primary text-xs">📅 Rescheduled</Badge>;
  if (status === "emergency") return <Badge variant="destructive" className="text-xs">🚨 Emergency</Badge>;
  return <Badge variant="secondary" className="text-xs">⏳ Pending</Badge>;
}

function getPriorityBadge(priority: string) {
  if (priority === "high") return <Badge variant="destructive" className="text-xs">HIGH</Badge>;
  if (priority === "medium") return <Badge variant="default" className="bg-amber-600 text-xs">MED</Badge>;
  return <Badge variant="secondary" className="text-xs">LOW</Badge>;
}

function DocumentCard({ doc, onView }: { doc: JobDocument; onView: (doc: JobDocument) => void }) {
  const isPhoto = doc.type === "photo";
  const icon = isPhoto ? <Image className="size-5 text-blue-500" /> : <FileText className="size-5 text-red-500" />;
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors group">
      <div className="size-12 rounded-lg bg-background border flex items-center justify-center shrink-0">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium truncate">{doc.name}</div>
        <div className="text-xs text-muted-foreground">{doc.uploadedBy} · {doc.uploadedAt} · {doc.size}</div>
      </div>
      <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          variant="outline"
          size="sm"
          className="h-7 gap-1 text-xs"
          onClick={(e) => { e.stopPropagation(); onView(doc); }}
        >
          <Eye className="size-3" /> View
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 gap-1 text-xs"
          onClick={(e) => e.stopPropagation()}
        >
          <Download className="size-3" />
        </Button>
      </div>
    </div>
  );
}

function PreviousYearJobCard({ job, onViewDoc }: { job: PreviousYearJob; onViewDoc: (doc: JobDocument) => void }) {
  const catColor = serviceCategoryColors[job.serviceCategory] || serviceCategoryColors["mixed"];
  return (
    <div className="p-4 rounded-lg border bg-muted/20 hover:bg-muted/30 transition-colors">
      <div className="flex items-start justify-between gap-2 mb-2">
        <div>
          <div className="font-semibold text-sm">{job.type}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{job.client}</div>
        </div>
        <div className="text-right shrink-0">
          <Badge className={`${catColor.bg} ${catColor.text} text-[10px] border-0`}>{catColor.label}</Badge>
        </div>
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground mt-2">
        <span className="flex items-center gap-1"><User className="size-3" /> {job.techName}</span>
        <span className="flex items-center gap-1"><Calendar className="size-3" /> {new Date(job.completedDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
        <span className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> {job.status === "completed" ? "Completed" : "Incomplete"}</span>
      </div>
      {job.documents.length > 0 && (
        <div className="mt-3 space-y-1.5">
          {job.documents.map(doc => (
            <DocumentCard key={doc.id} doc={doc} onView={onViewDoc} />
          ))}
        </div>
      )}
    </div>
  );
}

export function JobDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [addNoteOpen, setAddNoteOpen] = useState(false);
  const [noteText, setNoteText] = useState("");
  const [viewDocOpen, setViewDocOpen] = useState(false);
  const [viewingDoc, setViewingDoc] = useState<JobDocument | null>(null);

  function handleViewDoc(doc: JobDocument) {
    setViewingDoc(doc);
    setViewDocOpen(true);
  }

  // Find the job in all sources
  const allJobs = [...todayJobs, ...allCustomerJobs];
  const job = allJobs.find(j => j.id === id);

  if (!job) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <h2 className="text-xl font-bold">Job not found</h2>
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft className="size-4 mr-2" /> Go Back
        </Button>
      </div>
    );
  }

  const tech = employees.find(e => e.id === job.techId);
  const customer = customers.find(c => c.id === job.customerId);
  const location = customer?.locations.find(l => l.id === job.locationId);
  const catColor = serviceCategoryColors[job.serviceCategory] || serviceCategoryColors["mixed"];

  // Get other current year jobs at same location
  const otherCurrentJobs = allCustomerJobs.filter(j =>
    j.customerId === job.customerId &&
    j.locationId === job.locationId &&
    j.id !== job.id
  );

  // Get previous year jobs at same location
  const prevYearJobs = previousYearJobs.filter(j =>
    j.customerId === job.customerId &&
    (j.locationId === job.locationId || (!job.locationId && j.customerId === job.customerId))
  );

  // Schedule history (all completed jobs at this location)
  const scheduleHistory = [...otherCurrentJobs, ...allCustomerJobs.filter(j =>
    j.customerId === job.customerId && j.status === "completed" && j.id !== job.id
  )].filter((j, i, arr) => arr.findIndex(x => x.id === j.id) === i)
    .sort((a, b) => new Date(b.scheduledDate).getTime() - new Date(a.scheduledDate).getTime())
    .slice(0, 10);

  // Collect all documents from this job + previous year jobs for this location
  const allJobDocs = [...job.documents];

  return (
    <div className="space-y-6">
      {/* Back button */}
      <Button variant="ghost" size="sm" className="gap-1.5 -ml-2" onClick={() => navigate(-1)}>
        <ArrowLeft className="size-4" /> Back to Jobs
      </Button>

      {/* Job Header */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <Badge className={`${catColor.bg} ${catColor.text} text-xs border-0`}>{catColor.label}</Badge>
            {getStatusBadge(job.status)}
            {getPriorityBadge(job.priority)}
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">{job.type}</h1>
          <div className="text-muted-foreground mt-1 text-sm space-y-0.5">
            <div className="flex items-center gap-1.5">
              <MapPin className="size-3.5" />
              <span className="font-medium text-foreground">{job.client}</span>
              {location && <span className="text-muted-foreground">— {location.name}</span>}
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="size-3.5" />
              {job.address}
            </div>
          </div>
        </div>
        <div className="flex gap-2 shrink-0">
          <Dialog open={addNoteOpen} onOpenChange={setAddNoteOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5">
                <Plus className="size-3.5" /> Add Note
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Note to {job.id}</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <Textarea placeholder="Enter your note..." value={noteText} onChange={e => setNoteText(e.target.value)} rows={4} />
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setAddNoteOpen(false)}>Cancel</Button>
                  <Button onClick={() => setAddNoteOpen(false)}>Save Note</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Upload className="size-3.5" /> Upload File
          </Button>
        </div>
      </div>

      {/* Key Info Cards */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Service Type</div>
            <div className="text-lg font-bold">{catColor.label}</div>
            <div className="text-xs text-muted-foreground">{job.certRequired} required</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Assigned Tech</div>
            <div className="text-lg font-bold">{job.techName}</div>
            {tech && <div className="text-xs text-muted-foreground">{tech.role}</div>}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Scheduled</div>
            <div className="text-lg font-bold">{new Date(job.scheduledDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>
            <div className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="size-3" /> {job.scheduledTime}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Due Date</div>
            <div className="text-lg font-bold">{new Date(job.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>
            <div className="text-xs text-muted-foreground">Job #{job.id}</div>
          </CardContent>
        </Card>
      </div>

      {/* Customer Info + Notes */}
      {(customer || job.notes) && (
        <div className="grid gap-4 lg:grid-cols-2">
          {customer && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-1.5">
                  <User className="size-4 text-primary" /> Customer Info
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold">{customer.name}</span>
                  <Badge variant="outline" className="text-[10px]">{customer.type}</Badge>
                </div>
                <div className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <User className="size-3" /> {customer.contact}
                </div>
                <div className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <Phone className="size-3" /> {customer.phone}
                </div>
                <Button variant="link" size="sm" className="p-0 h-auto text-xs text-primary" onClick={() => navigate(`/customers/${customer.id}`)}>
                  View all {customer.name} jobs →
                </Button>
              </CardContent>
            </Card>
          )}
          {job.notes && (
            <Card className="border-amber-200 dark:border-amber-800 bg-amber-50/30 dark:bg-amber-950/10">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-1.5">
                  <FileText className="size-4 text-amber-600" /> Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{job.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Documents — with View/Open/Download */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm flex items-center gap-1.5">
              <FileText className="size-4 text-primary" /> Documents & Photos
              {allJobDocs.length > 0 && <Badge variant="secondary" className="text-[10px] ml-1">{allJobDocs.length}</Badge>}
            </CardTitle>
            <Button size="sm" variant="outline" className="gap-1.5 text-xs h-7">
              <Upload className="size-3" /> Upload
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {job.documents.length > 0 ? (
            <div className="grid gap-2 sm:grid-cols-2">
              {job.documents.map(doc => (
                <DocumentCard key={doc.id} doc={doc} onView={handleViewDoc} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Camera className="size-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No documents yet</p>
              <p className="text-xs">Upload photos, inspection reports, or certificates</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Previous Year History */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-1.5">
            <History className="size-4 text-primary" /> Previous Year History (2025)
            <Badge variant="secondary" className="text-[10px] ml-1">{prevYearJobs.length} jobs</Badge>
          </CardTitle>
          <p className="text-xs text-muted-foreground">What was done at this location last year — click documents to view</p>
        </CardHeader>
        <CardContent>
          {prevYearJobs.length > 0 ? (
            <div className="space-y-3">
              {prevYearJobs.map(pj => (
                <PreviousYearJobCard key={pj.id} job={pj} onViewDoc={handleViewDoc} />
              ))}
            </div>
          ) : (
            <div className="text-center py-6 text-muted-foreground">
              <History className="size-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No previous year history for this location</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Schedule History at this Location */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-1.5">
            <Wrench className="size-4 text-primary" /> Other Jobs at this Customer
            <Badge variant="secondary" className="text-[10px] ml-1">{scheduleHistory.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {scheduleHistory.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Date</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Job</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Tech</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Status</th>
                    <th className="text-center py-2 px-2 text-xs font-medium text-muted-foreground">Docs</th>
                  </tr>
                </thead>
                <tbody>
                  {scheduleHistory.map(sj => (
                    <tr
                      key={sj.id}
                      className="border-b border-muted/50 hover:bg-muted/20 transition-colors cursor-pointer"
                      onClick={() => navigate(`/jobs/${sj.id}`)}
                    >
                      <td className="py-2.5 px-2 text-xs">
                        {new Date(sj.scheduledDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      </td>
                      <td className="py-2.5 px-2">
                        <div className="text-xs font-semibold">{sj.type}</div>
                        <div className="text-[10px] text-muted-foreground">{sj.client}</div>
                      </td>
                      <td className="py-2.5 px-2 text-xs">{sj.techName}</td>
                      <td className="py-2.5 px-2">{getStatusBadge(sj.status)}</td>
                      <td className="py-2.5 px-2 text-center text-xs">{sj.documents.length > 0 ? `📎 ${sj.documents.length}` : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">No other jobs at this customer</p>
          )}
        </CardContent>
      </Card>

      {/* ─── Document Viewer Dialog ─── */}
      <Dialog open={viewDocOpen} onOpenChange={setViewDocOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {viewingDoc?.type === "photo" ? <Image className="size-5 text-blue-500" /> : <FileText className="size-5 text-red-500" />}
              {viewingDoc?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Preview area */}
            <div className="border rounded-lg bg-muted/30 overflow-hidden">
              {viewingDoc?.type === "photo" ? (
                <div className="aspect-[4/3] flex items-center justify-center bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/20">
                  <div className="text-center">
                    <Image className="size-16 mx-auto text-blue-400 mb-3" />
                    <p className="text-sm font-medium text-blue-700 dark:text-blue-300">{viewingDoc?.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">Photo preview would display here</p>
                  </div>
                </div>
              ) : (
                <div className="aspect-[3/4] max-h-[500px] flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/20 dark:to-orange-950/20">
                  <div className="text-center">
                    <FileText className="size-16 mx-auto text-red-400 mb-3" />
                    <p className="text-sm font-medium text-red-700 dark:text-red-300">{viewingDoc?.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">PDF document would render here</p>
                    <Button variant="outline" size="sm" className="mt-3 gap-1.5 text-xs">
                      <Eye className="size-3" /> Open in New Tab
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* File info */}
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="bg-muted/50 rounded-lg p-3">
                <div className="text-muted-foreground mb-0.5">Uploaded By</div>
                <div className="font-semibold">{viewingDoc?.uploadedBy}</div>
              </div>
              <div className="bg-muted/50 rounded-lg p-3">
                <div className="text-muted-foreground mb-0.5">Date</div>
                <div className="font-semibold">{viewingDoc?.uploadedAt}</div>
              </div>
              <div className="bg-muted/50 rounded-lg p-3">
                <div className="text-muted-foreground mb-0.5">Size</div>
                <div className="font-semibold">{viewingDoc?.size}</div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" className="gap-1.5 text-xs" onClick={() => setViewDocOpen(false)}>
                <X className="size-3" /> Close
              </Button>
              <Button className="gap-1.5 text-xs">
                <Download className="size-3" /> Download
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
