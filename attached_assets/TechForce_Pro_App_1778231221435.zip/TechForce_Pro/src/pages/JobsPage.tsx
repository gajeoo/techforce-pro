import { useNavigate } from "react-router-dom";
import {
  ArrowUpDown,
  Briefcase,
  Filter,
  Plus,
  Search,
} from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { todayJobs, returnJobs, rescheduleJobs, employees, customers } from "@/lib/mockData";

function getStatusBadge(status: string) {
  if (status === "completed") return <Badge variant="default" className="bg-emerald-600 text-[10px]">✅ Done</Badge>;
  if (status === "in-progress") return <Badge variant="default" className="bg-blue-600 text-[10px]">🔧 Active</Badge>;
  if (status === "return") return <Badge variant="default" className="bg-amber-600 text-[10px]">🔄 Return</Badge>;
  if (status === "reschedule") return <Badge variant="default" className="bg-primary text-[10px]">📅 Reschd</Badge>;
  if (status === "emergency") return <Badge variant="destructive" className="text-[10px]">🚨 Emergency</Badge>;
  return <Badge variant="secondary" className="text-[10px]">⏳ Pending</Badge>;
}

function getPriorityBadge(priority: string) {
  if (priority === "high") return <Badge variant="destructive" className="text-[10px]">HIGH</Badge>;
  if (priority === "medium") return <Badge variant="default" className="bg-amber-600 text-[10px]">MED</Badge>;
  return <Badge variant="secondary" className="text-[10px]">LOW</Badge>;
}

export function JobsPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);

  const filteredJobs = todayJobs.filter(
    j => j.client.toLowerCase().includes(search.toLowerCase()) ||
         j.techName.toLowerCase().includes(search.toLowerCase()) ||
         j.type.toLowerCase().includes(search.toLowerCase())
  );

  const todayRevenue = todayJobs.reduce((s, j) => s + j.revenue, 0);
  const completedRevenue = todayJobs.filter(j => j.status === "completed").reduce((s, j) => s + j.revenue, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Briefcase className="size-6 text-primary shrink-0" />
            Job Management
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {todayJobs.length} jobs today · ${todayRevenue.toLocaleString()} revenue · ${completedRevenue.toLocaleString()} collected
          </p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5 self-start sm:self-auto">
              <Plus className="size-3.5" /> Create Job
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Create New Job</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Customer</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                    <SelectContent>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Assigned Tech</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select tech" /></SelectTrigger>
                    <SelectContent>
                      {employees.map(e => (
                        <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs">Job Type</Label>
                <Input placeholder="e.g. Hood Suppression Inspection" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Scheduled Date</Label>
                  <Input type="date" />
                </div>
                <div>
                  <Label className="text-xs">Revenue ($)</Label>
                  <Input type="number" placeholder="0" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Priority</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Service Type</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Service type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="suppression">Suppression</SelectItem>
                      <SelectItem value="extinguisher">Extinguisher</SelectItem>
                      <SelectItem value="sprinkler">Sprinkler</SelectItem>
                      <SelectItem value="exit-light">Exit Light</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button onClick={() => setCreateOpen(false)}>Create Job</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="all" className="text-xs">All ({todayJobs.length})</TabsTrigger>
            <TabsTrigger value="returns" className="gap-1 text-xs">
              🔄 Returns <span className="ml-0.5 rounded-full bg-amber-600 text-white text-[10px] size-4 inline-flex items-center justify-center">{returnJobs.length}</span>
            </TabsTrigger>
            <TabsTrigger value="reschedule" className="gap-1 text-xs">
              📅 Reschd <span className="ml-0.5 rounded-full bg-primary text-white text-[10px] size-4 inline-flex items-center justify-center">{rescheduleJobs.length}</span>
            </TabsTrigger>
          </TabsList>
          <div className="flex gap-2">
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
              <Input placeholder="Search..." className="pl-8 w-full sm:w-48" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 shrink-0">
              <Filter className="size-3.5" /> Filter
            </Button>
          </div>
        </div>

        {/* All Jobs */}
        <TabsContent value="all">
          {/* Desktop Table */}
          <Card className="hidden md:block">
            <CardContent className="pt-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-foreground/20">
                    <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Time</th>
                    <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Priority</th>
                    <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">
                      <span className="flex items-center gap-1">Client / Job <ArrowUpDown className="size-3" /></span>
                    </th>
                    <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Tech</th>
                    <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Cert</th>
                    <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Revenue</th>
                    <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredJobs.map(job => (
                    <tr
                      key={job.id}
                      className="border-b border-muted/50 hover:bg-muted/20 transition-colors cursor-pointer"
                      onClick={() => navigate(`/jobs/${job.id}`)}
                    >
                      <td className="py-3 px-2 text-xs font-medium">{job.scheduledTime}</td>
                      <td className="py-3 px-2">{getPriorityBadge(job.priority)}</td>
                      <td className="py-3 px-2">
                        <div className="font-semibold text-xs text-primary hover:underline">{job.client}</div>
                        <div className="text-[11px] text-muted-foreground">{job.type}</div>
                      </td>
                      <td className="py-3 px-2 text-xs">{job.techName}</td>
                      <td className="py-3 px-2">
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-primary border-primary/40">{job.certRequired}</Badge>
                      </td>
                      <td className="py-3 px-2 text-right text-xs font-bold text-emerald-600">${job.revenue.toLocaleString()}</td>
                      <td className="py-3 px-2">{getStatusBadge(job.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-2">
            {filteredJobs.map(job => (
              <Card key={job.id} className="cursor-pointer hover:shadow-sm transition-shadow" onClick={() => navigate(`/jobs/${job.id}`)}>
                <CardContent className="p-3">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-sm">{job.statusIcon}</span>
                        <span className="text-sm font-bold truncate text-primary">{job.client}</span>
                      </div>
                      <div className="text-xs text-muted-foreground truncate">{job.type}</div>
                    </div>
                    <span className="text-sm font-bold text-emerald-600 shrink-0">${job.revenue.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">{job.scheduledTime}</span>
                    <span className="text-muted-foreground">·</span>
                    <span className="text-muted-foreground">{job.techName}</span>
                    <span className="ml-auto">{getStatusBadge(job.status)}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Returns */}
        <TabsContent value="returns">
          <div className="space-y-3">
            {returnJobs.map(job => (
              <Card key={job.id} className="border-amber-200 dark:border-amber-800 cursor-pointer hover:shadow-sm" onClick={() => navigate(`/jobs/${job.id}`)}>
                <CardContent className="p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">🔄</span>
                      <div>
                        <span className="font-semibold text-sm">{job.techName}</span>
                        <span className="text-muted-foreground text-sm"> — {job.client}</span>
                      </div>
                    </div>
                    <Badge variant="default" className="bg-amber-600 text-xs self-start sm:self-auto">Pending Return</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-1">{job.type}</p>
                  <p className="text-xs bg-amber-100/60 dark:bg-amber-900/20 p-2 rounded-lg">{job.notes}</p>
                  <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                    <span>Scheduled: {job.scheduledDate}</span>
                    <span className="font-bold text-emerald-600">${job.revenue.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Reschedules */}
        <TabsContent value="reschedule">
          <div className="space-y-3">
            {rescheduleJobs.map(job => (
              <Card key={job.id} className={`cursor-pointer hover:shadow-sm ${job.followUpDone ? "border-emerald-200 dark:border-emerald-800" : "border-primary/30"}`} onClick={() => navigate(`/jobs/${job.id}`)}>
                <CardContent className="p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{job.followUpDone ? "✅" : "📅"}</span>
                      <div>
                        <span className="font-semibold text-sm">{job.techName}</span>
                        <span className="text-muted-foreground text-sm"> — {job.client}</span>
                      </div>
                    </div>
                    {job.followUpDone
                      ? <Badge variant="default" className="bg-emerald-600 text-xs self-start sm:self-auto">Ready</Badge>
                      : <Badge className="bg-primary text-xs self-start sm:self-auto">⚠ Confirm Follow-up</Badge>
                    }
                  </div>
                  <p className="text-xs text-muted-foreground mb-1">{job.type}</p>
                  <p className="text-xs bg-muted/50 p-2 rounded-lg"><strong>Note:</strong> {job.notes}</p>
                  <div className="flex items-center justify-between mt-3">
                    <Button size="sm" variant={job.followUpDone ? "outline" : "default"} className="text-xs h-7" onClick={(e) => e.stopPropagation()}>
                      {job.followUpDone ? "Reschedule Job" : "Confirm Follow-Up"}
                    </Button>
                    <span className="text-xs font-bold text-emerald-600">${job.revenue.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
