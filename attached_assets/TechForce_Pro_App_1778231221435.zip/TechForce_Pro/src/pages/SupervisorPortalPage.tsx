import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertTriangle,
  ArrowUpDown,
  Check,
  CheckCircle2,
  ClipboardList,
  Clock,
  MapPin,
  Navigation,
  Phone,
  Shield,
  UserCheck,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  employees,
  todayJobs,
} from "@/lib/mockData";

// Shop day requests (simulated)
interface ShopRequest {
  id: string;
  techId: string;
  techName: string;
  date: string;
  reason: string;
  notes: string;
  status: "pending" | "approved" | "denied";
}

const initialRequests: ShopRequest[] = [
  { id: "SR-001", techId: "E-003", techName: "Derek Williams", date: "Jun 12, 2026", reason: "Recharging Extinguishers", notes: "Need to recharge 40 units for next week's route", status: "pending" },
  { id: "SR-002", techId: "E-005", techName: "Chris Taylor", date: "Jun 13, 2026", reason: "Truck Maintenance", notes: "Brake service overdue", status: "pending" },
  { id: "SR-003", techId: "E-001", techName: "Marcus Johnson", date: "Jun 11, 2026", reason: "Inventory & Stocking", notes: "Running low on O-rings and pull pins", status: "pending" },
];

// Live GPS tracker data (simulated) — NO revenue/financial info
const techLocations = [
  { id: "E-001", name: "Marcus J.", status: "on-job", location: "Applebee's — Columbia", address: "6181 Old Dobbin Ln", progress: 75, eta: "30 min left", gps: "39.2048° N, 76.8611° W", vehicle: "Truck #101", speed: "0 mph (parked)" },
  { id: "E-002", name: "Sarah C.", status: "en-route", location: "→ Howard County Schools", address: "Ellicott City, MD", progress: 40, eta: "15 min away", gps: "39.2679° N, 76.7984° W", vehicle: "Truck #102", speed: "42 mph" },
  { id: "E-003", name: "Derek W.", status: "on-job", location: "Hilton BWI", address: "1739 W Nursery Rd", progress: 90, eta: "10 min left", gps: "39.1812° N, 76.6685° W", vehicle: "Truck #103", speed: "0 mph (parked)" },
  { id: "E-004", name: "Mike R.", status: "shop", location: "Shop — Recharging", address: "8750 Bollman Pl, Savage", progress: 100, eta: "All day", gps: "39.1367° N, 76.8234° W", vehicle: "Truck #104", speed: "0 mph (parked)" },
  { id: "E-005", name: "Chris T.", status: "on-job", location: "Wells Fargo — Columbia", address: "6060 Majors Ln", progress: 50, eta: "45 min left", gps: "39.2123° N, 76.8456° W", vehicle: "Truck #105", speed: "0 mph (parked)" },
  { id: "E-006", name: "James B.", status: "en-route", location: "→ Chipotle — Rt 1", address: "8661 Baltimore National Pike", progress: 60, eta: "12 min away", gps: "39.2534° N, 76.8123° W", vehicle: "Truck #106", speed: "35 mph" },
];

// Operational alerts — no financial info
const operationalAlerts = [
  { tech: "Derek Williams", message: "Sprinkler certification expires in 60 days — schedule training", severity: "medium" as const },
  { tech: "James Rodriguez", message: "Extinguisher cert expires in 10 days — CRITICAL", severity: "high" as const },
  { tech: "Chris Taylor", message: "3 jobs rescheduled this month — needs supervisor review", severity: "medium" as const },
];

export function SupervisorPortalPage() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState(initialRequests);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [emergencyOpen, setEmergencyOpen] = useState(false);
  const [selectedTech, setSelectedTech] = useState<string>("");

  const onJobCount = techLocations.filter(t => t.status === "on-job").length;
  const enRouteCount = techLocations.filter(t => t.status === "en-route").length;
  const shopCount = techLocations.filter(t => t.status === "shop").length;
  const pendingRequests = requests.filter(r => r.status === "pending").length;

  function handleRequest(id: string, action: "approved" | "denied") {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: action } : r));
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Shield className="size-6 text-primary shrink-0" />
            Supervisor Dashboard
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Real-time team operations — {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
          </p>
        </div>
        <div className="flex gap-2 self-start sm:self-auto">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            onClick={() => navigate("/gps-tracking")}
          >
            <Navigation className="size-3.5" /> Live Map
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            onClick={() => setReassignOpen(true)}
          >
            <ArrowUpDown className="size-3.5" /> Reassign Job
          </Button>
          <Button
            variant="destructive"
            size="sm"
            className="gap-1.5"
            onClick={() => setEmergencyOpen(true)}
          >
            <Zap className="size-3.5" /> Emergency Dispatch
          </Button>
        </div>
      </div>

      {/* KPI Strip — Operational only, NO financial data */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-5">
        <Card className="cursor-pointer hover:shadow-sm transition-shadow" onClick={() => navigate("/jobs")}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">Jobs Today</span>
              <Wrench className="size-3.5 text-blue-600" />
            </div>
            <div className="text-xl font-extrabold">{todayJobs.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">On Job</span>
              <UserCheck className="size-3.5 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold text-emerald-600">{onJobCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">En Route</span>
              <Navigation className="size-3.5 text-blue-600" />
            </div>
            <div className="text-xl font-extrabold text-blue-600">{enRouteCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">In Shop</span>
              <Wrench className="size-3.5 text-red-600" />
            </div>
            <div className="text-xl font-extrabold text-red-600">{shopCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">Pending Approvals</span>
              <Clock className="size-3.5 text-amber-600" />
            </div>
            <div className="text-xl font-extrabold text-amber-600">{pendingRequests}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main grid */}
      <div className="grid gap-6 lg:grid-cols-5">
        {/* Live Team Tracker — GPS focused, NO revenue */}
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-sm flex items-center gap-2">
                  <MapPin className="size-4 text-primary" />
                  Live Team Tracker
                </CardTitle>
                <CardDescription>Real-time technician GPS locations & status</CardDescription>
              </div>
              <Button variant="outline" size="sm" className="gap-1 text-xs" onClick={() => navigate("/gps-tracking")}>
                <Navigation className="size-3" /> Full Map
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {techLocations.map(tech => {
                const statusColor = tech.status === "on-job" ? "text-emerald-600" : tech.status === "en-route" ? "text-blue-600" : tech.status === "shop" ? "text-red-600" : "text-gray-500";
                const statusBg = tech.status === "on-job" ? "bg-emerald-600" : tech.status === "en-route" ? "bg-blue-600" : tech.status === "shop" ? "bg-red-600" : "bg-emerald-500";
                return (
                  <div
                    key={tech.id}
                    className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/20 cursor-pointer transition-colors"
                    onClick={() => navigate("/gps-tracking")}
                  >
                    <div className="relative shrink-0">
                      <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                        {tech.name.split(" ").map(n => n[0]).join("")}
                      </div>
                      <div className={`absolute -bottom-0.5 -right-0.5 size-3.5 rounded-full border-2 border-white ${statusBg}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold">{tech.name}</span>
                        <Badge variant="secondary" className={`text-[9px] ${statusColor}`}>
                          {tech.status.replace("-", " ")}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">{tech.location}</p>
                      <div className="flex items-center gap-3 mt-1.5">
                        <Progress value={tech.progress} className="h-1.5 flex-1" />
                        <span className="text-[10px] text-muted-foreground shrink-0">{tech.eta}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-[10px] text-muted-foreground">
                        <span className="flex items-center gap-0.5"><Navigation className="size-2.5" /> {tech.vehicle}</span>
                        <span>{tech.speed}</span>
                      </div>
                    </div>
                    <Phone className="size-4 text-muted-foreground hover:text-primary shrink-0" />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Shop Day Requests */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Wrench className="size-4 text-primary" />
              Shop Day Requests
            </CardTitle>
            <CardDescription>{pendingRequests} pending approval</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {requests.map(req => (
                <div key={req.id} className={`rounded-lg border p-3 ${req.status === "pending" ? "border-amber-200 bg-amber-50/30 dark:border-amber-800 dark:bg-amber-950/10" : req.status === "approved" ? "border-emerald-200 bg-emerald-50/30 dark:border-emerald-800" : "border-red-200 bg-red-50/30 dark:border-red-800 opacity-60"}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold">{req.techName}</span>
                    <span className="text-[10px] text-muted-foreground">{req.date}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{req.reason}</p>
                  <p className="text-[11px] text-muted-foreground mt-1 italic">"{req.notes}"</p>

                  {/* Actions */}
                  <div className="flex items-center gap-2 mt-2">
                    {req.status === "pending" ? (
                      <>
                        <Button
                          size="sm"
                          className="gap-1 text-xs bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => handleRequest(req.id, "approved")}
                        >
                          <Check className="size-3" /> Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="gap-1 text-xs"
                          onClick={() => handleRequest(req.id, "denied")}
                        >
                          <X className="size-3" /> Deny
                        </Button>
                      </>
                    ) : (
                      <Badge variant={req.status === "approved" ? "default" : "destructive"} className="text-[10px]">
                        {req.status === "approved" ? <><CheckCircle2 className="size-3 mr-1" />Approved</> : <><X className="size-3 mr-1" />Denied</>}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Daily Team Activity — Operational focus, NO financial data */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <ClipboardList className="size-4 text-primary" />
                Today's Team Activity
              </CardTitle>
              <CardDescription>Jobs completed, current status, and certifications</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => navigate("/employees")}>
              All Techs
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-2 font-medium text-xs text-muted-foreground">Tech</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Jobs Done</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Total Jobs</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Units Serviced</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Current Location</th>
                  <th className="text-center py-2 px-2 font-medium text-xs text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {employees.map(emp => {
                  const jobsDone = Math.floor(Math.random() * 3) + 1;
                  const totalJobs = jobsDone + Math.floor(Math.random() * 2) + 1;
                  const units = jobsDone * (8 + Math.floor(Math.random() * 10));
                  const loc = techLocations.find(t => t.id === emp.id);
                  return (
                    <tr
                      key={emp.id}
                      className="border-b border-muted/50 hover:bg-muted/20 cursor-pointer transition-colors"
                      onClick={() => navigate("/employees")}
                    >
                      <td className="py-2.5 px-2">
                        <div className="flex items-center gap-2">
                          <div className="size-7 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">
                            {emp.avatar}
                          </div>
                          <div>
                            <span className="font-semibold text-xs text-primary">{emp.name.split(" ")[0]}</span>
                            <div className="text-[10px] text-muted-foreground">{loc?.vehicle || "—"}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-center text-xs font-bold">{jobsDone}</td>
                      <td className="py-2.5 px-2 text-center text-xs text-muted-foreground">{totalJobs}</td>
                      <td className="py-2.5 px-2 text-center text-xs">{units}</td>
                      <td className="py-2.5 px-2 text-center text-xs text-muted-foreground truncate max-w-[140px]">
                        {loc?.location || "Unknown"}
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <Badge variant="secondary" className={`text-[9px] ${loc?.status === "shop" ? "text-red-600" : loc?.status === "en-route" ? "text-blue-600" : "text-emerald-600"}`}>
                          {loc?.status?.replace("-", " ") || "active"}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Operational Alerts — no financial data */}
      {operationalAlerts.length > 0 && (
        <Card className="border-amber-200 dark:border-amber-900/50 bg-amber-50/50 dark:bg-amber-950/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="size-4 text-amber-600" />
              <span className="text-sm font-bold text-amber-700 dark:text-amber-400">Operational Alerts</span>
            </div>
            <div className="space-y-2">
              {operationalAlerts.map((alert, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between py-2 border-b border-amber-200/50 last:border-0 cursor-pointer hover:bg-amber-100/30 rounded px-2 -mx-2 transition-colors"
                  onClick={() => navigate("/employees")}
                >
                  <span className="text-sm">
                    <strong className="text-amber-700">{alert.tech}:</strong>{" "}
                    <span className="text-muted-foreground">{alert.message}</span>
                  </span>
                  <Badge variant={alert.severity === "high" ? "destructive" : "secondary"} className="text-[10px] shrink-0 ml-2">
                    {alert.severity}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reassign Job Dialog */}
      <Dialog open={reassignOpen} onOpenChange={setReassignOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowUpDown className="size-5 text-primary" />
              Reassign Job
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs">Select Job</Label>
              <Select>
                <SelectTrigger><SelectValue placeholder="Choose a job..." /></SelectTrigger>
                <SelectContent>
                  {todayJobs.map(j => (
                    <SelectItem key={j.id} value={j.id}>
                      {j.client} — {j.type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">From Tech</Label>
                <Select>
                  <SelectTrigger><SelectValue placeholder="Current tech" /></SelectTrigger>
                  <SelectContent>
                    {employees.map(e => (
                      <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">To Tech</Label>
                <Select value={selectedTech} onValueChange={setSelectedTech}>
                  <SelectTrigger><SelectValue placeholder="Assign to..." /></SelectTrigger>
                  <SelectContent>
                    {employees.map(e => (
                      <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs">Reason</Label>
              <Textarea placeholder="Why is this being reassigned?" rows={2} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setReassignOpen(false)}>Cancel</Button>
              <Button onClick={() => setReassignOpen(false)}>Reassign</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Emergency Dispatch Dialog */}
      <Dialog open={emergencyOpen} onOpenChange={setEmergencyOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Zap className="size-5" />
              Emergency Dispatch
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-300">
              This will immediately reassign the nearest available technician. Existing jobs may be delayed.
            </div>
            <div>
              <Label className="text-xs">Customer / Location</Label>
              <Input placeholder="Customer name or address..." />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Service Type</Label>
                <Select>
                  <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="suppression">Suppression</SelectItem>
                    <SelectItem value="extinguisher">Extinguisher</SelectItem>
                    <SelectItem value="sprinkler">Sprinkler</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Override Tech (optional)</Label>
                <Select>
                  <SelectTrigger><SelectValue placeholder="Auto-assign" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto — Nearest</SelectItem>
                    {employees.map(e => (
                      <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <Textarea placeholder="Describe the emergency..." rows={3} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setEmergencyOpen(false)}>Cancel</Button>
              <Button variant="destructive" className="gap-1.5" onClick={() => setEmergencyOpen(false)}>
                <Zap className="size-3.5" /> Dispatch Now
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
