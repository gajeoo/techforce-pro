import { useNavigate } from "react-router-dom";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Wrench,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { openJobs, employees, employeeWeekSchedules } from "@/lib/mockData";

function getDayBg(type: string) {
  if (type === "billable") return "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800";
  if (type === "shop") return "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 font-bold border-red-200 dark:border-red-800";
  if (type === "training") return "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800";
  if (type === "off") return "bg-muted text-muted-foreground border-border";
  return "bg-muted/50 text-muted-foreground border-border";
}

function getDayLabel(type: string, revenue: number) {
  if (type === "shop") return "SHOP";
  if (type === "training") return "Train";
  if (type === "off") return "OFF";
  if (type === "open") return "Open";
  return `$${revenue.toLocaleString()}`;
}

function getPriorityBadge(priority: string) {
  if (priority === "high") return <Badge variant="destructive" className="text-[10px]">HIGH</Badge>;
  if (priority === "medium") return <Badge variant="default" className="bg-amber-600 text-[10px]">MED</Badge>;
  return <Badge variant="secondary" className="text-[10px]">LOW</Badge>;
}

export function SchedulePage() {
  const navigate = useNavigate();

  // Compute week stats
  const totalBillable = employeeWeekSchedules.reduce((sum, emp) => sum + emp.weekRevenue, 0);
  const totalShopDays = employeeWeekSchedules.reduce((sum, emp) => sum + emp.shopDaysThisWeek, 0);
  const totalTraining = employeeWeekSchedules.reduce((sum, emp) =>
    sum + emp.days.filter(d => d.type === "training").length
  , 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <CalendarDays className="size-6 text-primary shrink-0" />
            Weekly Schedule
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            June 9–13, 2026
          </p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <Button variant="outline" size="icon" className="size-8"><ChevronLeft className="size-4" /></Button>
          <Button variant="outline" size="sm" className="text-xs">This Week</Button>
          <Button variant="outline" size="icon" className="size-8"><ChevronRight className="size-4" /></Button>
          <Button variant="destructive" size="sm" className="ml-2 gap-1.5 text-xs">
            <Zap className="size-3.5" /> Emergency
          </Button>
        </div>
      </div>

      {/* Week Summary Bar */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-3 sm:p-4 text-center">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Week Revenue</div>
            <div className="text-xl font-extrabold text-emerald-600">${totalBillable.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 sm:p-4 text-center">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Shop Days</div>
            <div className="text-xl font-extrabold text-red-600">{totalShopDays}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 sm:p-4 text-center">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Training Days</div>
            <div className="text-xl font-extrabold text-amber-600">{totalTraining}</div>
          </CardContent>
        </Card>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-xs">
        <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-emerald-100 dark:bg-emerald-900/30 border border-emerald-300" /> Billable</span>
        <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-red-100 dark:bg-red-900/30 border border-red-300" /> Shop Day</span>
        <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-amber-100 dark:bg-amber-900/30 border border-amber-300" /> Training</span>
      </div>

      {/* ═══ Employee Schedule Cards (both mobile and desktop) ═══ */}
      <div className="space-y-4">
        {employeeWeekSchedules.map(emp => {
          const empData = employees.find(e => e.id === emp.techId);

          return (
            <Card key={emp.techId} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardContent className="p-4 sm:p-5">
                {/* Employee Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <span className="font-bold text-base sm:text-lg">{emp.techName}</span>
                    <Badge variant="outline" className="text-[10px] sm:text-xs px-2 py-0.5 text-primary border-primary/40 font-semibold">
                      {emp.cert}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <span className="text-base sm:text-lg font-bold text-emerald-600">${emp.weekRevenue.toLocaleString()}</span>
                    {emp.shopDaysThisWeek > 0 && (
                      <span className="text-xs sm:text-sm text-red-600 font-bold ml-2">{emp.shopDaysThisWeek} shop</span>
                    )}
                  </div>
                </div>

                {/* Day Cards — 5 columns */}
                <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
                  {emp.days.map((day, di) => (
                    <div
                      key={di}
                      className={`rounded-xl border px-1.5 sm:px-3 py-2.5 sm:py-3 text-center transition-all ${getDayBg(day.type)} ${day.jobs.length > 0 ? "cursor-pointer hover:scale-[1.02] hover:shadow-sm" : ""}`}
                      onClick={() => {
                        if (day.jobs.length === 1) navigate(`/jobs/${day.jobs[0].id}`);
                      }}
                    >
                      <div className="text-[10px] sm:text-xs opacity-60 mb-0.5 font-medium">{day.label}</div>
                      <div className="text-sm sm:text-base font-bold">
                        {getDayLabel(day.type, day.revenue)}
                      </div>
                      {/* Show job count if multiple */}
                      {day.jobs.length > 1 && (
                        <div className="text-[9px] sm:text-[10px] opacity-70 mt-0.5">
                          {day.jobs.length} jobs
                        </div>
                      )}
                      {/* On larger screens, show client names */}
                      {day.jobs.length > 0 && (
                        <div className="hidden sm:block mt-1.5 space-y-0.5">
                          {day.jobs.slice(0, 2).map((j, ji) => (
                            <div
                              key={ji}
                              className="text-[10px] leading-tight opacity-70 truncate cursor-pointer hover:opacity-100"
                              onClick={(e) => { e.stopPropagation(); navigate(`/jobs/${j.id}`); }}
                            >
                              {j.client}
                            </div>
                          ))}
                          {day.jobs.length > 2 && (
                            <div className="text-[9px] opacity-50">+{day.jobs.length - 2} more</div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Shop days footer */}
                {empData && (
                  <div className="mt-3 pt-2 border-t text-[11px] sm:text-xs text-muted-foreground flex items-center gap-1.5">
                    <Wrench className="size-3" />
                    Shop days this month: {empData.shopDaysUsed}/{empData.shopDaysAllowed}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Open Jobs */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm">Open Jobs — Available for Assignment</CardTitle>
            <Button size="sm" className="text-xs" onClick={() => navigate("/jobs")}>View All Jobs</Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Desktop */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Priority</th>
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Job</th>
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Client</th>
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Cert</th>
                  <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Revenue</th>
                  <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Status</th>
                </tr>
              </thead>
              <tbody>
                {openJobs.map(job => (
                  <tr key={job.id} className={`border-b border-muted/50 hover:bg-muted/20 cursor-pointer transition-colors ${job.priority === "high" ? "bg-red-50/50 dark:bg-red-950/10" : ""}`}>
                    <td className="py-2.5 px-2">{getPriorityBadge(job.priority)}</td>
                    <td className="py-2.5 px-2 font-semibold text-xs">{job.job}</td>
                    <td className="py-2.5 px-2 text-xs text-muted-foreground">{job.client}</td>
                    <td className="py-2.5 px-2">
                      <Badge variant="outline" className="text-[10px] text-primary border-primary/40">{job.cert}</Badge>
                    </td>
                    <td className="py-2.5 px-2 text-right text-xs font-bold text-emerald-600">
                      {job.revenue > 0 ? `$${job.revenue.toLocaleString()}` : "—"}
                    </td>
                    <td className="py-2.5 px-2 text-xs text-muted-foreground italic">Unassigned</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile */}
          <div className="sm:hidden space-y-2">
            {openJobs.map(job => (
              <div key={job.id} className="border rounded-lg p-3 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    {getPriorityBadge(job.priority)}
                    <span className="text-xs font-bold truncate">{job.job}</span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">{job.client} · {job.cert}</div>
                </div>
                {job.revenue > 0 && <span className="text-xs font-bold text-emerald-600 shrink-0">${job.revenue}</span>}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
