import {
  Box,
  ChevronDown,
  ChevronRight,
  DollarSign,
  Edit2,
  Package,
  Plus,
  Search,
  Trash2,
  Wrench,
  X,
} from "lucide-react";
import { useCallback, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";

// ─── Types ──────────────────────────────────────────────────────────────

type CatalogProduct = {
  id: string;
  name: string;
  sku?: string;
  price?: number;
  unit?: string;
  description?: string;
};

type Catalog = {
  id: string;
  name: string;
  type: "product" | "service";
  products: CatalogProduct[];
};

// ─── Initial Data ───────────────────────────────────────────────────────

const initialCatalogs: Catalog[] = [
  // ── Products ──────────────────────────────────────────────────────
  {
    id: "cat-p1", name: "Breaker Bar", type: "product",
    products: [
      { id: "p1-1", name: "Breaker Bar — Standard 18\"", sku: "BB-18", price: 24.50, unit: "ea" },
      { id: "p1-2", name: "Breaker Bar — Heavy Duty 24\"", sku: "BB-24", price: 34.00, unit: "ea" },
    ],
  },
  {
    id: "cat-p2", name: "Fire Extinguishers", type: "product",
    products: [
      { id: "p2-1", name: "ABC Dry Chemical 5lb", sku: "FE-ABC5", price: 55.00, unit: "ea" },
      { id: "p2-2", name: "ABC Dry Chemical 10lb", sku: "FE-ABC10", price: 78.00, unit: "ea" },
      { id: "p2-3", name: "ABC Dry Chemical 20lb", sku: "FE-ABC20", price: 125.00, unit: "ea" },
      { id: "p2-4", name: "CO2 5lb", sku: "FE-CO2-5", price: 145.00, unit: "ea" },
      { id: "p2-5", name: "CO2 10lb", sku: "FE-CO2-10", price: 195.00, unit: "ea" },
      { id: "p2-6", name: "Class K Wet Chemical 6L", sku: "FE-K6L", price: 285.00, unit: "ea" },
      { id: "p2-7", name: "Water 2.5gal", sku: "FE-W25", price: 95.00, unit: "ea" },
    ],
  },
  {
    id: "cat-p3", name: "Hose Strap and Knuckle", type: "product",
    products: [
      { id: "p3-1", name: "Hose Strap — Nylon", sku: "HS-NYL", price: 3.50, unit: "ea" },
      { id: "p3-2", name: "Hose Knuckle — Brass", sku: "HK-BRS", price: 8.25, unit: "ea" },
      { id: "p3-3", name: "Hose Strap + Knuckle Kit", sku: "HSK-KIT", price: 10.50, unit: "kit" },
    ],
  },
  {
    id: "cat-p4", name: "Link G360", type: "product",
    products: [
      { id: "p4-1", name: "Link G360 — 165°F", sku: "LG360-165", price: 12.00, unit: "ea" },
      { id: "p4-2", name: "Link G360 — 212°F", sku: "LG360-212", price: 12.00, unit: "ea" },
      { id: "p4-3", name: "Link G360 — 286°F", sku: "LG360-286", price: 14.50, unit: "ea" },
    ],
  },
  {
    id: "cat-p5", name: "Link G500", type: "product",
    products: [
      { id: "p5-1", name: "Link G500 — 165°F", sku: "LG500-165", price: 15.00, unit: "ea" },
      { id: "p5-2", name: "Link G500 — 212°F", sku: "LG500-212", price: 15.00, unit: "ea" },
    ],
  },
  {
    id: "cat-p6", name: "Nozzle Cap", type: "product",
    products: [
      { id: "p6-1", name: "Nozzle Cap — Standard", sku: "NC-STD", price: 2.25, unit: "ea" },
      { id: "p6-2", name: "Nozzle Cap — Heavy Duty", sku: "NC-HD", price: 3.75, unit: "ea" },
    ],
  },
  {
    id: "cat-p7", name: "O-Ring", type: "product",
    products: [
      { id: "p7-1", name: "O-Ring — Valve Stem (10pk)", sku: "OR-VS10", price: 8.00, unit: "pk" },
      { id: "p7-2", name: "O-Ring — Cylinder Neck", sku: "OR-CN", price: 1.50, unit: "ea" },
      { id: "p7-3", name: "O-Ring Assortment Kit", sku: "OR-KIT", price: 22.00, unit: "kit" },
    ],
  },
  {
    id: "cat-p8", name: "OPEN Extinguisher", type: "product",
    products: [
      { id: "p8-1", name: "Open — Custom Extinguisher", sku: "OPEN-EXT", price: 0, unit: "ea", description: "Custom / non-standard extinguisher" },
    ],
  },
  {
    id: "cat-p9", name: "OPEN Part", type: "product",
    products: [
      { id: "p9-1", name: "Open — Misc Part", sku: "OPEN-PRT", price: 0, unit: "ea", description: "Custom / non-standard part" },
    ],
  },
  {
    id: "cat-p10", name: "Pull Pin", type: "product",
    products: [
      { id: "p10-1", name: "Pull Pin — Standard", sku: "PP-STD", price: 1.75, unit: "ea" },
      { id: "p10-2", name: "Pull Pin — Ring Style", sku: "PP-RING", price: 2.25, unit: "ea" },
    ],
  },
  {
    id: "cat-p11", name: "Service Collar", type: "product",
    products: [
      { id: "p11-1", name: "Service Collar — 2026", sku: "SC-2026", price: 0.85, unit: "ea" },
      { id: "p11-2", name: "Service Collar — 2025", sku: "SC-2025", price: 0.85, unit: "ea" },
    ],
  },
  {
    id: "cat-p12", name: "Tamper Seal", type: "product",
    products: [
      { id: "p12-1", name: "Tamper Seal — Red (100pk)", sku: "TS-RED100", price: 12.00, unit: "pk" },
      { id: "p12-2", name: "Tamper Seal — Yellow (100pk)", sku: "TS-YEL100", price: 12.00, unit: "pk" },
    ],
  },
  {
    id: "cat-p13", name: "Valve Stem", type: "product",
    products: [
      { id: "p13-1", name: "Valve Stem — Standard", sku: "VS-STD", price: 6.50, unit: "ea" },
      { id: "p13-2", name: "Valve Stem — Brass", sku: "VS-BRS", price: 9.00, unit: "ea" },
    ],
  },

  // ── Services ──────────────────────────────────────────────────────
  {
    id: "cat-s1", name: "6yr", type: "service",
    products: [
      { id: "s1-1", name: "6-Year Maintenance — Stored Pressure", sku: "6YR-SP", price: 22.00, unit: "ea" },
      { id: "s1-2", name: "6-Year Maintenance — Cartridge", sku: "6YR-CART", price: 28.00, unit: "ea" },
      { id: "s1-3", name: "6-Year Maintenance — CO2", sku: "6YR-CO2", price: 35.00, unit: "ea" },
    ],
  },
  {
    id: "cat-s2", name: "CT", type: "service",
    products: [
      { id: "s2-1", name: "Conductivity Test", sku: "CT-STD", price: 18.00, unit: "ea" },
    ],
  },
  {
    id: "cat-s3", name: "FE Inspection", type: "service",
    products: [
      { id: "s3-1", name: "Fire Extinguisher Annual Inspection", sku: "FEI-ANN", price: 25.00, unit: "ea" },
      { id: "s3-2", name: "Fire Extinguisher Monthly Spot Check", sku: "FEI-MON", price: 8.00, unit: "ea" },
    ],
  },
  {
    id: "cat-s4", name: "Hydro Test", type: "service",
    products: [
      { id: "s4-1", name: "Hydrostatic Test — Standard", sku: "HYD-STD", price: 35.00, unit: "ea" },
      { id: "s4-2", name: "Hydrostatic Test — Large Cylinder", sku: "HYD-LG", price: 55.00, unit: "ea" },
      { id: "s4-3", name: "Hydrostatic Test — CO2", sku: "HYD-CO2", price: 45.00, unit: "ea" },
    ],
  },
  {
    id: "cat-s5", name: "Labor", type: "service",
    products: [
      { id: "s5-1", name: "Standard Labor — Per Hour", sku: "LBR-HR", price: 85.00, unit: "hr" },
      { id: "s5-2", name: "Emergency / After Hours — Per Hour", sku: "LBR-EM", price: 135.00, unit: "hr" },
      { id: "s5-3", name: "Travel Time — Per Hour", sku: "LBR-TRV", price: 65.00, unit: "hr" },
    ],
  },
  {
    id: "cat-s6", name: "OPEN 6yr", type: "service",
    products: [
      { id: "s6-1", name: "Open — 6yr Maintenance (Custom)", sku: "OPEN-6YR", price: 0, unit: "ea", description: "Custom 6yr service" },
    ],
  },
  {
    id: "cat-s7", name: "OPEN FE", type: "service",
    products: [
      { id: "s7-1", name: "Open — FE Service (Custom)", sku: "OPEN-FE", price: 0, unit: "ea", description: "Custom FE service" },
    ],
  },
  {
    id: "cat-s8", name: "OPEN Hydro", type: "service",
    products: [
      { id: "s8-1", name: "Open — Hydro Test (Custom)", sku: "OPEN-HYD", price: 0, unit: "ea", description: "Custom hydro test" },
    ],
  },
  {
    id: "cat-s9", name: "OPEN Labor", type: "service",
    products: [
      { id: "s9-1", name: "Open — Labor (Custom)", sku: "OPEN-LBR", price: 0, unit: "hr", description: "Custom labor charge" },
    ],
  },
  {
    id: "cat-s10", name: "OPEN MISC", type: "service",
    products: [
      { id: "s10-1", name: "Open — Miscellaneous (Custom)", sku: "OPEN-MISC", price: 0, unit: "ea", description: "Custom misc service" },
    ],
  },
  {
    id: "cat-s11", name: "OPEN Recharge", type: "service",
    products: [
      { id: "s11-1", name: "Open — Recharge (Custom)", sku: "OPEN-RCH", price: 0, unit: "ea", description: "Custom recharge" },
    ],
  },
  {
    id: "cat-s12", name: "OPEN SS", type: "service",
    products: [
      { id: "s12-1", name: "Open — SS Service (Custom)", sku: "OPEN-SS", price: 0, unit: "ea", description: "Custom suppression service" },
    ],
  },
  {
    id: "cat-s13", name: "Recharge", type: "service",
    products: [
      { id: "s13-1", name: "Recharge — ABC Dry Chemical", sku: "RCH-ABC", price: 18.00, unit: "lb" },
      { id: "s13-2", name: "Recharge — CO2", sku: "RCH-CO2", price: 25.00, unit: "lb" },
      { id: "s13-3", name: "Recharge — Class K", sku: "RCH-K", price: 35.00, unit: "lb" },
      { id: "s13-4", name: "Recharge — Halotron", sku: "RCH-HAL", price: 45.00, unit: "lb" },
    ],
  },
  {
    id: "cat-s14", name: "SS Inspection", type: "service",
    products: [
      { id: "s14-1", name: "Suppression System Semi-Annual Inspection", sku: "SSI-SEMI", price: 250.00, unit: "system" },
      { id: "s14-2", name: "Suppression System Annual Inspection", sku: "SSI-ANN", price: 450.00, unit: "system" },
    ],
  },
  {
    id: "cat-s15", name: "SSC", type: "service",
    products: [
      { id: "s15-1", name: "Suppression System Certification", sku: "SSC-CERT", price: 150.00, unit: "system" },
    ],
  },
];

// ─── Sub-components ─────────────────────────────────────────────────────

function ProductRow({
  product,
  onDelete,
}: {
  product: CatalogProduct;
  onDelete: () => void;
}) {
  return (
    <div className="flex items-center gap-3 py-2 px-3 hover:bg-muted/30 rounded-lg transition-colors group">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">{product.name}</span>
          {product.sku && (
            <span className="text-[10px] text-muted-foreground bg-muted/50 rounded px-1.5 py-0.5">{product.sku}</span>
          )}
        </div>
        {product.description && (
          <p className="text-[11px] text-muted-foreground mt-0.5">{product.description}</p>
        )}
      </div>
      <div className="flex items-center gap-3 shrink-0">
        {product.price !== undefined && product.price > 0 && (
          <span className="text-sm font-bold text-emerald-600">
            ${product.price.toFixed(2)}{product.unit ? `/${product.unit}` : ""}
          </span>
        )}
        {product.price === 0 && (
          <span className="text-xs text-muted-foreground italic">Custom price</span>
        )}
        <Button variant="ghost" size="icon" className="size-6 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive">
          <Edit2 className="size-3" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-6 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
          onClick={onDelete}
        >
          <Trash2 className="size-3" />
        </Button>
      </div>
    </div>
  );
}

function CatalogCard({
  catalog,
  isExpanded,
  onToggle,
  onAddProduct,
  onDeleteProduct,
  onDeleteCatalog,
}: {
  catalog: Catalog;
  isExpanded: boolean;
  onToggle: () => void;
  onAddProduct: () => void;
  onDeleteProduct: (productId: string) => void;
  onDeleteCatalog: () => void;
}) {
  return (
    <Card className={`transition-all ${isExpanded ? "ring-1 ring-primary/20" : ""}`}>
      <CardContent className="p-0">
        <button
          onClick={onToggle}
          className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/20 transition-colors rounded-t-xl"
        >
          {isExpanded ? (
            <ChevronDown className="size-4 text-primary shrink-0" />
          ) : (
            <ChevronRight className="size-4 text-muted-foreground shrink-0" />
          )}
          <div className={`size-8 rounded-lg flex items-center justify-center shrink-0 ${
            catalog.type === "product" ? "bg-blue-100 dark:bg-blue-900/30" : "bg-amber-100 dark:bg-amber-900/30"
          }`}>
            {catalog.type === "product" ? (
              <Package className="size-4 text-blue-600 dark:text-blue-400" />
            ) : (
              <Wrench className="size-4 text-amber-600 dark:text-amber-400" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <span className="font-semibold text-sm">{catalog.name}</span>
          </div>
          <Badge variant="secondary" className="text-[10px] shrink-0">
            {catalog.products.length} item{catalog.products.length !== 1 ? "s" : ""}
          </Badge>
        </button>

        {isExpanded && (
          <div className="border-t">
            <div className="px-4 py-2 space-y-0.5">
              {catalog.products.map(product => (
                <ProductRow
                  key={product.id}
                  product={product}
                  onDelete={() => onDeleteProduct(product.id)}
                />
              ))}
              {catalog.products.length === 0 && (
                <p className="text-xs text-muted-foreground py-3 text-center">No items yet. Add one below.</p>
              )}
            </div>
            <div className="px-4 py-2 border-t flex items-center justify-between">
              <Button variant="ghost" size="sm" className="text-xs gap-1.5 text-primary hover:text-primary" onClick={onAddProduct}>
                <Plus className="size-3" /> Add Product
              </Button>
              <Button variant="ghost" size="sm" className="text-xs gap-1.5 text-muted-foreground hover:text-destructive" onClick={onDeleteCatalog}>
                <Trash2 className="size-3" /> Remove Catalog
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Add Catalog Modal ──────────────────────────────────────────────────

function AddCatalogForm({
  onAdd,
  onCancel,
}: {
  onAdd: (name: string, type: "product" | "service") => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const [type, setType] = useState<"product" | "service">("product");

  return (
    <Card className="border-primary/30 ring-1 ring-primary/10">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-bold">New Catalog</span>
          <Button variant="ghost" size="icon" className="size-6" onClick={onCancel}>
            <X className="size-3" />
          </Button>
        </div>
        <div className="flex gap-2 mb-3">
          <button
            onClick={() => setType("product")}
            className={`flex-1 p-2 rounded-lg border text-xs font-medium transition-all ${
              type === "product" ? "border-blue-500 bg-blue-50 dark:bg-blue-950/20 text-blue-700" : "hover:bg-muted/50"
            }`}
          >
            <Package className="size-4 mx-auto mb-1" />
            Product
          </button>
          <button
            onClick={() => setType("service")}
            className={`flex-1 p-2 rounded-lg border text-xs font-medium transition-all ${
              type === "service" ? "border-amber-500 bg-amber-50 dark:bg-amber-950/20 text-amber-700" : "hover:bg-muted/50"
            }`}
          >
            <Wrench className="size-4 mx-auto mb-1" />
            Service
          </button>
        </div>
        <Input
          placeholder="Catalog name..."
          value={name}
          onChange={e => setName(e.target.value)}
          className="text-sm mb-3"
          autoFocus
        />
        <Button
          size="sm"
          className="w-full"
          disabled={!name.trim()}
          onClick={() => { onAdd(name.trim(), type); }}
        >
          Create Catalog
        </Button>
      </CardContent>
    </Card>
  );
}

function AddProductForm({
  onAdd,
  onCancel,
}: {
  onAdd: (product: CatalogProduct) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const [sku, setSku] = useState("");
  const [price, setPrice] = useState("");
  const [unit, setUnit] = useState("ea");

  return (
    <div className="border rounded-xl p-3 bg-muted/20 mt-2">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-bold">Add New Product</span>
        <Button variant="ghost" size="icon" className="size-5" onClick={onCancel}>
          <X className="size-3" />
        </Button>
      </div>
      <div className="grid gap-2 grid-cols-2 sm:grid-cols-4">
        <Input placeholder="Name" value={name} onChange={e => setName(e.target.value)} className="text-xs h-8 col-span-2" autoFocus />
        <Input placeholder="SKU" value={sku} onChange={e => setSku(e.target.value)} className="text-xs h-8" />
        <div className="flex gap-1">
          <Input placeholder="Price" type="number" value={price} onChange={e => setPrice(e.target.value)} className="text-xs h-8 flex-1" />
          <Input placeholder="Unit" value={unit} onChange={e => setUnit(e.target.value)} className="text-xs h-8 w-14" />
        </div>
      </div>
      <Button
        size="sm"
        className="mt-2 text-xs"
        disabled={!name.trim()}
        onClick={() => {
          onAdd({
            id: `new-${Date.now()}`,
            name: name.trim(),
            sku: sku.trim() || undefined,
            price: price ? Number(price) : 0,
            unit: unit.trim() || "ea",
          });
        }}
      >
        Add
      </Button>
    </div>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────

export function CatalogPage() {
  const [catalogs, setCatalogs] = useState<Catalog[]>(initialCatalogs);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "product" | "service">("all");
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [showAddCatalog, setShowAddCatalog] = useState(false);
  const [addingProductTo, setAddingProductTo] = useState<string | null>(null);

  const toggleExpanded = useCallback((id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const addCatalog = useCallback((name: string, type: "product" | "service") => {
    setCatalogs(prev => [...prev, {
      id: `cat-new-${Date.now()}`,
      name,
      type,
      products: [],
    }]);
    setShowAddCatalog(false);
  }, []);

  const deleteCatalog = useCallback((id: string) => {
    setCatalogs(prev => prev.filter(c => c.id !== id));
    setExpandedIds(prev => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  }, []);

  const addProduct = useCallback((catalogId: string, product: CatalogProduct) => {
    setCatalogs(prev => prev.map(c =>
      c.id === catalogId ? { ...c, products: [...c.products, product] } : c
    ));
    setAddingProductTo(null);
  }, []);

  const deleteProduct = useCallback((catalogId: string, productId: string) => {
    setCatalogs(prev => prev.map(c =>
      c.id === catalogId ? { ...c, products: c.products.filter(p => p.id !== productId) } : c
    ));
  }, []);

  const filtered = catalogs.filter(c => {
    if (typeFilter !== "all" && c.type !== typeFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return c.name.toLowerCase().includes(q) ||
        c.products.some(p => p.name.toLowerCase().includes(q) || (p.sku && p.sku.toLowerCase().includes(q)));
    }
    return true;
  });

  const productCatalogs = filtered.filter(c => c.type === "product");
  const serviceCatalogs = filtered.filter(c => c.type === "service");

  const totalProducts = catalogs.filter(c => c.type === "product").reduce((s, c) => s + c.products.length, 0);
  const totalServices = catalogs.filter(c => c.type === "service").reduce((s, c) => s + c.products.length, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Box className="size-6 text-primary shrink-0" />
            Catalogs
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Manage products & services for invoicing
          </p>
        </div>
        <Button size="sm" className="gap-1.5 self-start sm:self-auto" onClick={() => setShowAddCatalog(true)}>
          <Plus className="size-3.5" /> New Catalog
        </Button>
      </div>

      {/* Summary */}
      <div className="grid gap-3 grid-cols-3">
        <Card>
          <CardContent className="p-4 text-center">
            <Package className="size-4 text-blue-600 mx-auto mb-1" />
            <div className="text-xl font-extrabold">{catalogs.filter(c => c.type === "product").length}</div>
            <div className="text-xs text-muted-foreground">Product Catalogs</div>
            <div className="text-[10px] text-muted-foreground">{totalProducts} items</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Wrench className="size-4 text-amber-600 mx-auto mb-1" />
            <div className="text-xl font-extrabold">{catalogs.filter(c => c.type === "service").length}</div>
            <div className="text-xs text-muted-foreground">Service Catalogs</div>
            <div className="text-[10px] text-muted-foreground">{totalServices} items</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <DollarSign className="size-4 text-emerald-600 mx-auto mb-1" />
            <div className="text-xl font-extrabold">{totalProducts + totalServices}</div>
            <div className="text-xs text-muted-foreground">Total Items</div>
          </CardContent>
        </Card>
      </div>

      {/* Search + Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input placeholder="Search catalogs & products..." className="pl-8" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-1 bg-muted/50 rounded-lg p-0.5 self-start">
          {(["all", "product", "service"] as const).map(t => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all capitalize ${
                typeFilter === t ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "all" ? "All" : t === "product" ? "Products" : "Services"}
            </button>
          ))}
        </div>
      </div>

      {/* Add Catalog Form */}
      {showAddCatalog && (
        <AddCatalogForm onAdd={addCatalog} onCancel={() => setShowAddCatalog(false)} />
      )}

      {/* Product Catalogs */}
      {(typeFilter === "all" || typeFilter === "product") && productCatalogs.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Package className="size-4 text-blue-600" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Products</h2>
            <Badge variant="secondary" className="text-[10px]">{productCatalogs.length}</Badge>
          </div>
          <div className="space-y-2">
            {productCatalogs.map(catalog => (
              <div key={catalog.id}>
                <CatalogCard
                  catalog={catalog}
                  isExpanded={expandedIds.has(catalog.id)}
                  onToggle={() => toggleExpanded(catalog.id)}
                  onAddProduct={() => setAddingProductTo(catalog.id)}
                  onDeleteProduct={pid => deleteProduct(catalog.id, pid)}
                  onDeleteCatalog={() => deleteCatalog(catalog.id)}
                />
                {addingProductTo === catalog.id && (
                  <AddProductForm
                    onAdd={product => addProduct(catalog.id, product)}
                    onCancel={() => setAddingProductTo(null)}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Service Catalogs */}
      {(typeFilter === "all" || typeFilter === "service") && serviceCatalogs.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Wrench className="size-4 text-amber-600" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Services</h2>
            <Badge variant="secondary" className="text-[10px]">{serviceCatalogs.length}</Badge>
          </div>
          <div className="space-y-2">
            {serviceCatalogs.map(catalog => (
              <div key={catalog.id}>
                <CatalogCard
                  catalog={catalog}
                  isExpanded={expandedIds.has(catalog.id)}
                  onToggle={() => toggleExpanded(catalog.id)}
                  onAddProduct={() => setAddingProductTo(catalog.id)}
                  onDeleteProduct={pid => deleteProduct(catalog.id, pid)}
                  onDeleteCatalog={() => deleteCatalog(catalog.id)}
                />
                {addingProductTo === catalog.id && (
                  <AddProductForm
                    onAdd={product => addProduct(catalog.id, product)}
                    onCancel={() => setAddingProductTo(null)}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {filtered.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            No catalogs match your search.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
