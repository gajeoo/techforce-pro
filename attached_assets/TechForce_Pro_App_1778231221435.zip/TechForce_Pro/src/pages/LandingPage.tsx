import {
  AlertTriangle,
  ArrowRight,
  CalendarDays,
  DollarSign,
  Flame,
  Shield,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { Link } from "react-router-dom";
import { TestUserLoginSection } from "@/components/TestUserLoginSection";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

const features = [
  {
    icon: CalendarDays,
    title: "AI-Powered Scheduling",
    description:
      "Auto-assign the right tech to the right job based on certs, proximity, and profit potential.",
  },
  {
    icon: DollarSign,
    title: "Profit-Per-Tech Tracking",
    description:
      "See real-time ROI for every technician: revenue, shop day costs, and utilization rates.",
  },
  {
    icon: AlertTriangle,
    title: "Profit Leak Alerts",
    description:
      "Automatic warnings when shop days exceed thresholds or utilization drops below targets.",
  },
  {
    icon: Users,
    title: "Cert-Based Workforce",
    description:
      "Manage suppression, sprinkler, extinguisher, and exit light certifications per tech.",
  },
  {
    icon: TrendingUp,
    title: "Customer Pricing Engine",
    description:
      "Per-customer, per-service pricing that auto-populates on every invoice.",
  },
  {
    icon: Shield,
    title: "Compliance Tracking",
    description:
      "Service history ensures every location stays up to code with zero missed inspections.",
  },
];

export function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="size-9 rounded-lg bg-primary flex items-center justify-center">
              <Flame className="size-5 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-tight">TechForce Pro</span>
              <span className="text-[11px] text-muted-foreground leading-tight">by Multicorp Fire Protection</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/login">Sign in</Link>
            </Button>
            <Button size="sm" asChild>
              <Link to="/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 md:py-28 border-b">
        <div className="container text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-semibold rounded-full px-4 py-1.5 mb-6">
            <Zap className="size-3.5" /> Built for Multicorp Fire Protection Services
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
            Turn Shop Days Into
            <span className="text-primary"> Billable Revenue</span>
          </h1>
          <p className="text-lg text-muted-foreground mt-6 max-w-2xl mx-auto">
            TechForce Pro gives dispatchers, supervisors, and owners real-time visibility into
            tech utilization, profit per employee, and scheduling gaps — so every day counts.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
            <Button size="lg" className="gap-2" asChild>
              <Link to="/signup">
                Start Demo <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/login">Sign In</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-muted/30 border-b">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { value: "6", label: "Active Technicians" },
              { value: "180+", label: "Service Locations" },
              { value: "89%", label: "Team Utilization" },
              { value: "$582K", label: "Revenue YTD" },
            ].map(stat => (
              <div key={stat.label}>
                <div className="text-3xl md:text-4xl font-extrabold text-primary">{stat.value}</div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold">Everything You Need to Run a Profitable Fire Protection Business</h2>
            <p className="text-muted-foreground mt-3 max-w-xl mx-auto">
              Purpose-built for fire protection — not a generic field service tool.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map(feature => (
              <Card key={feature.title} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                    <feature.icon className="size-5 text-primary" />
                  </div>
                  <CardTitle className="text-base">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t bg-primary/5">
        <div className="container text-center max-w-2xl mx-auto">
          <Flame className="size-10 text-primary mx-auto mb-4" />
          <h2 className="text-2xl md:text-3xl font-bold mb-3">
            Ready to Maximize Your Crew's Output?
          </h2>
          <p className="text-muted-foreground mb-6">
            Stop losing revenue to unnecessary shop days. See exactly where your money goes.
          </p>
          <Button size="lg" className="gap-2" asChild>
            <Link to="/signup">
              Start Using TechForce Pro <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Test Login (preview only) */}
      <TestUserLoginSection />

      {/* Footer */}
      <footer className="py-8 border-t">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Flame className="size-4 text-primary" />
            <span>© 2026 Multicorp Fire Protection Services</span>
          </div>
          <span>9693 Gerwig Lane, Columbia, MD 21046 · (410) 876-5000</span>
        </div>
      </footer>
    </div>
  );
}
