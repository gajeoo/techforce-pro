import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  Award,
  Calendar,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Phone,
  Plus,
  TrendingUp,
  UserCheck,
  Users,
  Wrench,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { employees, employeeWeekSchedules } from "@/lib/mockData";

function getStatusBadge(status: string) {
  if (status === "on-job") return <Badge variant="default" className="bg-emerald-600 text-[10px]">On Job</Badge>;
  if (status === "shop") return <Badge variant="default" className="bg-red-600 text-[10px]">Shop Day</Badge>;
  if (status === "off") return <Badge variant="secondary" className="text-[10px]">Off</Badge>;
  return <Badge variant="outline" className="text-[10px]">Available</Badge>;
}

function getDayBg(type: string) {
  if (type === "billable") return "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300";
  if (type === "shop") return "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 font-bold";
  if (type === "training") return "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300";
  return "bg-muted text-muted-foreground";
}

export function EmployeesPage() {
  const navigate = useNavigate();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  const totalRevenue = employees.reduce((s, e) => s + e.revenueYTD, 0);
  const avgUtil = Math.round(employees.reduce((s, e) => s + e.utilization, 0) / employees.length);
  const totalShopUsed = employees.reduce((s, e) => s + e.shopDaysUsed, 0);
  const totalShopAllowed = employees.reduce((s, e) => s + e.shopDaysAllowed, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Users className="size-6 text-primary shrink-0" />
            Employees
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {employees.length} technicians · Managing shop days & profitability
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5 self-start sm:self-auto">
              <Plus className="size-3.5" /> Add Employee
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Employee</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Full Name</Label><Input placeholder="John Smith" /></div>
                <div><Label className="text-xs">Phone</Label><Input placeholder="(410) 555-0000" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Role</Label><Input placeholder="Suppression Lead" /></div>
                <div><Label className="text-xs">Annual Salary</Label><Input type="number" placeholder="55000" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Bill Rate ($/day)</Label><Input type="number" placeholder="900" /></div>
                <div><Label className="text-xs">Shop Days/Month</Label><Input type="number" placeholder="3" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
                <Button onClick={() => setAddOpen(false)}>Add Employee</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Revenue YTD</span>
              <DollarSign className="size-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold">${(totalRevenue / 1000).toFixed(0)}K</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Avg Utilization</span>
              <TrendingUp className="size-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold">{avgUtil}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Shop Days Used</span>
              <UserCheck className="size-4 text-amber-600" />
            </div>
            <div className="text-xl font-extrabold">{totalShopUsed} / {totalShopAllowed}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Active Techs</span>
              <Award className="size-4 text-primary" />
            </div>
            <div className="text-xl font-extrabold">{employees.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Employee Cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {employees.map(emp => {
          const netProfit = emp.revenueYTD - (emp.salary * 0.4);
          const utilColor = emp.utilization >= 90 ? "text-emerald-600" : emp.utilization >= 85 ? "text-amber-600" : "text-red-600";
          const shopPercent = (emp.shopDaysUsed / emp.shopDaysAllowed) * 100;
          const shopWarning = shopPercent >= 80;
          const shopDanger = shopPercent >= 100;
          const remaining = emp.shopDaysAllowed - emp.shopDaysUsed;
          const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];
          const weekSched = employeeWeekSchedules.find(s => s.techId === emp.id);
          const isExpanded = expandedId === emp.id;

          return (
            <Card key={emp.id} className="hover:shadow-md transition-shadow overflow-hidden">
              {/* Top accent stripe */}
              <div className={`h-1 ${emp.utilization >= 90 ? "bg-emerald-500" : emp.utilization >= 85 ? "bg-amber-500" : "bg-red-500"}`} />

              <CardHeader className="pb-2 pt-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                      {emp.avatar}
                    </div>
                    <div>
                      <CardTitle className="text-base">{emp.name}</CardTitle>
                      <CardDescription className="text-xs">{emp.role}</CardDescription>
                      <div className="flex items-center gap-1 mt-1 text-[10px] text-muted-foreground">
                        <Phone className="size-3" /> {emp.phone}
                      </div>
                    </div>
                  </div>
                  {getStatusBadge(emp.status)}
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Certifications */}
                <div className="flex flex-wrap gap-1.5">
                  {emp.certs.map(cert => (
                    <Badge key={cert} variant="outline" className="text-[10px] px-2 py-0.5 text-primary border-primary/30 font-medium">
                      {cert}
                    </Badge>
                  ))}
                  <span className="text-[10px] text-muted-foreground ml-1 self-center">Since {new Date(emp.hireDate).getFullYear()}</span>
                </div>

                {/* Revenue & Profit */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-lg p-2.5">
                    <div className="text-[10px] text-emerald-600 font-medium">Revenue YTD</div>
                    <div className="text-sm font-extrabold text-emerald-700 dark:text-emerald-400">${(emp.revenueYTD / 1000).toFixed(0)}K</div>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-2.5">
                    <div className="text-[10px] text-blue-600 font-medium">Net Profit</div>
                    <div className="text-sm font-extrabold text-blue-700 dark:text-blue-400">${(netProfit / 1000).toFixed(0)}K</div>
                  </div>
                  <div className="bg-muted rounded-lg p-2.5">
                    <div className="text-[10px] text-muted-foreground font-medium">Bill Rate</div>
                    <div className="text-sm font-extrabold">${emp.billRate.toLocaleString()}</div>
                  </div>
                </div>

                {/* Utilization */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-muted-foreground">Utilization</span>
                    <span className={`font-bold ${utilColor}`}>{emp.utilization}%</span>
                  </div>
                  <Progress value={emp.utilization} className="h-2.5" />
                </div>

                {/* Shop Days */}
                <div className={`rounded-xl border p-3 ${shopDanger ? "border-red-300 bg-red-50/60 dark:border-red-800 dark:bg-red-950/20" : shopWarning ? "border-amber-200 bg-amber-50/40 dark:border-amber-800 dark:bg-amber-950/10" : "border-border bg-muted/30"}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="size-3.5 text-primary" />
                      <span className="text-xs font-bold">Shop Days This Month</span>
                    </div>
                    <div className={`text-lg font-extrabold ${shopDanger ? "text-red-600" : shopWarning ? "text-amber-600" : "text-foreground"}`}>
                      {emp.shopDaysUsed}/{emp.shopDaysAllowed}
                    </div>
                  </div>
                  <Progress
                    value={Math.min(shopPercent, 100)}
                    className={`h-2 mb-2 ${shopDanger ? "[&>div]:bg-red-600" : shopWarning ? "[&>div]:bg-amber-500" : ""}`}
                  />
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-muted-foreground">{remaining > 0 ? `${remaining} remaining` : "⚠ All used"}</span>
                    <span className="text-muted-foreground">Daily cost: ${Math.round(emp.salary / 260).toLocaleString()}</span>
                  </div>

                  {/* Mini shop day history */}
                  <div className="mt-2 pt-2 border-t border-border/50">
                    <div className="text-[10px] text-muted-foreground mb-1">6-Month History</div>
                    <div className="flex gap-1 items-end">
                      {emp.shopDayHistory.map((days, i) => {
                        const maxDays = emp.shopDaysAllowed;
                        const h = Math.max(8, (days / Math.max(maxDays, 1)) * 28);
                        const over = days > emp.shopDaysAllowed;
                        return (
                          <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
                            <div
                              className={`w-full rounded-t-sm ${over ? "bg-red-400" : days >= maxDays * 0.8 ? "bg-amber-400" : "bg-primary/40"}`}
                              style={{ height: `${h}px` }}
                            />
                            <span className="text-[8px] text-muted-foreground">{months[i]}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Weekly Schedule Inline (collapsible) */}
                {weekSched && (
                  <div>
                    <button
                      className="flex items-center gap-1.5 text-xs font-semibold text-primary w-full justify-between hover:underline"
                      onClick={() => setExpandedId(isExpanded ? null : emp.id)}
                    >
                      <span className="flex items-center gap-1"><Wrench className="size-3" /> This Week's Schedule</span>
                      {isExpanded ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
                    </button>
                    {isExpanded && (
                      <div className="mt-2 space-y-2">
                        <div className="grid grid-cols-5 gap-1">
                          {weekSched.days.map((day, di) => (
                            <div
                              key={di}
                              className={`rounded-lg px-1 py-2 text-center ${getDayBg(day.type)} ${day.jobs.length > 0 ? "cursor-pointer" : ""}`}
                              onClick={() => {
                                if (day.jobs.length === 1) navigate(`/jobs/${day.jobs[0].id}`);
                              }}
                            >
                              <div className="text-[9px] opacity-60 mb-0.5">{day.label}</div>
                              <div className="text-xs font-bold">
                                {day.type === "shop" ? "SHOP" : day.type === "training" ? "Train" : `$${day.revenue.toLocaleString()}`}
                              </div>
                              {day.jobs.length > 0 && day.jobs.map((j, ji) => (
                                <div key={ji} className="text-[8px] opacity-60 truncate mt-0.5">{j.client}</div>
                              ))}
                            </div>
                          ))}
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                          <span>Week revenue: <strong className="text-emerald-600">${weekSched.weekRevenue.toLocaleString()}</strong></span>
                          {weekSched.shopDaysThisWeek > 0 && (
                            <span className="text-red-600 font-bold">{weekSched.shopDaysThisWeek} shop days</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Footer */}
                <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t">
                  <span>Salary: ${(emp.salary / 1000).toFixed(0)}K/yr</span>
                  <span>This month: ${emp.revenueThisMonth.toLocaleString()}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
