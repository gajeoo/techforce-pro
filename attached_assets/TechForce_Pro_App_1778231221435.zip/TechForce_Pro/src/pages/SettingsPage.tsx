import { useAuthActions } from "@convex-dev/auth/react";
import { useMutation, useQuery } from "convex/react";
import {
  Bell,
  Bot,
  Calendar,
  ChevronRight,
  Loader2,
  Moon,
  Palette,
  Save,
  Settings2,
  Shield,
  Sun,
  User,
  Wrench,
} from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useTheme } from "@/contexts/ThemeContext";
import { api } from "../../convex/_generated/api";

// Shop Day Rules matching Blueprint Section 04
const defaultRules = {
  monthlyCap: 3,
  consecutiveLimit: 2,
  weekBalance: 1,
  autoConvertThreshold: 75,
  trainingExemption: true,
  overrideAuthority: "supervisor",
  minShopDayFloor: 1,
  fatiguePreventionDays: 5,
};

// Auto-decline rules from Section 08
const defaultAutoDecline = {
  distanceLimit: 45,
  revenueFloor: 400,
  certMismatch: true,
};

export function SettingsPage() {
  const user = useQuery(api.auth.currentUser);
  const { theme, toggleTheme, switchable } = useTheme();
  const { signIn, signOut } = useAuthActions();
  const deleteAccount = useMutation(api.users.deleteAccount);
  const navigate = useNavigate();

  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [deleteAccountOpen, setDeleteAccountOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [passwordStep, setPasswordStep] = useState<"request" | "verify">("request");
  const [rules, setRules] = useState(defaultRules);
  const [autoDecline, setAutoDecline] = useState(defaultAutoDecline);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveRules = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleRequestPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const formData = new FormData();
    formData.append("email", user?.email || "");
    formData.append("flow", "reset");
    try {
      await signIn("password", formData);
      setPasswordStep("verify");
    } catch {
      setError("Could not send reset code. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    formData.append("email", user?.email || "");
    formData.append("flow", "reset-verification");
    try {
      await signIn("password", formData);
      setSuccess("Password changed successfully!");
      setTimeout(() => { setChangePasswordOpen(false); setPasswordStep("request"); setSuccess(""); }, 1500);
    } catch {
      setError("Invalid code or password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    setLoading(true);
    setError("");
    try {
      await deleteAccount();
      await signOut();
      navigate("/");
    } catch {
      setError("Could not delete account. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
          <Settings2 className="size-6 text-primary shrink-0" />
          Settings
        </h1>
        <p className="text-muted-foreground mt-1 text-sm">System configuration, rules engine, and account management</p>
      </div>

      <Tabs defaultValue="rules" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="rules" className="text-xs">Shop Day Rules</TabsTrigger>
          <TabsTrigger value="ai" className="text-xs">AI & Scheduling</TabsTrigger>
          <TabsTrigger value="notifications" className="text-xs">Notifications</TabsTrigger>
          <TabsTrigger value="account" className="text-xs">Account</TabsTrigger>
        </TabsList>

        {/* ═══ Shop Day Rules Engine ═══ (Blueprint Section 04) */}
        <TabsContent value="rules">
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Wrench className="size-4 text-primary" />
                  Shop Day Rules Engine
                </CardTitle>
                <CardDescription>
                  Management sets the rules — the system enforces them automatically. Changes apply to all technicians.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Monthly Cap */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Monthly Cap (per tech)</Label>
                      <Badge variant="outline" className="text-[10px]">Per-tech or per-role</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Maximum shop days allowed per technician per month</p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={rules.monthlyCap}
                        onChange={e => setRules(r => ({ ...r, monthlyCap: +e.target.value }))}
                        className="w-20"
                        min={0}
                        max={22}
                      />
                      <span className="text-sm text-muted-foreground">days/month</span>
                    </div>
                  </div>

                  {/* Consecutive Limit */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Consecutive Limit</Label>
                      <Badge variant="outline" className="text-[10px]">Default: 2</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Max consecutive shop days before a billable day is required</p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={rules.consecutiveLimit}
                        onChange={e => setRules(r => ({ ...r, consecutiveLimit: +e.target.value }))}
                        className="w-20"
                        min={1}
                        max={5}
                      />
                      <span className="text-sm text-muted-foreground">consecutive days</span>
                    </div>
                  </div>

                  {/* Week Balance */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Week Balance</Label>
                      <Badge variant="outline" className="text-[10px]">Default: 1</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">No more than X shop days per week</p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={rules.weekBalance}
                        onChange={e => setRules(r => ({ ...r, weekBalance: +e.target.value }))}
                        className="w-20"
                        min={0}
                        max={5}
                      />
                      <span className="text-sm text-muted-foreground">days/week</span>
                    </div>
                  </div>

                  {/* Auto-Convert Threshold */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Auto-Convert Threshold</Label>
                      <Badge variant="outline" className="text-[10px]">Default: 75%</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">When shop days exceed X% of allocation, auto-suggest conversions</p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={rules.autoConvertThreshold}
                        onChange={e => setRules(r => ({ ...r, autoConvertThreshold: +e.target.value }))}
                        className="w-20"
                        min={50}
                        max={100}
                      />
                      <span className="text-sm text-muted-foreground">% of allocation</span>
                    </div>
                  </div>
                </div>

                {/* Toggle rules */}
                <div className="border-t pt-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Training Day Exemption</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Training days don't count toward shop day limits</p>
                    </div>
                    <Switch
                      checked={rules.trainingExemption}
                      onCheckedChange={v => setRules(r => ({ ...r, trainingExemption: v }))}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Override Authority</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Who can approve extra shop days beyond allocation</p>
                    </div>
                    <Select value={rules.overrideAuthority} onValueChange={v => setRules(r => ({ ...r, overrideAuthority: v }))}>
                      <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="supervisor">Supervisor</SelectItem>
                        <SelectItem value="owner">Owner Only</SelectItem>
                        <SelectItem value="both">Supervisor + Owner</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Minimum Shop Day Floor</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Each tech guaranteed this minimum per month (can't be converted)</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={rules.minShopDayFloor}
                        onChange={e => setRules(r => ({ ...r, minShopDayFloor: +e.target.value }))}
                        className="w-16"
                        min={0}
                        max={5}
                      />
                      <span className="text-xs text-muted-foreground">days</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Fatigue Prevention</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">No tech works more than X consecutive billable days without a break</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={rules.fatiguePreventionDays}
                        onChange={e => setRules(r => ({ ...r, fatiguePreventionDays: +e.target.value }))}
                        className="w-16"
                        min={3}
                        max={10}
                      />
                      <span className="text-xs text-muted-foreground">days</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-muted-foreground">
                    System will recalculate profitability targets automatically after changes.
                  </div>
                  <Button className="gap-1.5" onClick={handleSaveRules}>
                    <Save className="size-3.5" />
                    {saveSuccess ? "✓ Saved!" : "Save Rules"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Per-Tech Overrides */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Calendar className="size-4 text-primary" />
                  Per-Tech Shop Day Allocations
                </CardTitle>
                <CardDescription>Override the default for individual technicians based on role and seniority</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Tech</th>
                        <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Role</th>
                        <th className="text-center py-2 px-2 font-medium text-muted-foreground text-xs">Monthly Allocation</th>
                        <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Daily Cost</th>
                        <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Target Utilization</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { name: "Sarah Johnson", role: "Suppression Lead", days: 2, cost: 327, target: "90%+" },
                        { name: "Derek Williams", role: "Sprinkler Tech", days: 3, cost: 269, target: "85%+" },
                        { name: "Marcus Taylor", role: "Extinguisher Tech", days: 3, cost: 212, target: "85%+" },
                        { name: "Kevin Park", role: "Extinguisher Tech", days: 3, cost: 212, target: "85%+" },
                        { name: "Angela Davis", role: "Suppression Tech", days: 2, cost: 288, target: "90%+" },
                        { name: "James Rodriguez", role: "Helper / Apprentice", days: 4, cost: 154, target: "80%+" },
                      ].map(t => (
                        <tr key={t.name} className="border-b border-muted/50 hover:bg-muted/20">
                          <td className="py-2.5 px-2 text-xs font-medium">{t.name}</td>
                          <td className="py-2.5 px-2 text-xs text-muted-foreground">{t.role}</td>
                          <td className="py-2.5 px-2 text-center">
                            <Input type="number" defaultValue={t.days} className="w-16 mx-auto text-center h-7 text-xs" min={0} max={22} />
                          </td>
                          <td className="py-2.5 px-2 text-right text-xs">${t.cost}/day</td>
                          <td className="py-2.5 px-2 text-right text-xs font-medium">{t.target}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ═══ AI & Scheduling Settings ═══ (Blueprint Section 08) */}
        <TabsContent value="ai">
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Bot className="size-4 text-primary" />
                  AI Scheduler & Smart Assignment
                </CardTitle>
                <CardDescription>Configure how the AI auto-assigns jobs and handles scheduling conflicts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Certification Match Required</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">Techs must hold the required cert for auto-assignment</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Shop Day Auto-Conversion</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">Suggest converting shop days when open jobs match cert</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Geography-Based Assignment</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">Nearest tech to job site preferred</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Customer Priority Weighting</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">HIGH priority jobs get offered first in suggestions</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>

            {/* Auto-Decline Rules */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Shield className="size-4 text-primary" />
                  Auto-Decline Rules
                </CardTitle>
                <CardDescription>Automatically deprioritize or decline certain assignments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Distance Limit</Label>
                  <p className="text-xs text-muted-foreground">No jobs beyond this distance from base</p>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={autoDecline.distanceLimit}
                      onChange={e => setAutoDecline(r => ({ ...r, distanceLimit: +e.target.value }))}
                      className="w-20"
                    />
                    <span className="text-sm text-muted-foreground">miles</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Revenue Floor (Suppression Techs)</Label>
                  <p className="text-xs text-muted-foreground">High-cert techs should take high-value jobs</p>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={autoDecline.revenueFloor}
                      onChange={e => setAutoDecline(r => ({ ...r, revenueFloor: +e.target.value }))}
                      className="w-24"
                    />
                    <span className="text-sm text-muted-foreground">$ minimum</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Strict Cert Mismatch</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">Never assign exit light jobs to suppression techs, etc.</p>
                  </div>
                  <Switch
                    checked={autoDecline.certMismatch}
                    onCheckedChange={v => setAutoDecline(r => ({ ...r, certMismatch: v }))}
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <Button className="gap-1.5" onClick={handleSaveRules}>
                    <Save className="size-3.5" /> Save AI Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ═══ Notifications ═══ */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Bell className="size-4 text-primary" />
                Notification Preferences
              </CardTitle>
              <CardDescription>Configure alerts, scheduled reports, and email delivery</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Shop Day Alerts</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Notify when a tech is at or over their shop day limit</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Emergency Override Alerts</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Immediate notification for emergency dispatches</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Cert Expiry Warnings</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Alert 30/60/90 days before certification expires</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Invoice Payment Reminders</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Auto-remind for invoices at 30, 60, 90 days</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="border-t pt-4">
                <h4 className="text-sm font-bold mb-3">Scheduled Report Delivery</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <div className="text-sm font-medium">Weekly Utilization Report</div>
                      <div className="text-xs text-muted-foreground">Every Monday at 7:00 AM</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <div className="text-sm font-medium">Monthly P&L Summary</div>
                      <div className="text-xs text-muted-foreground">1st of each month at 8:00 AM</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <div className="text-sm font-medium">Daily Dispatch Summary</div>
                      <div className="text-xs text-muted-foreground">Every day at 6:30 AM</div>
                    </div>
                    <Switch />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══ Account ═══ */}
        <TabsContent value="account">
          <div className="space-y-6 max-w-2xl">
            <Card className="overflow-hidden">
              <div className="h-20 bg-gradient-to-r from-primary/20 via-primary/10 to-transparent" />
              <CardContent className="-mt-10 pb-6">
                <div className="flex items-end gap-4">
                  <Avatar className="size-16 border-4 border-background shadow-lg">
                    <AvatarFallback className="text-xl bg-primary text-primary-foreground">
                      {user?.name?.charAt(0).toUpperCase() || <User className="size-6" />}
                    </AvatarFallback>
                  </Avatar>
                  <div className="pb-1">
                    <p className="font-semibold">{user?.name || "User"}</p>
                    <p className="text-sm text-muted-foreground">{user?.email}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Palette className="size-4 text-muted-foreground" />
                  Appearance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1">
                {switchable ? (
                  <div className="flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-muted/50">
                    <div className="flex items-center gap-4">
                      <div className="size-10 rounded-full bg-secondary flex items-center justify-center">
                        {theme === "light" ? <Moon className="size-5 text-foreground" /> : <Sun className="size-5 text-foreground" />}
                      </div>
                      <div>
                        <Label htmlFor="dark-mode" className="font-medium">Dark mode</Label>
                        <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
                      </div>
                    </div>
                    <Switch id="dark-mode" checked={theme === "dark"} onCheckedChange={toggleTheme} />
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground px-4 py-2">Theme follows your system preference</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-base">
                  <User className="size-4 text-muted-foreground" />
                  Account
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1">
                <button
                  onClick={() => setChangePasswordOpen(true)}
                  className="w-full flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-muted/50 text-left"
                >
                  <div>
                    <p className="font-medium text-sm">Change password</p>
                    <p className="text-sm text-muted-foreground">Update your password</p>
                  </div>
                  <ChevronRight className="size-4 text-muted-foreground" />
                </button>
                <button
                  onClick={() => setDeleteAccountOpen(true)}
                  className="w-full flex items-center justify-between rounded-lg border border-destructive/20 p-4 transition-colors hover:bg-destructive/5 text-left"
                >
                  <div>
                    <p className="font-medium text-sm text-destructive">Delete account</p>
                    <p className="text-sm text-muted-foreground">Permanently delete your account</p>
                  </div>
                  <ChevronRight className="size-4 text-destructive" />
                </button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Change Password Dialog */}
      <Dialog open={changePasswordOpen} onOpenChange={setChangePasswordOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
            <DialogDescription>
              {passwordStep === "request" ? "We'll send a verification code to your email." : "Enter the code from your email and your new password."}
            </DialogDescription>
          </DialogHeader>
          {passwordStep === "request" ? (
            <form onSubmit={handleRequestPasswordReset}>
              <div className="py-4">
                <p className="text-sm text-muted-foreground">
                  A reset code will be sent to: <span className="font-medium text-foreground">{user?.email}</span>
                </p>
              </div>
              {error && <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2 mb-4">{error}</p>}
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setChangePasswordOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                  {loading && <Loader2 className="size-4 animate-spin" />} Send Code
                </Button>
              </DialogFooter>
            </form>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">Verification Code</Label>
                <Input id="code" name="code" type="text" placeholder="Enter code from email" autoComplete="one-time-code" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newPassword">New Password</Label>
                <Input id="newPassword" name="newPassword" type="password" placeholder="••••••••" minLength={6} autoComplete="new-password" required />
              </div>
              {error && <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>}
              {success && <p className="text-sm text-emerald-600 bg-emerald-50 rounded-lg px-3 py-2">{success}</p>}
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setPasswordStep("request"); setError(""); }}>Back</Button>
                <Button type="submit" disabled={loading}>
                  {loading && <Loader2 className="size-4 animate-spin" />} Change Password
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={deleteAccountOpen} onOpenChange={setDeleteAccountOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Account</DialogTitle>
            <DialogDescription>This action cannot be undone. This will permanently delete your account and remove all your data.</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground">Are you sure you want to delete your account?</p>
          </div>
          {error && <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteAccountOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin" />} Delete Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
