import {
  AlertTriangle,
  ArrowUpRight,
  Award,
  BarChart3,
  Calendar,
  Clock,
  DollarSign,
  Download,
  FileSpreadsheet,
  Mail,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { employees, monthlyRevenue } from "@/lib/mockData";

// ─── Per-tech profitability ─────────────────────────────────────────────

const techProfitability = employees.map(emp => {
  const monthlyCost = emp.salary * 1.3 / 12;
  const monthlyRevenue = emp.revenueThisMonth;
  const profit = monthlyRevenue - monthlyCost;
  const roi = Math.round((profit / monthlyCost) * 100);
  const shopCostPerDay = Math.round(emp.salary / 260);
  const shopCostTotal = emp.shopDaysUsed * shopCostPerDay;
  return { ...emp, monthlyCost, profit, roi, shopCostPerDay, shopCostTotal };
}).sort((a, b) => b.roi - a.roi);

// ─── Invoice aging data ────────────────────────────────────────────────

const invoiceAging = [
  { id: "INV-2456", client: "BCOGov (Glen Arm)", amount: 3250, issued: "May 12, 2026", due: "Jul 11, 2026", age: 25, bucket: "current" as const },
  { id: "INV-2448", client: "Howard County Public Schools", amount: 2800, issued: "May 1, 2026", due: "Jun 30, 2026", age: 36, bucket: "30" as const },
  { id: "INV-2435", client: "Metro Office Park", amount: 1500, issued: "Apr 15, 2026", due: "Jun 14, 2026", age: 52, bucket: "30" as const },
  { id: "INV-2421", client: "Hilton BWI Airport", amount: 4200, issued: "Apr 2, 2026", due: "Jun 1, 2026", age: 65, bucket: "60" as const },
  { id: "INV-2398", client: "Harbor Condos", amount: 1850, issued: "Mar 10, 2026", due: "May 9, 2026", age: 88, bucket: "60" as const },
  { id: "INV-2376", client: "Applebee's — Columbia", amount: 600, issued: "Feb 20, 2026", due: "Apr 21, 2026", age: 106, bucket: "90" as const },
  { id: "INV-2452", client: "Olive Garden — Columbia", amount: 1400, issued: "May 8, 2026", due: "Jul 7, 2026", age: 29, bucket: "current" as const },
  { id: "INV-2440", client: "Chipotle — Rt 1", amount: 950, issued: "Apr 22, 2026", due: "Jun 21, 2026", age: 45, bucket: "30" as const },
  { id: "INV-2410", client: "Wells Fargo — Columbia", amount: 2100, issued: "Mar 25, 2026", due: "May 24, 2026", age: 73, bucket: "60" as const },
  { id: "INV-2388", client: "Lincoln Elementary", amount: 980, issued: "Mar 5, 2026", due: "May 4, 2026", age: 93, bucket: "90" as const },
];

const agingBuckets = {
  current: invoiceAging.filter(i => i.bucket === "current"),
  "30": invoiceAging.filter(i => i.bucket === "30"),
  "60": invoiceAging.filter(i => i.bucket === "60"),
  "90": invoiceAging.filter(i => i.bucket === "90"),
};

// ─── Cert tracker data ──────────────────────────────────────────────────

const certTracker = [
  { tech: "Sarah Johnson", cert: "Suppression", expiry: "Dec 2026", status: "current" as const, daysLeft: 210 },
  { tech: "Sarah Johnson", cert: "Extinguisher", expiry: "Mar 2027", status: "current" as const, daysLeft: 300 },
  { tech: "Derek Williams", cert: "Sprinkler", expiry: "Aug 2026", status: "expiring" as const, daysLeft: 60 },
  { tech: "Marcus Taylor", cert: "Extinguisher", expiry: "Nov 2026", status: "current" as const, daysLeft: 180 },
  { tech: "Kevin Park", cert: "Extinguisher", expiry: "Jul 2026", status: "expiring" as const, daysLeft: 25 },
  { tech: "Kevin Park", cert: "Exit Lights", expiry: "Sep 2026", status: "current" as const, daysLeft: 90 },
  { tech: "Angela Davis", cert: "Suppression", expiry: "Oct 2026", status: "current" as const, daysLeft: 150 },
  { tech: "James Rodriguez", cert: "Extinguisher", expiry: "Jun 2026", status: "critical" as const, daysLeft: 10 },
];

// ─── Returns & Reschedules Summary ──────────────────────────────────────

const returnsData = [
  { reason: "Parts Needed", count: 8, avgDays: 4.2 },
  { reason: "Follow-Up Required", count: 5, avgDays: 7.1 },
  { reason: "Customer Request", count: 3, avgDays: 3.5 },
  { reason: "Failed Inspection", count: 2, avgDays: 6.0 },
];

const rescheduleData = [
  { reason: "No Access", count: 6, pctTotal: 35 },
  { reason: "Weather", count: 4, pctTotal: 24 },
  { reason: "Equipment Failure", count: 3, pctTotal: 18 },
  { reason: "Customer Canceled", count: 4, pctTotal: 23 },
];

// ─── Component ──────────────────────────────────────────────────────────

export function ReportsPage() {
  const ytdRevenue = monthlyRevenue.reduce((s, m) => s + m.revenue, 0);
  const ytdCost = monthlyRevenue.reduce((s, m) => s + m.cost, 0);
  const ytdProfit = ytdRevenue - ytdCost;
  const ytdShopDays = monthlyRevenue.reduce((s, m) => s + m.shopDays, 0);
  const maxMonthlyRevenue = Math.max(...monthlyRevenue.map(m => m.revenue));
  const avgProfit = ytdProfit / monthlyRevenue.length;

  const totalOutstanding = invoiceAging.reduce((s, i) => s + i.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <BarChart3 className="size-6 text-primary shrink-0" />
            Reports & Analytics
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            YTD performance through June 2026
          </p>
        </div>
        <div className="flex gap-2 self-start sm:self-auto">
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download className="size-3.5" /> Export PDF
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5">
            <FileSpreadsheet className="size-3.5" /> Export Excel
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Mail className="size-3.5" /> Schedule
          </Button>
        </div>
      </div>

      {/* ── YTD Summary ────────────────────────────────────────────── */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">YTD Revenue</span>
              <DollarSign className="size-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold">${(ytdRevenue / 1000).toFixed(0)}K</div>
            <div className="text-xs text-emerald-600 mt-1 flex items-center gap-0.5">
              <ArrowUpRight className="size-3" /> +22% vs last year
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">YTD Profit</span>
              <TrendingUp className="size-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold text-emerald-600">${(ytdProfit / 1000).toFixed(0)}K</div>
            <div className="text-xs text-muted-foreground mt-1">{Math.round((ytdProfit / ytdRevenue) * 100)}% margin</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Avg Monthly Profit</span>
              <BarChart3 className="size-4 text-blue-600" />
            </div>
            <div className="text-xl font-extrabold">${(avgProfit / 1000).toFixed(1)}K</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Total Shop Days</span>
              <Calendar className="size-4 text-red-600" />
            </div>
            <div className="text-xl font-extrabold text-red-600">{ytdShopDays}</div>
            <div className="text-xs text-emerald-600 mt-1 flex items-center gap-0.5">
              <TrendingDown className="size-3" /> −14% vs last year
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Main Tabs ─────────────────────────────────────────────── */}
      <Tabs defaultValue="revenue" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="revenue" className="text-xs">Revenue & Profit</TabsTrigger>
          <TabsTrigger value="utilization" className="text-xs">Utilization & Shop Days</TabsTrigger>
          <TabsTrigger value="profitability" className="text-xs">Tech ROI</TabsTrigger>
          <TabsTrigger value="invoices" className="text-xs">Invoice Aging</TabsTrigger>
          <TabsTrigger value="certs" className="text-xs">Cert Tracker</TabsTrigger>
          <TabsTrigger value="returns" className="text-xs">Returns & Reschedules</TabsTrigger>
        </TabsList>

        {/* ═══ Revenue & Profit ═══ */}
        <TabsContent value="revenue">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Monthly Revenue & Profit Trend</CardTitle>
              <CardDescription>Revenue (green) vs Cost (gray) — profit is the difference</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {monthlyRevenue.map(m => {
                  const revPct = (m.revenue / maxMonthlyRevenue) * 100;
                  const costPct = (m.cost / maxMonthlyRevenue) * 100;
                  return (
                    <div key={m.month}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium w-8">{m.month}</span>
                        <div className="flex gap-3">
                          <span className="text-emerald-600 font-bold">${(m.revenue / 1000).toFixed(1)}K</span>
                          <span className="text-muted-foreground">Cost: ${(m.cost / 1000).toFixed(1)}K</span>
                          <span className="font-bold">${(m.profit / 1000).toFixed(1)}K</span>
                          <span className={`${m.shopDays <= 35 ? "text-emerald-600" : "text-red-600"} font-medium`}>{m.shopDays} shop days</span>
                        </div>
                      </div>
                      <div className="relative h-5 bg-muted/50 rounded-full overflow-hidden">
                        <div className="absolute inset-y-0 left-0 bg-emerald-500/30 rounded-full" style={{ width: `${revPct}%` }} />
                        <div className="absolute inset-y-0 left-0 bg-emerald-600 rounded-full" style={{ width: `${costPct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-6 mt-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-emerald-600" /> Cost</span>
                <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-emerald-500/30" /> Revenue</span>
                <span>Profit = Revenue − Cost</span>
              </div>
            </CardContent>
          </Card>

          {/* Profitability by Client */}
          <Card className="mt-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Profitability by Client (Top 6)</CardTitle>
              <CardDescription>Revenue per client vs cost to service — YTD</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { client: "BCOGov (Glen Arm)", revenue: 22400, cost: 8200 },
                  { client: "Olive Garden — Columbia", revenue: 18400, cost: 6800 },
                  { client: "Hilton BWI Airport", revenue: 14800, cost: 5200 },
                  { client: "Metro Office Park", revenue: 15600, cost: 6400 },
                  { client: "Howard County Public Schools", revenue: 12200, cost: 4500 },
                  { client: "Chipotle — Rt 1", revenue: 11200, cost: 4100 },
                ].map(c => {
                  const profit = c.revenue - c.cost;
                  const margin = Math.round((profit / c.revenue) * 100);
                  return (
                    <div key={c.client} className="flex items-center gap-3">
                      <span className="text-xs font-medium w-48 truncate">{c.client}</span>
                      <div className="flex-1">
                        <Progress value={margin} className="h-3" />
                      </div>
                      <div className="text-right w-28 shrink-0">
                        <span className="text-xs font-bold text-emerald-600">${(profit / 1000).toFixed(1)}K</span>
                        <span className="text-xs text-muted-foreground ml-1">({margin}%)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══ Utilization & Shop Days ═══ */}
        <TabsContent value="utilization">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Shop Day Trend (Monthly)</CardTitle>
              <CardDescription>Fewer shop days = more billable revenue</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2 h-40">
                {monthlyRevenue.map(m => {
                  const maxShop = Math.max(...monthlyRevenue.map(r => r.shopDays));
                  const pct = (m.shopDays / maxShop) * 100;
                  const isLow = m.shopDays <= 35;
                  return (
                    <div key={m.month} className="flex-1 flex flex-col items-center gap-1">
                      <span className="text-xs font-bold">{m.shopDays}</span>
                      <div className="w-full rounded-t-lg relative" style={{ height: `${pct}%` }}>
                        <div className={`w-full h-full rounded-t-lg ${isLow ? "bg-emerald-500" : "bg-red-500"}`} />
                      </div>
                      <span className="text-[10px] text-muted-foreground">{m.month}</span>
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 text-xs text-muted-foreground text-center">
                ↓ Shop days trending down from 48 (Feb) to 30 (Jun) — 37.5% improvement
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Utilization by Technician</CardTitle>
              <CardDescription>Billable vs shop vs training days — this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {employees.map(emp => {
                  const billDays = Math.round(22 * emp.utilization / 100);
                  const shopDays = emp.shopDaysUsed;
                  const trainDays = Math.max(0, 22 - billDays - shopDays);
                  return (
                    <div key={emp.id}>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-medium">{emp.name}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-emerald-600">{billDays}d bill</span>
                          <span className="text-red-600">{shopDays}d shop</span>
                          {trainDays > 0 && <span className="text-amber-600">{trainDays}d train</span>}
                          <span className={`font-bold ${emp.utilization >= 90 ? "text-emerald-600" : emp.utilization >= 85 ? "text-amber-600" : "text-red-600"}`}>
                            {emp.utilization}%
                          </span>
                        </div>
                      </div>
                      <div className="flex h-3 rounded-full overflow-hidden bg-muted/50">
                        <div className="bg-emerald-500" style={{ width: `${(billDays / 22) * 100}%` }} />
                        <div className="bg-red-500" style={{ width: `${(shopDays / 22) * 100}%` }} />
                        {trainDays > 0 && <div className="bg-amber-500" style={{ width: `${(trainDays / 22) * 100}%` }} />}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-4 mt-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-emerald-500" /> Billable</span>
                <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-red-500" /> Shop</span>
                <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-amber-500" /> Training</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══ Tech ROI ═══ */}
        <TabsContent value="profitability">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-sm">Technician ROI Ranking</CardTitle>
                  <CardDescription>Monthly profitability ranked by return on investment</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Desktop */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">#</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Technician</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Revenue</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Cost</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Profit</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">ROI</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Shop Days</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Shop Cost</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Util</th>
                    </tr>
                  </thead>
                  <tbody>
                    {techProfitability.map((tech, i) => (
                      <tr key={tech.id} className="border-b border-muted/50 hover:bg-muted/20">
                        <td className="py-2.5 px-2 text-xs font-bold text-muted-foreground">{i + 1}</td>
                        <td className="py-2.5 px-2">
                          <div className="flex items-center gap-2">
                            <div className="size-7 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">{tech.avatar}</div>
                            <div>
                              <div className="font-semibold text-xs">{tech.name}</div>
                              <div className="text-[10px] text-muted-foreground">{tech.role}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-2.5 px-2 text-right text-xs font-medium text-emerald-600">${tech.revenueThisMonth.toLocaleString()}</td>
                        <td className="py-2.5 px-2 text-right text-xs text-muted-foreground">${Math.round(tech.monthlyCost).toLocaleString()}</td>
                        <td className={`py-2.5 px-2 text-right text-xs font-bold ${tech.profit >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                          ${Math.round(tech.profit).toLocaleString()}
                        </td>
                        <td className="py-2.5 px-2 text-right">
                          <Badge variant={tech.roi >= 150 ? "default" : tech.roi >= 100 ? "secondary" : "destructive"} className="text-[10px]">
                            {tech.roi}%
                          </Badge>
                        </td>
                        <td className="py-2.5 px-2 text-right text-xs">{tech.shopDaysUsed}/{tech.shopDaysAllowed}</td>
                        <td className="py-2.5 px-2 text-right text-xs text-red-600 font-medium">${tech.shopCostTotal.toLocaleString()}</td>
                        <td className="py-2.5 px-2">
                          <div className="flex items-center gap-2">
                            <Progress value={tech.utilization} className="h-2 w-16" />
                            <span className="text-xs font-medium">{tech.utilization}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="md:hidden space-y-3">
                {techProfitability.map((tech, i) => (
                  <div key={tech.id} className="border rounded-xl p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-muted-foreground w-5">#{i + 1}</span>
                        <div className="size-8 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">{tech.avatar}</div>
                        <div>
                          <div className="text-sm font-bold">{tech.name}</div>
                          <div className="text-[10px] text-muted-foreground">{tech.role}</div>
                        </div>
                      </div>
                      <Badge variant={tech.roi >= 150 ? "default" : tech.roi >= 100 ? "secondary" : "destructive"} className="text-[10px]">
                        {tech.roi}% ROI
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs">
                      <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-lg p-2">
                        <div className="text-[9px] text-muted-foreground">Profit</div>
                        <div className={`font-bold ${tech.profit >= 0 ? "text-emerald-600" : "text-red-600"}`}>${Math.round(tech.profit).toLocaleString()}</div>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-2">
                        <div className="text-[9px] text-muted-foreground">Util</div>
                        <div className="font-bold">{tech.utilization}%</div>
                      </div>
                      <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-2">
                        <div className="text-[9px] text-muted-foreground">Shop Cost</div>
                        <div className="font-bold text-red-600">${tech.shopCostTotal}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══ Invoice Aging ═══ */}
        <TabsContent value="invoices">
          {/* Aging Summary Cards */}
          <div className="grid gap-3 grid-cols-2 lg:grid-cols-4 mb-4">
            <Card className="border-emerald-200 dark:border-emerald-800">
              <CardContent className="p-4">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Current</div>
                <div className="text-xl font-extrabold text-emerald-600">
                  ${(agingBuckets.current.reduce((s, i) => s + i.amount, 0) / 1000).toFixed(1)}K
                </div>
                <div className="text-xs text-muted-foreground">{agingBuckets.current.length} invoices</div>
              </CardContent>
            </Card>
            <Card className="border-amber-200 dark:border-amber-800">
              <CardContent className="p-4">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">30+ Days</div>
                <div className="text-xl font-extrabold text-amber-600">
                  ${(agingBuckets["30"].reduce((s, i) => s + i.amount, 0) / 1000).toFixed(1)}K
                </div>
                <div className="text-xs text-muted-foreground">{agingBuckets["30"].length} invoices</div>
              </CardContent>
            </Card>
            <Card className="border-orange-200 dark:border-orange-800">
              <CardContent className="p-4">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">60+ Days</div>
                <div className="text-xl font-extrabold text-orange-600">
                  ${(agingBuckets["60"].reduce((s, i) => s + i.amount, 0) / 1000).toFixed(1)}K
                </div>
                <div className="text-xs text-muted-foreground">{agingBuckets["60"].length} invoices</div>
              </CardContent>
            </Card>
            <Card className="border-red-200 dark:border-red-800">
              <CardContent className="p-4">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">90+ Days</div>
                <div className="text-xl font-extrabold text-red-600">
                  ${(agingBuckets["90"].reduce((s, i) => s + i.amount, 0) / 1000).toFixed(1)}K
                </div>
                <div className="text-xs text-muted-foreground">{agingBuckets["90"].length} invoices</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Clock className="size-4 text-primary" />
                    Outstanding Invoices — ${totalOutstanding.toLocaleString()} Total
                  </CardTitle>
                  <CardDescription>Sorted by age (oldest first)</CardDescription>
                </div>
                <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                  <Download className="size-3.5" /> Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Desktop */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Invoice</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Client</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Amount</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Issued</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Due</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Age</th>
                      <th className="text-center py-2 px-2 font-medium text-muted-foreground text-xs">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...invoiceAging].sort((a, b) => b.age - a.age).map(inv => (
                      <tr key={inv.id} className="border-b border-muted/50 hover:bg-muted/20">
                        <td className="py-2.5 px-2 text-xs font-mono font-medium">{inv.id}</td>
                        <td className="py-2.5 px-2 text-xs font-medium">{inv.client}</td>
                        <td className="py-2.5 px-2 text-right text-xs font-bold">${inv.amount.toLocaleString()}</td>
                        <td className="py-2.5 px-2 text-xs text-muted-foreground">{inv.issued}</td>
                        <td className="py-2.5 px-2 text-xs text-muted-foreground">{inv.due}</td>
                        <td className="py-2.5 px-2 text-right text-xs font-bold">{inv.age}d</td>
                        <td className="py-2.5 px-2 text-center">
                          <Badge variant={inv.bucket === "current" ? "secondary" : inv.bucket === "30" ? "default" : inv.bucket === "60" ? "default" : "destructive"}
                            className={`text-[10px] ${inv.bucket === "30" ? "bg-amber-600" : inv.bucket === "60" ? "bg-orange-600" : ""}`}>
                            {inv.bucket === "current" ? "Current" : `${inv.bucket}+ Days`}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile */}
              <div className="md:hidden space-y-2">
                {[...invoiceAging].sort((a, b) => b.age - a.age).map(inv => (
                  <div key={inv.id} className="border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-mono font-medium">{inv.id}</span>
                      <Badge variant={inv.bucket === "90" ? "destructive" : inv.bucket === "current" ? "secondary" : "default"}
                        className={`text-[10px] ${inv.bucket === "30" ? "bg-amber-600" : inv.bucket === "60" ? "bg-orange-600" : ""}`}>
                        {inv.age}d
                      </Badge>
                    </div>
                    <div className="text-sm font-bold">{inv.client}</div>
                    <div className="flex items-center justify-between text-xs mt-1">
                      <span className="text-muted-foreground">Due: {inv.due}</span>
                      <span className="font-bold">${inv.amount.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══ Cert Tracker ═══ */}
        <TabsContent value="certs">
          {/* Alert for critical certs */}
          {certTracker.filter(c => c.status === "critical" || c.status === "expiring").length > 0 && (
            <Card className="border-red-200 dark:border-red-800 bg-red-50/50 dark:bg-red-950/10 mb-4">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm font-bold text-red-600 mb-2">
                  <AlertTriangle className="size-4" />
                  Certifications Requiring Attention
                </div>
                <div className="space-y-2">
                  {certTracker.filter(c => c.status === "critical" || c.status === "expiring").map((c, i) => (
                    <div key={i} className="text-xs flex items-center gap-2">
                      <Badge variant={c.status === "critical" ? "destructive" : "default"} className={`text-[10px] ${c.status === "expiring" ? "bg-amber-600" : ""}`}>
                        {c.status === "critical" ? "CRITICAL" : "EXPIRING"}
                      </Badge>
                      <span className="font-medium">{c.tech}</span>
                      <span className="text-muted-foreground">— {c.cert} expires {c.expiry} ({c.daysLeft} days)</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Award className="size-4 text-primary" />
                Certification Tracker — All Technicians
              </CardTitle>
              <CardDescription>Cert expiry dates, training needed, compliance status</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Desktop */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Technician</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Certification</th>
                      <th className="text-left py-2 px-2 font-medium text-muted-foreground text-xs">Expiry</th>
                      <th className="text-right py-2 px-2 font-medium text-muted-foreground text-xs">Days Left</th>
                      <th className="text-center py-2 px-2 font-medium text-muted-foreground text-xs">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {certTracker.map((c, i) => (
                      <tr key={i} className={`border-b border-muted/50 hover:bg-muted/20 ${c.status === "critical" ? "bg-red-50/50 dark:bg-red-950/10" : c.status === "expiring" ? "bg-amber-50/50 dark:bg-amber-950/10" : ""}`}>
                        <td className="py-2.5 px-2 text-xs font-medium">{c.tech}</td>
                        <td className="py-2.5 px-2">
                          <Badge variant="outline" className="text-[10px] text-primary border-primary/40">{c.cert}</Badge>
                        </td>
                        <td className="py-2.5 px-2 text-xs text-muted-foreground">{c.expiry}</td>
                        <td className="py-2.5 px-2 text-right text-xs font-bold">
                          <span className={c.status === "critical" ? "text-red-600" : c.status === "expiring" ? "text-amber-600" : "text-emerald-600"}>
                            {c.daysLeft}
                          </span>
                        </td>
                        <td className="py-2.5 px-2 text-center">
                          <Badge variant={c.status === "critical" ? "destructive" : c.status === "expiring" ? "default" : "secondary"}
                            className={`text-[10px] ${c.status === "expiring" ? "bg-amber-600" : ""}`}>
                            {c.status === "critical" ? "⚠ CRITICAL" : c.status === "expiring" ? "Expiring Soon" : "✓ Current"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile */}
              <div className="md:hidden space-y-2">
                {certTracker.map((c, i) => (
                  <div key={i} className={`border rounded-lg p-3 ${c.status === "critical" ? "border-red-300" : c.status === "expiring" ? "border-amber-300" : ""}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-bold">{c.tech}</span>
                      <Badge variant={c.status === "critical" ? "destructive" : c.status === "expiring" ? "default" : "secondary"}
                        className={`text-[10px] ${c.status === "expiring" ? "bg-amber-600" : ""}`}>
                        {c.status === "critical" ? "CRITICAL" : c.status === "expiring" ? "Expiring" : "Current"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <Badge variant="outline" className="text-[10px]">{c.cert}</Badge>
                      <span className="text-muted-foreground">Expires: {c.expiry} ({c.daysLeft}d)</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══ Returns & Reschedules ═══ */}
        <TabsContent value="returns">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Return Reasons — This Month</CardTitle>
                <CardDescription>Frequency, average resolution time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {returnsData.map(r => (
                    <div key={r.reason} className="flex items-center justify-between p-2.5 rounded-lg border hover:bg-muted/20">
                      <div>
                        <div className="text-sm font-medium">{r.reason}</div>
                        <div className="text-xs text-muted-foreground">Avg resolution: {r.avgDays} days</div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-amber-600">{r.count}</div>
                        <div className="text-[10px] text-muted-foreground">returns</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Total returns this month</span>
                  <span className="font-bold text-amber-600">{returnsData.reduce((s, r) => s + r.count, 0)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Reschedule Reasons — This Month</CardTitle>
                <CardDescription>Breakdown by cause</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {rescheduleData.map(r => (
                    <div key={r.reason}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-medium">{r.reason}</span>
                        <span className="text-muted-foreground">{r.count} ({r.pctTotal}%)</span>
                      </div>
                      <Progress value={r.pctTotal} className="h-2.5" />
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Total reschedules this month</span>
                  <span className="font-bold">{rescheduleData.reduce((s, r) => s + r.count, 0)}</span>
                </div>
                <div className="mt-2 text-xs text-muted-foreground bg-muted/50 p-2 rounded-lg">
                  ⚠ Jobs rescheduled 3+ times are auto-flagged for supervisor attention
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
