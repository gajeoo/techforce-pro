import { useState } from "react";
import {
  Car,
  Clock,
  MapPin,
  Navigation,
  Phone,
  RefreshCw,
  Search,
  Signal,
  Truck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
// import { employees } from "@/lib/mockData";

// Simulated vehicle / GPS tracking data
interface VehicleTracker {
  id: string;
  techId: string;
  techName: string;
  vehicle: string;
  vehiclePlate: string;
  lat: number;
  lng: number;
  address: string;
  speed: number;
  heading: string;
  status: "moving" | "idle" | "parked" | "off";
  currentJob: string | null;
  lastUpdate: string;
  clockInTime: string | null;
  clockInLocation: string | null;
  mileageTodayMi: number;
  engineStatus: "running" | "off";
}

const vehicleTrackers: VehicleTracker[] = [
  {
    id: "VT-001", techId: "E-001", techName: "Marcus Johnson",
    vehicle: "Truck #101 — 2023 Ford F-250", vehiclePlate: "MD 8F2 T91",
    lat: 39.2048, lng: -76.8611, address: "6181 Old Dobbin Ln, Columbia, MD 21045",
    speed: 0, heading: "N/A", status: "parked", currentJob: "Applebee's — Columbia",
    lastUpdate: "2 min ago", clockInTime: "7:45 AM", clockInLocation: "Shop — 8750 Bollman Pl, Savage, MD",
    mileageTodayMi: 18.4, engineStatus: "running"
  },
  {
    id: "VT-002", techId: "E-002", techName: "Sarah Chen",
    vehicle: "Truck #102 — 2022 Chevy Silverado", vehiclePlate: "MD 3K7 P45",
    lat: 39.2679, lng: -76.7984, address: "Route 40 near Ellicott City, MD",
    speed: 42, heading: "SW", status: "moving", currentJob: null,
    lastUpdate: "Just now", clockInTime: "7:30 AM", clockInLocation: "Home — 2145 Maplewood Dr, Catonsville, MD",
    mileageTodayMi: 32.1, engineStatus: "running"
  },
  {
    id: "VT-003", techId: "E-003", techName: "Derek Williams",
    vehicle: "Truck #103 — 2023 Ford F-250", vehiclePlate: "MD 5R9 W12",
    lat: 39.1812, lng: -76.6685, address: "1739 W Nursery Rd, Linthicum Heights, MD",
    speed: 0, heading: "N/A", status: "parked", currentJob: "Hilton BWI Airport",
    lastUpdate: "5 min ago", clockInTime: "8:00 AM", clockInLocation: "Shop — 8750 Bollman Pl, Savage, MD",
    mileageTodayMi: 24.7, engineStatus: "running"
  },
  {
    id: "VT-004", techId: "E-004", techName: "Mike Rodriguez",
    vehicle: "Truck #104 — 2021 Ram 1500", vehiclePlate: "MD 1V3 J78",
    lat: 39.1367, lng: -76.8234, address: "8750 Bollman Pl, Savage, MD 20763",
    speed: 0, heading: "N/A", status: "parked", currentJob: null,
    lastUpdate: "30 min ago", clockInTime: "8:15 AM", clockInLocation: "Shop — 8750 Bollman Pl, Savage, MD",
    mileageTodayMi: 0, engineStatus: "off"
  },
  {
    id: "VT-005", techId: "E-005", techName: "Chris Taylor",
    vehicle: "Truck #105 — 2022 Ford F-150", vehiclePlate: "MD 7T2 K56",
    lat: 39.2123, lng: -76.8456, address: "6060 Majors Ln, Columbia, MD 21045",
    speed: 0, heading: "N/A", status: "idle", currentJob: "Wells Fargo — Columbia",
    lastUpdate: "1 min ago", clockInTime: "7:50 AM", clockInLocation: "Home — 1089 Kings Valley Ct, Damasc., MD",
    mileageTodayMi: 41.3, engineStatus: "running"
  },
  {
    id: "VT-006", techId: "E-006", techName: "James Brown",
    vehicle: "Truck #106 — 2023 Chevy Silverado", vehiclePlate: "MD 4M8 B34",
    lat: 39.2534, lng: -76.8123, address: "Baltimore National Pike, near Catonsville",
    speed: 35, heading: "E", status: "moving", currentJob: null,
    lastUpdate: "Just now", clockInTime: "7:40 AM", clockInLocation: "Shop — 8750 Bollman Pl, Savage, MD",
    mileageTodayMi: 28.9, engineStatus: "running"
  },
];

// Clock in/out history
const clockHistory = [
  { tech: "Marcus Johnson", action: "Clock In", time: "7:45 AM", location: "39.1367° N, 76.8234° W — Shop, Savage MD", vehicle: "Truck #101" },
  { tech: "Sarah Chen", action: "Clock In", time: "7:30 AM", location: "39.2891° N, 76.7341° W — Home, Catonsville MD", vehicle: "Truck #102" },
  { tech: "James Brown", action: "Clock In", time: "7:40 AM", location: "39.1367° N, 76.8234° W — Shop, Savage MD", vehicle: "Truck #106" },
  { tech: "Chris Taylor", action: "Clock In", time: "7:50 AM", location: "39.3012° N, 77.2034° W — Home, Damascus MD", vehicle: "Truck #105" },
  { tech: "Derek Williams", action: "Clock In", time: "8:00 AM", location: "39.1367° N, 76.8234° W — Shop, Savage MD", vehicle: "Truck #103" },
  { tech: "Mike Rodriguez", action: "Clock In", time: "8:15 AM", location: "39.1367° N, 76.8234° W — Shop, Savage MD", vehicle: "Truck #104" },
];

function getStatusColor(status: VehicleTracker["status"]) {
  switch (status) {
    case "moving": return { bg: "bg-blue-600", text: "text-blue-600", light: "bg-blue-100 dark:bg-blue-900/30" };
    case "idle": return { bg: "bg-amber-500", text: "text-amber-600", light: "bg-amber-100 dark:bg-amber-900/30" };
    case "parked": return { bg: "bg-emerald-500", text: "text-emerald-600", light: "bg-emerald-100 dark:bg-emerald-900/30" };
    case "off": return { bg: "bg-gray-400", text: "text-gray-500", light: "bg-gray-100 dark:bg-gray-800" };
  }
}

export function GPSTrackingPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleTracker | null>(null);

  const filteredVehicles = vehicleTrackers.filter(v => {
    const matchesSearch = v.techName.toLowerCase().includes(search.toLowerCase()) ||
      v.vehicle.toLowerCase().includes(search.toLowerCase()) ||
      v.address.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || v.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const movingCount = vehicleTrackers.filter(v => v.status === "moving").length;
  const parkedCount = vehicleTrackers.filter(v => v.status === "parked").length;
  const idleCount = vehicleTrackers.filter(v => v.status === "idle").length;
  const totalMileage = vehicleTrackers.reduce((s, v) => s + v.mileageTodayMi, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Navigation className="size-6 text-primary shrink-0" />
            GPS Fleet Tracking
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Live vehicle locations, clock in/out GPS stamps, and fleet status
          </p>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5 self-start sm:self-auto">
          <RefreshCw className="size-3.5" /> Refresh
        </Button>
      </div>

      {/* Summary KPIs */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardContent className="p-4">
            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">Fleet Size</div>
            <div className="text-xl font-extrabold">{vehicleTrackers.length}</div>
            <div className="text-[10px] text-muted-foreground">vehicles tracked</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">Moving</span>
              <div className="size-2.5 rounded-full bg-blue-600 animate-pulse" />
            </div>
            <div className="text-xl font-extrabold text-blue-600">{movingCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">On Site</span>
              <div className="size-2.5 rounded-full bg-emerald-500" />
            </div>
            <div className="text-xl font-extrabold text-emerald-600">{parkedCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase">Idle</span>
              <div className="size-2.5 rounded-full bg-amber-500" />
            </div>
            <div className="text-xl font-extrabold text-amber-600">{idleCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-[10px] font-semibold text-muted-foreground uppercase mb-1">Total Miles Today</div>
            <div className="text-xl font-extrabold">{totalMileage.toFixed(1)}</div>
            <div className="text-[10px] text-muted-foreground">fleet-wide</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid gap-6 lg:grid-cols-5">
        {/* Map Area */}
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <MapPin className="size-4 text-primary" />
              Live Fleet Map
            </CardTitle>
            <CardDescription>Real-time vehicle positions — Columbia / Baltimore Metro area</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Simulated map */}
            <div className="relative w-full aspect-[16/10] rounded-lg bg-gradient-to-br from-emerald-50 via-blue-50 to-blue-100 dark:from-emerald-950/20 dark:via-blue-950/20 dark:to-blue-900/20 border overflow-hidden">
              {/* Grid lines */}
              <div className="absolute inset-0 opacity-20">
                {[...Array(8)].map((_, i) => (
                  <div key={`h-${i}`} className="absolute w-full border-t border-gray-400" style={{ top: `${(i + 1) * 11.1}%` }} />
                ))}
                {[...Array(12)].map((_, i) => (
                  <div key={`v-${i}`} className="absolute h-full border-l border-gray-400" style={{ left: `${(i + 1) * 7.7}%` }} />
                ))}
              </div>

              {/* Road outlines */}
              <div className="absolute inset-0">
                <div className="absolute top-[30%] left-0 right-0 h-[2px] bg-gray-300 dark:bg-gray-600 opacity-60" /> {/* I-70 */}
                <div className="absolute top-0 bottom-0 left-[60%] w-[2px] bg-gray-300 dark:bg-gray-600 opacity-60" /> {/* I-95 */}
                <div className="absolute top-[50%] left-[20%] right-[20%] h-[2px] bg-gray-300 dark:bg-gray-600 opacity-40" /> {/* Route 1 */}
              </div>

              {/* Area labels */}
              <div className="absolute top-[15%] left-[25%] text-[9px] text-muted-foreground font-medium opacity-50">Ellicott City</div>
              <div className="absolute top-[45%] left-[35%] text-[9px] text-muted-foreground font-medium opacity-50">Columbia</div>
              <div className="absolute top-[70%] left-[30%] text-[9px] text-muted-foreground font-medium opacity-50">Savage</div>
              <div className="absolute top-[55%] left-[65%] text-[9px] text-muted-foreground font-medium opacity-50">BWI Area</div>
              <div className="absolute top-[10%] left-[60%] text-[9px] text-muted-foreground font-medium opacity-50">Catonsville</div>

              {/* Vehicle pins */}
              {vehicleTrackers.map((v, i) => {
                const positions = [
                  { top: "40%", left: "38%" },   // Marcus - Columbia
                  { top: "18%", left: "52%" },   // Sarah - Ellicott City route
                  { top: "58%", left: "68%" },   // Derek - BWI
                  { top: "68%", left: "32%" },   // Mike - Shop/Savage
                  { top: "43%", left: "42%" },   // Chris - Columbia
                  { top: "22%", left: "45%" },   // James - Catonsville route
                ];
                const pos = positions[i] || { top: "50%", left: "50%" };
                const sc = getStatusColor(v.status);
                const isSelected = selectedVehicle?.id === v.id;

                return (
                  <div
                    key={v.id}
                    className={`absolute cursor-pointer transition-all duration-200 ${isSelected ? "z-20 scale-125" : "z-10 hover:scale-110"}`}
                    style={{ top: pos.top, left: pos.left, transform: "translate(-50%, -50%)" }}
                    onClick={() => setSelectedVehicle(isSelected ? null : v)}
                  >
                    <div className="relative">
                      <div className={`size-8 rounded-full ${sc.bg} border-2 border-white shadow-lg flex items-center justify-center`}>
                        <Truck className="size-4 text-white" />
                      </div>
                      {v.status === "moving" && (
                        <div className={`absolute -top-1 -right-1 size-3 rounded-full ${sc.bg} animate-ping`} />
                      )}
                      <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-[8px] font-bold text-foreground bg-white/90 dark:bg-background/90 rounded px-1 shadow-sm">
                        {v.techName.split(" ")[0]}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Shop marker */}
              <div className="absolute" style={{ top: "72%", left: "30%", transform: "translate(-50%, -50%)" }}>
                <div className="size-6 rounded-md bg-primary/20 border border-primary flex items-center justify-center">
                  <Car className="size-3 text-primary" />
                </div>
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-[7px] font-bold text-primary bg-white/80 dark:bg-background/80 rounded px-1">
                  SHOP
                </div>
              </div>
            </div>

            {/* Selected vehicle detail overlay */}
            {selectedVehicle && (
              <div className="mt-4 p-4 rounded-lg border bg-muted/30">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-sm font-bold">{selectedVehicle.techName}</h3>
                      <Badge variant="secondary" className={`text-[10px] ${getStatusColor(selectedVehicle.status).text}`}>
                        {selectedVehicle.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{selectedVehicle.vehicle}</p>
                    <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                      <MapPin className="size-3" /> {selectedVehicle.address}
                    </p>
                    {selectedVehicle.currentJob && (
                      <p className="text-xs font-medium text-primary mt-1">
                        On Job: {selectedVehicle.currentJob}
                      </p>
                    )}
                  </div>
                  <div className="text-right text-xs space-y-1">
                    <div className="text-muted-foreground">Speed: <span className="font-bold text-foreground">{selectedVehicle.speed} mph</span></div>
                    <div className="text-muted-foreground">Miles today: <span className="font-bold text-foreground">{selectedVehicle.mileageTodayMi} mi</span></div>
                    <div className="text-muted-foreground">Engine: <span className={`font-bold ${selectedVehicle.engineStatus === "running" ? "text-emerald-600" : "text-gray-500"}`}>{selectedVehicle.engineStatus}</span></div>
                    <div className="text-muted-foreground">Updated: <span className="font-bold text-foreground">{selectedVehicle.lastUpdate}</span></div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Vehicle List */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Truck className="size-4 text-primary" />
              Fleet Vehicles
            </CardTitle>
            <CardDescription>{vehicleTrackers.length} vehicles</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 mb-3">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2 size-3.5 text-muted-foreground" />
                <Input placeholder="Search..." className="pl-7 h-8 text-xs" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[100px] h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="moving">Moving</SelectItem>
                  <SelectItem value="parked">Parked</SelectItem>
                  <SelectItem value="idle">Idle</SelectItem>
                  <SelectItem value="off">Off</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              {filteredVehicles.map(v => {
                const sc = getStatusColor(v.status);
                const isSelected = selectedVehicle?.id === v.id;
                return (
                  <div
                    key={v.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${isSelected ? "border-primary bg-primary/5" : "hover:bg-muted/20"}`}
                    onClick={() => setSelectedVehicle(isSelected ? null : v)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative shrink-0">
                        <div className={`size-9 rounded-full ${sc.light} flex items-center justify-center`}>
                          <Truck className={`size-4 ${sc.text}`} />
                        </div>
                        <div className={`absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-white ${sc.bg}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold">{v.techName}</span>
                          <Badge variant="secondary" className={`text-[9px] ${sc.text}`}>{v.status}</Badge>
                        </div>
                        <p className="text-[10px] text-muted-foreground truncate">{v.address}</p>
                        <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                          <span className="flex items-center gap-0.5"><Truck className="size-2.5" /> {v.vehicle.split("—")[0].trim()}</span>
                          {v.speed > 0 && <span className="font-medium text-blue-600">{v.speed} mph</span>}
                          <span>{v.lastUpdate}</span>
                        </div>
                      </div>
                      <Phone className="size-3.5 text-muted-foreground hover:text-primary shrink-0" />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clock In/Out GPS Log */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <Clock className="size-4 text-primary" />
                Today's Clock In/Out — GPS Verified
              </CardTitle>
              <CardDescription>GPS coordinates stamped at every clock event</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">Technician</th>
                  <th className="text-center py-2 px-2 text-xs font-medium text-muted-foreground">Action</th>
                  <th className="text-center py-2 px-2 text-xs font-medium text-muted-foreground">Time</th>
                  <th className="text-left py-2 px-2 text-xs font-medium text-muted-foreground">GPS Location</th>
                  <th className="text-center py-2 px-2 text-xs font-medium text-muted-foreground">Vehicle</th>
                </tr>
              </thead>
              <tbody>
                {clockHistory.map((entry, i) => (
                  <tr key={i} className="border-b border-muted/50 hover:bg-muted/20">
                    <td className="py-2.5 px-2">
                      <div className="flex items-center gap-2">
                        <div className="size-6 rounded-full bg-primary/10 flex items-center justify-center text-[9px] font-bold text-primary">
                          {entry.tech.split(" ").map(n => n[0]).join("")}
                        </div>
                        <span className="text-xs font-semibold">{entry.tech}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-2 text-center">
                      <Badge variant="default" className="text-[10px] bg-emerald-600">{entry.action}</Badge>
                    </td>
                    <td className="py-2.5 px-2 text-center text-xs font-medium">{entry.time}</td>
                    <td className="py-2.5 px-2">
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Signal className="size-3 text-emerald-500 shrink-0" />
                        <span className="truncate">{entry.location}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-2 text-center text-xs text-muted-foreground">{entry.vehicle}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
