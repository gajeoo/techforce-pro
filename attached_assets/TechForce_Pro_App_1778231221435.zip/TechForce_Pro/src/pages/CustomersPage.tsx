import {
  AlertCircle,
  Building2,
  ChevronRight,
  DollarSign,
  MapPin,
  Plus,
  Search,
} from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { customers } from "@/lib/mockData";

function getTypeBadge(type: string) {
  const map: Record<string, string> = {
    Restaurant: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
    School: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
    Commercial: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    "Group Home": "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
    Condo: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300",
    Government: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  };
  return <Badge variant="secondary" className={`text-[10px] ${map[type] || ""}`}>{type}</Badge>;
}

function getContractBadge(status: string) {
  if (status === "active") return <Badge variant="default" className="bg-emerald-600 text-[10px]">Active</Badge>;
  if (status === "expiring") return <Badge variant="default" className="bg-amber-600 text-[10px]">Expiring</Badge>;
  return <Badge variant="secondary" className="text-[10px]">Pending</Badge>;
}

export function CustomersPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const totalRevenue = customers.reduce((s, c) => s + c.revenueYTD, 0);
  const totalJobs = customers.reduce((s, c) => s + c.jobCount, 0);
  const expiringCount = customers.filter(c => c.contractStatus === "expiring").length;

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.type.toLowerCase().includes(search.toLowerCase()) ||
    c.contact.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Building2 className="size-6 text-primary shrink-0" />
            Customer Pricing
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {customers.length} clients · Click a customer to see all locations & jobs
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5 self-start sm:self-auto">
              <Plus className="size-3.5" /> Add Customer
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Add New Customer</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Company Name</Label><Input placeholder="Acme Corp" /></div>
                <div>
                  <Label className="text-xs">Type</Label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="restaurant">Restaurant</SelectItem>
                      <SelectItem value="school">School</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="condo">Condo</SelectItem>
                      <SelectItem value="government">Government</SelectItem>
                      <SelectItem value="group-home">Group Home</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Contact Name</Label><Input placeholder="John Smith" /></div>
                <div><Label className="text-xs">Phone</Label><Input placeholder="(410) 555-0000" /></div>
              </div>
              <div><Label className="text-xs">Primary Address</Label><Input placeholder="123 Main St, Columbia, MD 21044" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Extinguisher Rate</Label><Input placeholder="$35/unit" /></div>
                <div><Label className="text-xs">Suppression Rate</Label><Input placeholder="$450" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
                <Button onClick={() => setAddOpen(false)}>Add Customer</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary */}
      <div className="grid gap-3 grid-cols-3">
        <Card>
          <CardContent className="p-4 text-center">
            <DollarSign className="size-4 text-emerald-600 mx-auto mb-1" />
            <div className="text-xl font-extrabold">${(totalRevenue / 1000).toFixed(0)}K</div>
            <div className="text-xs text-muted-foreground">Revenue YTD</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Building2 className="size-4 text-primary mx-auto mb-1" />
            <div className="text-xl font-extrabold">{totalJobs}</div>
            <div className="text-xs text-muted-foreground">Jobs YTD</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <AlertCircle className="size-4 text-amber-600 mx-auto mb-1" />
            <div className="text-xl font-extrabold text-amber-600">{expiringCount}</div>
            <div className="text-xs text-muted-foreground">Expiring</div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
        <Input placeholder="Search customers..." className="pl-8" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {/* Desktop Table */}
      <Card className="hidden lg:block">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Per-Client Pricing Table</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-foreground/20">
                  <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Customer</th>
                  <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Type</th>
                  <th className="text-center py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Locations</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Extinguisher</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Suppression</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Sprinkler</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Exit Light</th>
                  <th className="text-right py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Revenue</th>
                  <th className="text-left py-3 px-2 font-semibold text-xs uppercase tracking-wider text-muted-foreground">Status</th>
                  <th className="py-3 px-2"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(cust => (
                  <tr
                    key={cust.id}
                    className={`border-b border-muted/50 hover:bg-muted/20 transition-colors cursor-pointer ${cust.contractStatus === "expiring" ? "bg-amber-50/40 dark:bg-amber-950/10" : ""}`}
                    onClick={() => navigate(`/customers/${cust.id}`)}
                  >
                    <td className="py-3 px-2">
                      <Link to={`/customers/${cust.id}`} className="font-semibold text-primary hover:underline">
                        {cust.name}
                      </Link>
                    </td>
                    <td className="py-3 px-2">{getTypeBadge(cust.type)}</td>
                    <td className="py-3 px-2 text-center">
                      <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="size-3" />
                        {cust.locations.length}
                      </div>
                    </td>
                    <td className="py-3 px-2 text-right text-xs font-medium">{cust.extinguisher}</td>
                    <td className="py-3 px-2 text-right text-xs font-medium">{cust.suppression}</td>
                    <td className="py-3 px-2 text-right text-xs font-medium">{cust.sprinkler}</td>
                    <td className="py-3 px-2 text-right text-xs font-medium">{cust.exitLight}</td>
                    <td className="py-3 px-2 text-right text-xs font-bold text-emerald-600">${cust.revenueYTD.toLocaleString()}</td>
                    <td className="py-3 px-2">{getContractBadge(cust.contractStatus)}</td>
                    <td className="py-3 px-2">
                      <Link to={`/customers/${cust.id}`}>
                        <Button variant="ghost" size="sm" className="text-xs h-7 gap-1">
                          View <ChevronRight className="size-3" />
                        </Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Mobile/Tablet Cards */}
      <div className="lg:hidden space-y-3">
        {filtered.map(cust => (
          <Link key={cust.id} to={`/customers/${cust.id}`}>
            <Card className={`hover:border-primary/30 transition-colors cursor-pointer ${cust.contractStatus === "expiring" ? "border-amber-200 dark:border-amber-800" : ""}`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <div className="font-bold text-sm text-primary">{cust.name}</div>
                    <div className="flex items-center gap-2 mt-1">
                      {getTypeBadge(cust.type)}
                      {getContractBadge(cust.contractStatus)}
                    </div>
                  </div>
                  <div className="text-right shrink-0 flex items-center gap-1">
                    <div>
                      <div className="text-sm font-bold text-emerald-600">${cust.revenueYTD.toLocaleString()}</div>
                      <div className="text-[10px] text-muted-foreground">{cust.jobCount} jobs YTD</div>
                    </div>
                    <ChevronRight className="size-4 text-muted-foreground" />
                  </div>
                </div>

                <div className="text-xs text-muted-foreground mb-3 flex items-center gap-3">
                  <span>{cust.contact} · {cust.phone}</span>
                  <span className="flex items-center gap-1"><MapPin className="size-3" /> {cust.locations.length} location{cust.locations.length > 1 ? "s" : ""}</span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="bg-muted/50 rounded-lg p-2">
                    <div className="text-[9px] text-muted-foreground">Extinguisher</div>
                    <div className="text-xs font-bold">{cust.extinguisher}</div>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-2">
                    <div className="text-[9px] text-muted-foreground">Suppression</div>
                    <div className="text-xs font-bold">{cust.suppression}</div>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-2">
                    <div className="text-[9px] text-muted-foreground">Sprinkler</div>
                    <div className="text-xs font-bold">{cust.sprinkler}</div>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-2">
                    <div className="text-[9px] text-muted-foreground">Exit Light</div>
                    <div className="text-xs font-bold">{cust.exitLight}</div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-3 pt-2 border-t text-[11px] text-muted-foreground">
                  <span>Last service: {cust.lastService}</span>
                  <span className="text-primary font-medium">View Details →</span>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Info Box */}
      <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4">
        <p className="text-sm font-semibold text-amber-800 dark:text-amber-300 mb-1">💡 Custom Pricing</p>
        <p className="text-xs text-amber-700 dark:text-amber-400">
          Each customer gets tailored rates per service type. Click any customer to see all their locations, jobs grouped by due date or service type, and attached documents.
          Schools get volume discounts, restaurants pay standard rates, government contracts have fixed-bid pricing.
        </p>
      </div>
    </div>
  );
}
