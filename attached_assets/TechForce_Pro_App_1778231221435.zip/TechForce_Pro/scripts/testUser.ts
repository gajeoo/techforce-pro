export const TEST_USER = {
  email: "agent-4eaf178d@test.local",
  password: "jLDJg0IDbcCGaaOmmZ6V1-fsydOyL9a5",
  name: "Test Agent",
} as const;
